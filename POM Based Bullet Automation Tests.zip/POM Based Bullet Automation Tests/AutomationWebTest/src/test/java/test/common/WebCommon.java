package test.common;

public class WebCommon {
//test
}

package test.common;

public class WebProjectConstant {
	
	// login user
	public static final String url = "https://bulletauto.globalreach-partners.com/Account/LogOn";
//	public static final String url = "http://192.168.139.8:8888/Account/LogOn";

	// Test Data for Web
	public static final String testDataPath = "\\src\\test\\resources\\TestData\\";
	public static final String testResourcePath = "\\src\\test\\resources\\resource\\";
	public static final String excelTestcaseFileName = "AutomationTestCases_AdditionalFunction.xlsx";
	public static final String excelTestcaseSheetName = "E2E Test Cases";
	
	
	public static final int resultTestCaseColumn = 9;
	public static final String resultTestDataColumn = "Results";

	
}

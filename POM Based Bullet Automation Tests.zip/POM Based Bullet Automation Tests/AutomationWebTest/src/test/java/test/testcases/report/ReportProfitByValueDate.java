package test.testcases.report;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;
import test.page.bulletfinancialobjects.ReportPage;

public class ReportProfitByValueDate extends WebTestSetup{

	public final String DataSheetName = "ReportProfitByValueDate";
	public final String TestCaseName = "BulletFinancial_ReportProfitByValueDate";
	
	public ReportProfitByValueDate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ReportProfitByValueDateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ReportProfitByValueDateTestMethod(Object data[]) throws Exception {
		String reportname =	Common.getCellDataProvider(data, "Report Name");
		String fromdate =	Common.getCellDataProvider(data, "From Date");
		String todate =	Common.getCellDataProvider(data, "To Date");		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		ReportPage report = homepage.clickReport();
		report.verifyProfitByValueDateReport(reportname, fromdate, todate);
	}
	
}

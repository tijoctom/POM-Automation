package test.testcases.opentrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class OpenTradeDoubleClick extends WebTestSetup{

	public final String DataSheetName = "OpenTradeDoubleClick";
	public final String TestCaseName = "BulletNet_TradeOpen_DoubleClickTrade";
	
	public OpenTradeDoubleClick() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] OpenTradeDoubleClickTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void OpenTradeDoubleClickTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		SearchFXTrade searchFXtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage tradeentry= searchFXtrade.doubleclickTrade();
		tradeentry.verifyUrl(Common.getCellDataProvider(data, "Groupid"),Common.getCellDataProvider(data, "Search Key"));
		driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

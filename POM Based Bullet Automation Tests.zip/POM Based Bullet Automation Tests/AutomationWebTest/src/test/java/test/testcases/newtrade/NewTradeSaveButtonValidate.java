package test.testcases.newtrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;

public class NewTradeSaveButtonValidate extends WebTestSetup{

	public final String DataSheetName = "NewTradeSaveButtonValidate";
	public final String TestCaseName = "BulletNet_TradeFX_SaveValidate";
	
	public NewTradeSaveButtonValidate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NewTradeSaveButtonValidateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NewTradeSaveButtonValidateTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();;
		NewTradePage newtrade=findclient.navigateTradeFX();
		newtrade.verifySaveButtonValidation();
		driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

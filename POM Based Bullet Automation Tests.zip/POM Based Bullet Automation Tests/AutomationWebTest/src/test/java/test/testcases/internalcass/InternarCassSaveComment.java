package test.testcases.internalcass;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CassPage;
import test.page.bulletfinancialobjects.LoginPage;

public class InternarCassSaveComment extends WebTestSetup{

	public final String DataSheetName = "InternalCASS_SaveComments";
	public final String TestCaseName = "";
	
	public InternarCassSaveComment() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] InternarCassSaveCommentTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void InternarCassSaveCommentTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		CassPage.precondition();
		CassPage cass  = homepage.clickCass();
		cass.cassIBR();
		cass.verifyInternalCassSaveComment();
	}
	
}

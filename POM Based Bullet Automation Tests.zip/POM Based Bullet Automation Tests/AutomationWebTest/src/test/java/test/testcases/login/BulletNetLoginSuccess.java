package test.testcases.login;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;

public class BulletNetLoginSuccess extends WebTestSetup{

	public final String DataSheetName = "Login";
	public final String TestCaseName = "BulletNet_LoginAccount";
	
	public BulletNetLoginSuccess() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] LoginSuccessTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void LoginSuccessTestMethod(Object data[]) throws Exception {
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage;
		loginPage.LoginSubmit();
		// Check login success
		homepage = loginPage.verifyLoginSuccess();
		// Logoff
		homepage.logoff();
	}
	
}

package test.testcases.findclient;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;

public class ClientDetailsJournalSaveValidate extends WebTestSetup{

	public final String DataSheetName = "CDJournalSaveValidate";
	public final String TestCaseName = "BulletNet_ClientDetails_Journal_SaveJournalValidation";
	
	public ClientDetailsJournalSaveValidate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] CDJournalSaveValidateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void CDJournalSaveValidateTestMethod(Object data[]) throws Exception {
	
		String compid = Common.getCellDataProvider(data,"Compid");		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage clientdetails = homepage.search(compid);
		clientdetails.editJournal();
		clientdetails.verifyPopupMessage();
		
	}
	
}

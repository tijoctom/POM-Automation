package test.testcases.windowedforward;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class WindowForwardVerifyField extends WebTestSetup {

	public final String DataSheetName = "WindowForwardVerifyField";
	public final String TestCaseName = "WindowForwardVerifyField";

	public WindowForwardVerifyField() {

		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}

	@DataProvider(name = DataSheetName)
	public Object[][] WindowForwardVerifyFieldTestData() throws Exception {
		// return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	@Test(dataProvider = DataSheetName)
	public void WindowForwardVerifyFieldTest(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();
		NewTradePage newtrade = findclient.navigateTradeFX();
		newtrade.verifyFieldMandatoryMessage();
		newtrade.createTradeDealNoWithUtilDate();
		homepage.logoff();
        loginPage.loginAgain();
		homepage.navigateClientPage();
		SearchFXTrade searchtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage edittrade = searchtrade.openFirstRow(); 
		String tradeno = edittrade.verifyLastTradeNew();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();
		findclient.selectSwapRecordNew(tradeno);
		findclient.verifyFirstUtilSwapV2();
		findclient.submitDrowDown();
		findclient.drawDownApprovalPopUp();
		String drawdownNo =findclient.getDrawdownNumber();
		homepage.navigateClientPage();
		homepage.clickBtnOpenTrade();
		homepage.clickQuoteNumber(tradeno);
		homepage.verifyBokerDisabled();
		homepage.logoff();
        loginPage.loginAgain2();		
		findclient.navigateTradeApproval();
		findclient.verifyDrowdownNo(drawdownNo);
		findclient.approvalRecordNew(tradeno);
		edittrade.verifyFieldEnabled();
		
	}

}
package test.testcases.nominalallocation;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;

public class NominalAllocationInvalidRole extends WebTestSetup{

	public final String DataSheetName = "NominalAllocationInvalidRole";
	public final String TestCaseName = "BulletFinancial_NominalAllocationInvalidRole";
	
	public NominalAllocationInvalidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NominalAllocationInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NominalAllocationInvalidRoleTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyNominalAllocationRole();
	}
	
}

package test.testcases.options;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.OnboardingPage;
import test.page.bulletnetobjects.OptionsPage;


public class ClientCategorisationChange extends WebTestSetup{

	public final String DataSheetName = "ClientCategorisationChange";
	public final String TestCaseName = "ClientCategorisationChange";
	
	public ClientCategorisationChange() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ClientCategorisationChangeTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ClientCategorisationChangeTestMethod(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		OptionsPage option = homepage.navigatetoClientPage();
		option.clickNewOptions();
		option.createOptions();
		OnboardingPage onboard = homepage.navigateOnboarding();
		onboard.updateonboardingScreenNew();
		homepage.logoff();
		loginPage.loginAgain();
		option.clickOptionOpen();
		option.clickFirstCell();
		option.verifyOptionVerifyMsg();        
	}
	
}

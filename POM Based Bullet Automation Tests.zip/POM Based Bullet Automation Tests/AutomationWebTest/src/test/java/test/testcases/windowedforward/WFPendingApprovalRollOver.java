package test.testcases.windowedforward;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class WFPendingApprovalRollOver extends WebTestSetup {

	public final String DataSheetName = "WFPendingApprovalRollOver";
	public final String TestCaseName = "WFPendingApprovalRollOver";

	public WFPendingApprovalRollOver() {

		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}

	@DataProvider(name = DataSheetName)
	public Object[][] WFPendingApprovalRollOverTestData() throws Exception {
		// return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	@Test(dataProvider = DataSheetName)
	public void WFPendingApprovalRollOverTest(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();
		NewTradePage newtrade = findclient.navigateTradeFX();
		newtrade.createTradeDealNoWithUtilDate();
		homepage.logoff();
        loginPage.loginAgain();
		homepage.navigateClientPage();
		SearchFXTrade searchtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage edittrade = searchtrade.openFirstRow(); 
		String tradeno = edittrade.verifyLastTradeNew();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();
		findclient.selectSwapRecordNew(tradeno);
		findclient.selectSwapRollOver();
		findclient.inputRollOverDate();
		findclient.verifyFirstUtilRollOver();
		findclient.clickPlusButton();
		findclient.saveRollOver();
		String rollOver =findclient.getRollOverNumber();
		homepage.navigateClientPage();
		homepage.clickBtnOpenTrade();
		homepage.clickQuoteNumber(rollOver);
		edittrade.verifyRollOver();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();		
		findclient.selectSwapRecordNew(rollOver);
		findclient.submitDrowDown();
		findclient.drawDownApprovalPopUp();
		String drawdownNo =findclient.getDrawdownNumber();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();		
		findclient.selectSwapRecordNew(rollOver);
		findclient.submitDrowDown();
		findclient.verifyPendingApprovalMsg();
		homepage.logoff();
        loginPage.loginAgain2();		
		findclient.navigateTradeApproval();
		findclient.verifyDrowdownNo(drawdownNo);
		findclient.approvalRecordNew(rollOver);
		edittrade.verifyFieldEnabled();
		
	}

}
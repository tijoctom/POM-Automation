package test.testcases.exportpaymentmanual;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.ExportPaymentPage;
import test.page.bulletfinancialobjects.LoginPage;

public class ExportPaymentManualDoubleClick extends WebTestSetup{

	public final String DataSheetName = "ExportPaymentDoubleClick";
	public final String TestCaseName = "BulletFinancial_ExportPaymentManual_DoubleClick";
	
	public ExportPaymentManualDoubleClick() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ExportPaymentManualDoubleClickTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ExportPaymentManualDoubleClickTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		ExportPaymentPage exportmanual = homepage.clickExportPaymentManual();
		exportmanual.verifyDoubleClickManual();
	}
	
}

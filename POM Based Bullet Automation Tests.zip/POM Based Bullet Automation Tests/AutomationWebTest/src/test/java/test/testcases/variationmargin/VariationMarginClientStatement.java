package test.testcases.variationmargin;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;
import test.page.bulletfinancialobjects.VariationMarginPage;

public class VariationMarginClientStatement extends WebTestSetup{

	public final String DataSheetName = "VariationMarginClientStatement";
	public final String TestCaseName = "BulletFinancial_VariationMargin_ClientStatement";
	
	public VariationMarginClientStatement() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] VariationMarginClientStatementTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void VariationMarginClientStatementTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		VariationMarginPage variationmargin = homepage.clickVariationMargin();
		variationmargin.verifyClientStatement();
	}
	
}

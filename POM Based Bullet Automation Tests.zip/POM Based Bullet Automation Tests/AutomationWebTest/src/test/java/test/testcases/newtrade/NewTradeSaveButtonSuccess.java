package test.testcases.newtrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;

public class NewTradeSaveButtonSuccess extends WebTestSetup{

	public final String DataSheetName = "NewTradeSaveButtonSuccess";
	public final String TestCaseName = "BulletNet_TradeFX_SaveSuccess";
	
	public NewTradeSaveButtonSuccess() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NewTradeSaveButtonSuccessTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NewTradeSaveButtonSuccessTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		driver.closeOtherWindow();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();;
		NewTradePage newtrade=findclient.navigateTradeFX();
		newtrade.verifySaveButtonSuccess();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

package test.testcases.testrequired;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;

public class NetHomePageSettingRemovedFunction extends WebTestSetup{

	public final String DataSheetName = "NetHomePageRemoveFunction";
	public final String TestCaseName = "";
	
	public NetHomePageSettingRemovedFunction() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] HomePageSettingRemovedFunctionTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void HomePageSettingRemovedFunctionTestMethod(Object data[]) throws Exception {
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyRemovedLabelHomePageSetting();
		
	}
	
}

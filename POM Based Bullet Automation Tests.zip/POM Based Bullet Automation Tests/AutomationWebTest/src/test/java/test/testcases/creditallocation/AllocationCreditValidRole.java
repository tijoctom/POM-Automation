package test.testcases.creditallocation;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CreditAllocationPage;
import test.page.bulletfinancialobjects.LoginPage;

public class AllocationCreditValidRole extends WebTestSetup{

	public final String DataSheetName = "AllocationCreditValidRole";
	public final String TestCaseName = "BulletFinancial_AllocationCreditValidRole";
	
	public AllocationCreditValidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] AllocationCreditInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void AllocationCreditInvalidRoleTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyCreditAllocationRole();
		CreditAllocationPage creditallocationpage = homepage.clickCreditAllocation();
		creditallocationpage.verifyTitle();
	}
	
}

package test.testcases.creditallocation;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;

public class AllocationCreditInvalidRole extends WebTestSetup{

	public final String DataSheetName = "AllocationCreditInvalidRole";
	public final String TestCaseName = "BulletFinancial_AllocationCreditInvalidRole";
	
	public AllocationCreditInvalidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] AllocationCreditInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void AllocationCreditInvalidRoleTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyCreditAllocationRole();
	}
	
}

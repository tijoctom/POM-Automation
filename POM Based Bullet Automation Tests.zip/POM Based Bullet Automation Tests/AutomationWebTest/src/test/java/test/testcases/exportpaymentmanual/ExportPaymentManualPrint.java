package test.testcases.exportpaymentmanual;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.ExportPaymentPage;
import test.page.bulletfinancialobjects.LoginPage;

public class ExportPaymentManualPrint extends WebTestSetup{

	public final String DataSheetName = "ExportPaymentPrint";
	public final String TestCaseName = "BulletFinancial_ExportPaymentManual_Print";
	
	public ExportPaymentManualPrint() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ExportPaymentManualPrintTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ExportPaymentManualPrintTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		ExportPaymentPage exportmanual = homepage.clickExportPaymentManual();
		exportmanual.verifyPrintManual();
	}
	
}

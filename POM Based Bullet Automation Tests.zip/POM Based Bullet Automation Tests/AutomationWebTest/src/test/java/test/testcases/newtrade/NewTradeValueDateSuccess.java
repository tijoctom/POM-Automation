package test.testcases.newtrade;


import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;
import com.nashtech.utils.databases.SqlServerJDBC;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.CommonObject;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;

public class NewTradeValueDateSuccess extends WebTestSetup{

	public final String DataSheetName = "NewTradeValueDateSuccess";
	public final String TestCaseName = "BulletNet_TradeFX_ValueDateSuccess";

	
	public NewTradeValueDateSuccess() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NewTradeValueDateSuccessTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}
	
	
	@Test(dataProvider = DataSheetName)
	public void NewTradeValueDateSuccessTestMethod(Object data[]) throws Exception {
		SqlServerJDBC.getConnection();
		Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        if (Common.getCellDataProvider(data, "Payment Type").equalsIgnoreCase("Spot") ||
		Common.getCellDataProvider(data, "Payment Type").equalsIgnoreCase("Same currency"))
        	excelWriter.writeResultToExcel(testDataSheetName, dataIndex, "Value Date", sdf.format(cal.getTime()));        				
        else if (Common.getCellDataProvider(data, "Payment Type").equalsIgnoreCase("Forward")){
        	cal.add(Calendar.DATE, 10);
        	while (cal.get(Calendar.DAY_OF_WEEK)==7 ||cal.get(Calendar.DAY_OF_WEEK)==1 || 
        			CommonObject.isholiday(cal, Common.getCellDataProvider(data, "Sell Ccy").substring(0, Common.getCellDataProvider(data, "Sell Ccy").lastIndexOf(","))) ||
        			CommonObject.isholiday(cal, Common.getCellDataProvider(data, "Buy Ccy").substring(0, Common.getCellDataProvider(data, "Sell Ccy").lastIndexOf(","))))       			
			cal.add(Calendar.DATE, 1);		
        	excelWriter.writeResultToExcel(testDataSheetName, dataIndex, "Value Date", sdf.format(cal.getTime()));
        }	
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();;
		NewTradePage newtrade=findclient.navigateTradeFX();		
		newtrade.inputDate(sdf.format(cal.getTime()));
		newtrade.verifyInputDateSuccess();
		//driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
        }
	
}

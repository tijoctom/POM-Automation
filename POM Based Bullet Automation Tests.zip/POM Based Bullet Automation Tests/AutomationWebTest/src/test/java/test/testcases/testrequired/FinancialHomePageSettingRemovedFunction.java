package test.testcases.testrequired;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;

public class FinancialHomePageSettingRemovedFunction extends WebTestSetup{

	public final String DataSheetName = "FinancialHomePageRemoveFunction";
	public final String TestCaseName = "";
	
	public FinancialHomePageSettingRemovedFunction() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] HomePageSettingRemovedFunctionTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void HomePageSettingRemovedFunctionTestMethod(Object data[]) throws Exception {
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyRemovedLabelHomePageSetting();
		homepage.clickLogoff();
		
	}
	
}

package test.testcases.OPIInput;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;
import test.page.bulletfinancialobjects.OPIInput;

public class OPIInputCopyTemplate extends WebTestSetup{

	public final String DataSheetName = "OPIInputCopyTemplate";
	public final String TestCaseName = "BulletFinancial_CopyOPITemplate";
	
	public OPIInputCopyTemplate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] OPIInputCopyTemplateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void OPIInputCopyTemplateTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		OPIInput opiinput = homepage.clickOPIInput();
		opiinput.verifyCopyTemplate();
		
	}
	
}

package test.testcases.opentrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class OpenTradeOpenButton extends WebTestSetup{

	public final String DataSheetName = "OpenTradeOpenTrade";
	public final String TestCaseName = "BulletNet_TradeOpen_OpenButton";
	
	public OpenTradeOpenButton() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] OpenTradeOpenTradeTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void OpenTradeOpenTradeTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		SearchFXTrade searchFXtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage tradeentry= searchFXtrade.openTrade();
		tradeentry.verifyUrl(Common.getCellDataProvider(data, "Groupid"),Common.getCellDataProvider(data, "Search Key"));
		driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

package test.testcases.changepassword;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.ForgetPasswordPage;
import test.page.bulletnetobjects.LoginPage;

public class BulletForgetPasswordFail extends WebTestSetup{

	public final String DataSheetName = "ForgotPasswordValidation";
	public final String TestCaseName = "BulletNet_LoginAccountValidation";
	
	public BulletForgetPasswordFail() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ForgetPasswordFailTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ForgetPasswordFailTestMethod(Object data[]) throws Exception {
	
		LoginPage loginPage = new LoginPage(driver, data);
		// Navigate Forget Password Page from Login Page
		ForgetPasswordPage forgetpasswordpage = loginPage.navigateForgetPassword();
		// Input data then submit
		forgetpasswordpage.ForgotPasswordSubmitUsername();
		// Verify error message
		forgetpasswordpage.ForgotPasswordFail();

	}
	
}

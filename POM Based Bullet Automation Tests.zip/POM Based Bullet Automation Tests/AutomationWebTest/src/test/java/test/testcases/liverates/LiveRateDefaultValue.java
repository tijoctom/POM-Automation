package test.testcases.liverates;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LiveRatesPage;
import test.page.bulletnetobjects.LoginPage;

public class LiveRateDefaultValue extends WebTestSetup{

	public final String DataSheetName = "LiveRateDefault";
	public final String TestCaseName = "BulletNet_LiveRates_VerifyDefault";
	
	public LiveRateDefaultValue() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ClientDetailsDefaultValueTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ClientDetailsDefaultValueTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		LiveRatesPage liverates = homepage.clickBtnLiveRate();
		liverates.verifyData();
		
	}
	
}

package test.testcases.variationmargin;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;

public class VariationMarginPrecondition extends WebTestSetup{

	public final String DataSheetName = "VariationMarginPrecondition";
	public final String TestCaseName = "";
	
	public VariationMarginPrecondition() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] VariationMarginPreconditionTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void VariationMarginPreconditionTestMethod(Object data[]) throws Exception {
		String[] query=Common.getCellDataProvider(data, "Precondition").split("\n");
		SqlServerJDBC.getConnection();
		for (int i=0;i<query.length;i++){
			SqlServerJDBC.executeQuery(query[i]);
		}
	}
	
}

package test.testcases.windowedforward;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class WindowForwardGRMFCE extends WebTestSetup {

	public final String DataSheetName = "WindowForwardGRMFCE";
	public final String TestCaseName = "WindowForwardGRMFCE";

	public WindowForwardGRMFCE() {

		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}

	@DataProvider(name = DataSheetName)
	public Object[][] WindowForwardGRMFCETestData() throws Exception {
		// return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	@Test(dataProvider = DataSheetName)
	public void WindowForwardGRMFCETest(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();
		NewTradePage newtrade = findclient.navigateTradeFX();
		newtrade.verifyFirstUtilisationDateGRM();
		newtrade.createTradeDealNoNew();	
		homepage.logoff();
        loginPage.loginAgain();
		homepage.navigateClientPage();
		SearchFXTrade searchtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage edittrade = searchtrade.openFirstRow();
		edittrade.verifyFirstUtilDisabled();
		String tradeno = edittrade.verifyLastTradeNew();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();
		findclient.selectSwapRecordNew(tradeno);
		findclient.submitDrowDown();
		findclient.verifySwapTradeSuccess();
		findclient.verifyNoSwapV2FirstUtil();
		homepage.navigateClientPage();
		homepage.navigateAllTradeHistory();
		homepage.verifyFirstUtilAllTradeHistory();
		homepage.navigateClientPage();
		homepage.naviagteFXTradeHistory();
		homepage.verifyFirstUtilAllTradeHistory();	
		homepage.logoff();
		      
	}

}

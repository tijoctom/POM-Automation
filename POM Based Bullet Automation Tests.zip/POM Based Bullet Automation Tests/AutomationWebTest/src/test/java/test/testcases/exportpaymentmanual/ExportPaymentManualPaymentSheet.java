package test.testcases.exportpaymentmanual;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.ExportPaymentPage;
import test.page.bulletfinancialobjects.LoginPage;

public class ExportPaymentManualPaymentSheet extends WebTestSetup{

	public final String DataSheetName = "ExportPaymentPaymentSheet";
	public final String TestCaseName = "BulletFinancial_ExportPaymentManual_PaymentSheet";
	
	public ExportPaymentManualPaymentSheet() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ExportPaymentManualPaymentSheetTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ExportPaymentManualPaymentSheetTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		ExportPaymentPage exportmanual = homepage.clickExportPaymentManual();
		exportmanual.verifyPaymentSheetManual();
	}
	
}

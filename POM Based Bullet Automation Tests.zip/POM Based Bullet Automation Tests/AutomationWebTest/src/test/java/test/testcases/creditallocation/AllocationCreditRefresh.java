package test.testcases.creditallocation;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;

import test.common.WebProjectConstant;
import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CreditAllocationPage;
import test.page.bulletfinancialobjects.LoginPage;

public class AllocationCreditRefresh extends WebTestSetup{

	public final String DataSheetName = "AllocationCreditRefresh";
	public final String TestCaseName = "BulletFinancial_AllocationCreditRefresh";
	
	public AllocationCreditRefresh() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] AllocationCreditInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void AllocationCreditInvalidRoleTestMethod(Object data[]) throws Exception {
		String url = Common.getCellDataProvider(data, "Upload URL");
		url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + url;				
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyCreditAllocationRole();
		CreditAllocationPage creditallocationpage = homepage.clickCreditAllocation();
		creditallocationpage.importFile(url);
		creditallocationpage.associationCompany();
		creditallocationpage.verifyRefresh();
	}
	
}

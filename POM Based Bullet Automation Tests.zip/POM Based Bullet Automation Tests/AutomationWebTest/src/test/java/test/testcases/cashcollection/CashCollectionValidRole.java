package test.testcases.cashcollection;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CashCollectionPage;
import test.page.bulletfinancialobjects.LoginPage;

public class CashCollectionValidRole extends WebTestSetup{

	public final String DataSheetName = "CashCollectionValidID";
	public final String TestCaseName = "BulletFinancial_CashCollection_ValidPermission";
	
	public CashCollectionValidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] CashCollectionValidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void CashCollectionValidRoleTestMethod(Object data[]) throws Exception {		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyCashCollectionRole();
		CashCollectionPage cashcollectionpage = homepage.clickCashCollection();
		cashcollectionpage.verifyTitle();
		loginPage.LogOff();
	}
	
}

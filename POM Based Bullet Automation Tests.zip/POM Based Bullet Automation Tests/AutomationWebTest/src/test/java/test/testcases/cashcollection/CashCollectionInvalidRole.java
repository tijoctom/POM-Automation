package test.testcases.cashcollection;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;

public class CashCollectionInvalidRole extends WebTestSetup{

	public final String DataSheetName = "CashCollectionInvalidID";
	public final String TestCaseName = "BulletFinancial_CashCollection_InvalidPermission";
	
	public CashCollectionInvalidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] CashCollectionInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void CashCollectionInvalidRoleTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		//homepage.verifyCashCollectionRole();
		homepage.verifyInvalidCashCollection();
		loginPage.LogOff();		
	}
	
}

package test.testcases.exportpaymentmanual;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.ExportPaymentPage;
import test.page.bulletfinancialobjects.LoginPage;

public class ExportPaymentManualDelete extends WebTestSetup{

	public final String DataSheetName = "ExportPaymentDeleteOPI";
	public final String TestCaseName = "BulletFinancial_ExportPaymentManual_DeleteOPI";
	
	public ExportPaymentManualDelete() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ExportPaymentManualDeleteTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ExportPaymentManualDeleteTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		ExportPaymentPage exportmanual = homepage.clickExportPaymentManual();
		exportmanual.verifyDeleteManual();
	}
	
}

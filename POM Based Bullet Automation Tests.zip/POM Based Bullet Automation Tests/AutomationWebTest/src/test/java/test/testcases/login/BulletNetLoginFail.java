package test.testcases.login;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.LoginPage;

public class BulletNetLoginFail extends WebTestSetup{

	public final String DataSheetName = "LoginValidation";
	public final String TestCaseName = "BulletNet_LoginAccountValidation";
	
	public BulletNetLoginFail() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] LoginSuccessTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void LoginSuccessTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		//
		loginPage.LoginSubmit();
		// Check login success
		loginPage.verifyLoginUnsuccess();

	}
	
}

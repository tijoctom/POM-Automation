package test.testcases.newtrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;

public class NewTradePlusButtonValidate extends WebTestSetup{

	public final String DataSheetName = "NewTradePlusButtonValidate";
	public final String TestCaseName = "BulletNet_TradeFX_PlusButtonValidate";
	
	public NewTradePlusButtonValidate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NewTradePlusButtonValidateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NewTradePlusButtonValidateTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();;
		NewTradePage newtrade=findclient.navigateTradeFX();
		newtrade.verifyPlusButtonValidation();	
		driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

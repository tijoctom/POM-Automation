package test.testcases.testrequired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;
import test.page.bulletfinancialobjects.OPIHistoryPage;

public class BugGRPFCEIN8951 extends WebTestSetup{

	public final String DataSheetName = "BugGRPFCEIN8951";
	public final String TestCaseName = "BugGRPFCEIN8951";
	
	public BugGRPFCEIN8951() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] BugGRPFCEIN8951TestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void BugGRPFCEIN8951TestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		OPIHistoryPage opihistory = homepage.clickOPIHistory();
		opihistory.verifySearchAmountData();
	}
	
}

package test.testcases.cashcollection;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CashCollectionPage;
import test.page.bulletfinancialobjects.LoginPage;

public class CashCollectionUpdate extends WebTestSetup{

	public final String DataSheetName = "CashCollectionUpdate";
	public final String TestCaseName = "BulletFinancial_CashCollection_Update";
	
	public CashCollectionUpdate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] CashCollectionUpdateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void CashCollectionUpdateTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		CashCollectionPage cashcollection = homepage.clickCashCollection();
		cashcollection.verifyUpdate();
		loginPage.LogOff();
	}
	
}

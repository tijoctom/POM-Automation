package test.testcases.opentrade;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.SearchFXTrade;

public class OpenTradeSearch extends WebTestSetup{

	public final String DataSheetName = "OpenTradeSearch";
	public final String TestCaseName = "BulletNet_TradeOpen_SearchTrade";
	
	public OpenTradeSearch() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] OpenTradeSearchTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void OpenTradeSearchTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		SearchFXTrade searchFXtrade = homepage.clickBtnOpenTrade();
		searchFXtrade.verifySearchDataReturn();
		driver.closeOtherWindow();
		homepage.logoff();
		SqlServerJDBC.closeConnection();
	}
	
}

package test.testcases.advancesearch;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletnetobjects.AdvanceSearchPage;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;

public class AdvanceSearchSearch extends WebTestSetup{

	public final String DataSheetName = "AdvanceSearchSearch";
	public final String TestCaseName = "BulletNet_AdvanceSearch_Search";
	
	public AdvanceSearchSearch() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] AdvanceSearchSearchTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void AdvanceSearchSearchTestMethod(Object data[]) throws Exception {
			
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		AdvanceSearchPage advancesearch = homepage.clickBtnAdvanceSearch();
		advancesearch.verifySearchFunction();
		driver.closeOtherWindow();
		homepage.logoff();
	}
	
}

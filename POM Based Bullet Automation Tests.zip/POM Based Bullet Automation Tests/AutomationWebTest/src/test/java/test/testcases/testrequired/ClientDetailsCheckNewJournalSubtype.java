package test.testcases.testrequired;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;

public class ClientDetailsCheckNewJournalSubtype extends WebTestSetup{

	public final String DataSheetName = "ClientDetailsNewJournalSubtype";
	public final String TestCaseName = "";
	
	public ClientDetailsCheckNewJournalSubtype() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ClientDetailsCheckNewJournalSubtypeTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ClientDetailsCheckNewJournalSubtypeTestMethod(Object data[]) throws Exception {
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage clientdetails = homepage.navigateClientPage();
		clientdetails.verifyJournalNewSubType();
		
	}
	
}

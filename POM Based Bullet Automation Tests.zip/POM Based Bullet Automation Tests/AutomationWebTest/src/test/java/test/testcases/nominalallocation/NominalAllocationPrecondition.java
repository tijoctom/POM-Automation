package test.testcases.nominalallocation;


import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebProjectConstant;
import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.CreditAllocationPage;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;


import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class NominalAllocationPrecondition extends WebTestSetup{

	public final String DataSheetName = "NominalAllocationPrecondition";
	public final String TestCaseName = "";
	
	public NominalAllocationPrecondition() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	@DataProvider(name=DataSheetName)
	public Object[][] NominalAllocationInvalidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NominalAllocationInvalidRoleTestMethod(Object data[]) throws Exception {
		
		
		SqlServerJDBC.getConnection();
		driver.closeOtherWindow();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();;
		NewTradePage newtrade=findclient.navigateTradeFX();
		String dealno =newtrade.createTradeDealNo();
		SearchFXTrade searchtrade= homepage.clickBtnOpenTrade();
		TradeEntryPage edittrade = searchtrade.openFirstRow();
		edittrade.verifyLastTrade();
		excelWriter.writeResultToExcelBatch(Common.correctPath(Common.strWorkspacepath
				+ WebProjectConstant.testDataPath), testCaseFileName, "NominalAllocationSearchDeal", 2, "Keyword", dealno);		
		
		

	}
	
}

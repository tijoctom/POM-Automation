package test.testcases.windowedforward;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;

public class WFRollingOverRollover extends WebTestSetup {

	public final String DataSheetName = "WFRollingOverRollover";
	public final String TestCaseName = "WFRollingOverRollover";

	public WFRollingOverRollover() {

		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}

	@DataProvider(name = DataSheetName)
	public Object[][] WFRollingOverRolloverTestData() throws Exception {
		// return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	@Test(dataProvider = DataSheetName)
	public void WFRollingOverRolloverTest(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage findclient = homepage.navigateClientPage();
		NewTradePage newtrade = findclient.navigateTradeFX();
		newtrade.createTradeDealNoWithUtilDate();
		homepage.logoff();
        loginPage.loginAgain();
		homepage.navigateClientPage();
		SearchFXTrade searchtrade = homepage.clickBtnOpenTrade();
		TradeEntryPage edittrade = searchtrade.openFirstRow(); 
		String tradeno = edittrade.verifyLastTradeNew();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();
		findclient.selectSwapRecordNew(tradeno);
		findclient.selectSwapRollOver();
		findclient.inputRollOverDate();
		findclient.clickPlusButton();
		findclient.saveRollOver();
		String rollOver =findclient.getRollOverNumber();
		homepage.navigateClientPage();
		homepage.clickBtnOpenTrade();
		homepage.clickQuoteNumber(rollOver);
		edittrade.verifyRollOver();
		homepage.navigateClientPage();
		findclient.navigateSwapV2();		
		findclient.selectSwapRecordNew(rollOver);
		findclient.selectSwapRollOver();
		findclient.verifyFirstUtilRollOverRollOver();
		
		
	}

}
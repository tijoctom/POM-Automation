package test.testcases.liverates;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LiveRatesPage;
import test.page.bulletnetobjects.LoginPage;

public class LiveRateSearch extends WebTestSetup{

	public final String DataSheetName = "LiveRateSearch";
	public final String TestCaseName = "LiveRateSearch";
	
	public LiveRateSearch() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] LiveRateSearchTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void LiveRateSearchTestMethod(Object data[]) throws Exception {
			
		SqlServerJDBC.getConnection();
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		LiveRatesPage liverates = homepage.clickBtnLiveRate();
		liverates.inputData();
		liverates.clickButtonGo();
		
	}
	
}

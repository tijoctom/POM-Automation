package test.testcases.windowedforward;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;


public class WFTradeApprovalInvalidRole extends WebTestSetup {

	public final String DataSheetName = "WFTradeApprovalInvalidRole";
	public final String TestCaseName = "WFTradeApprovalInvalidRole";

	public WFTradeApprovalInvalidRole() {

		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}

	@DataProvider(name = DataSheetName)
	public Object[][] WFTradeApprovalInvalidRoleTestData() throws Exception {
		// return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	@Test(dataProvider = DataSheetName)
	public void WFTradeApprovalInvalidRoleTest(Object data[]) throws Exception {

		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyTradeApproval();
		homepage.logoff();
		
	}

}
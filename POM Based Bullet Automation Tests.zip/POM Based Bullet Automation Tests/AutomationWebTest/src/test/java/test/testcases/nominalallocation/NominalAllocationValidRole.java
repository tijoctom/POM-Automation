package test.testcases.nominalallocation;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;

public class NominalAllocationValidRole extends WebTestSetup{

	public final String DataSheetName = "NominalAllocationValidRole";
	public final String TestCaseName = "BulletFinancial_NominalAllocationValidRole";
	
	public NominalAllocationValidRole() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] NominalAllocationValidRoleTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void NominalAllocationValidRoleTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		homepage.verifyNominalAllocationRole();
	}
	
}

package test.testcases.testrequired;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.NewTradePage;
import test.page.bulletnetobjects.SearchFXTrade;
import test.page.bulletnetobjects.TradeEntryPage;
import test.page.bulletnetobjects.TradeReportPage;

public class StoryGRPFCEIN9356 extends WebTestSetup{

	public final String DataSheetName = "StoryGRPFCEIN9356";
	public final String TestCaseName = "BulletNet_TradeFX_SaveSuccess";
	//Bullet: Contract Note\Report OPI - List only unique beneficiaries (De-Dupe)
	public StoryGRPFCEIN9356() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] StoryGRPFCEIN9356TestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void StoryGRPFCEIN9356TestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		SearchFXTrade searchpage = homepage.clickBtnOpenTrade();
		TradeEntryPage tradeentrypage = searchpage.openTrade();
		TradeReportPage tradereportpage =tradeentrypage.navigateTradeReport();
		tradereportpage.verifyOpiData();
	}
	
}

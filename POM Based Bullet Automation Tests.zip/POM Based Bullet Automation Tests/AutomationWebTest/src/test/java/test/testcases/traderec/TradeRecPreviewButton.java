package test.testcases.traderec;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.LoginPage;
import test.page.bulletnetobjects.TradeReconciliationPage;

public class TradeRecPreviewButton extends WebTestSetup{

	public final String DataSheetName = "TradeRecPreview";
	public final String TestCaseName = "BulletNet_TradeRec_Preview";
	
	public TradeRecPreviewButton() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] TradeRecPreviewButtonTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void TradeRecPreviewButtonTestMethod(Object data[]) throws Exception {
		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage=loginPage.LoginSubmit();
		TradeReconciliationPage traderec = homepage.clickTradeRec(Common.getCellDataProvider(data, "Groupid"));
		traderec.selectCounterparties(Common.getCellDataProvider(data, "Counterparties"));
		traderec.verifyPreview(Common.getCellDataProvider(data, "Report Name"));
	}
	
}

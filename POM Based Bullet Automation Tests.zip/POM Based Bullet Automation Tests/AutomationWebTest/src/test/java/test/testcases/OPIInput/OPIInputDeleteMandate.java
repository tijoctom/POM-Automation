package test.testcases.OPIInput;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import test.common.WebTestSetup;
import test.page.bulletfinancialobjects.BulletFinancialHomePage;
import test.page.bulletfinancialobjects.LoginPage;
import test.page.bulletfinancialobjects.OPIInput;

public class OPIInputDeleteMandate extends WebTestSetup{

	public final String DataSheetName = "OPIInputDeleteMandate";
	public final String TestCaseName = "BulletFinancial_OPIInputDeleteMandate";
	
	public OPIInputDeleteMandate() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] OPIInputDeleteMandateTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void OPIInputDeleteMandateTestMethod(Object data[]) throws Exception {
		LoginPage loginPage = new LoginPage(driver, data);
		BulletFinancialHomePage homepage = loginPage.LoginSubmit();
		OPIInput opiinput = homepage.clickOPIInput();
		opiinput.verifyDeleteMandate();
		
	}
	
}

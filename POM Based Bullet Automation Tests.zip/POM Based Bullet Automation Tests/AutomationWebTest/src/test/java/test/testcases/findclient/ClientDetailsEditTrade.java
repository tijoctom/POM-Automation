package test.testcases.findclient;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nashtech.common.Common;

import test.common.WebTestSetup;
import test.page.bulletnetobjects.BulletNetHomePage;
import test.page.bulletnetobjects.FindClientPage;
import test.page.bulletnetobjects.LoginPage;

public class ClientDetailsEditTrade extends WebTestSetup{

	public final String DataSheetName = "ClientDetailsEdit";
	public final String TestCaseName = "BulletNet_ClientDetails_ClientInfo_EditClient";
	
	public ClientDetailsEditTrade() {
		
		testDataSheetName = DataSheetName;
		strTestCaseName = TestCaseName;
	}
	
	
	@DataProvider(name=DataSheetName)
	public Object[][] ClientDetailsDefaultValueTestData() throws Exception{
		//return the data from excel file
		Object[][] data = getTestProvider();
		return data;
	}

	
	@Test(dataProvider = DataSheetName)
	public void ClientDetailsDefaultValueTestMethod(Object data[]) throws Exception {
	
		String compid = Common.getCellDataProvider(data,"Compid");		
		LoginPage loginPage = new LoginPage(driver, data);
		BulletNetHomePage homepage = loginPage.LoginSubmit();
		FindClientPage clientdetails = homepage.search(compid);
		clientdetails.editdata();
		clientdetails.saveClient();
		clientdetails.verifyPopupMessage();
		
	}
	
}

package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

import test.page.bulletnetobjects.CommonObject;

public class ReportPage{

	private WebDriverMethod driverMethod;
	@SuppressWarnings("unused")
	private Object [] data;

	// Web Element Locators
	private By txtFromDate = By.xpath("//*[@id='mskDateFrom']");
	private By txtToDate = By.xpath("//*[@id='mskDateTo']");
	private By optProfitByValueDate = By.xpath("//*[@id='optProfitByValueDate']");
	private By btnPreview = By.xpath("//*[@id='btnPreview']");
	private By lbInvalidPermission = By.xpath("//td[text()='You do not have access rights to run this report.']");
	
	public ReportPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void openProfitByValueDateReport(String fromdate, String todate) throws Exception{
		driverMethod.selectRadioButton("optProfitByValueDate", optProfitByValueDate);
		driverMethod.inputText("txtFromDate", txtFromDate, fromdate);
		driverMethod.inputText("txtToDate", txtToDate, todate);
		driverMethod.click("btnPreview", btnPreview);
	}
	public void verifyProfitByValueDateReport(String reportname, String fromdate, String todate) throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();		
		openProfitByValueDateReport(fromdate, todate);
		driverMethod.switchwindow(size);
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.LONG_WAITTIME_SECONDS);
		String url = driverMethod.driver.getCurrentUrl();
		driverMethod.compareText("reportname", reportname, url.substring(url.lastIndexOf("reportName=")));
	}
	public void verifyProfitByValueDateInvalidPermission() throws Exception{
		driverMethod.selectRadioButton("optProfitByValueDate", optProfitByValueDate);
		driverMethod.click("btnPreview", btnPreview);
		driverMethod.isElementDisplayed(lbInvalidPermission);
	}
}

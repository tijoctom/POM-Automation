package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;


public class AdvanceSearchPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtClientCode = By.xpath("//input[@id='ClientCodeValue']");
	private By txtLegacyClientCode = By.xpath("//input[@id='ImportClientNo']");
	private By ddlCodedBy = By.xpath("//select[@id='ClientCodeUserValue']");
	private By ddlRegisteredTo = By.xpath("//select[@id='RegisteredToValue']");
	private By txtCompany = By.xpath("//input[@id='CompanyValue']");
	private By txtContactName = By.xpath("//input[@id='ContactNameValue']");
	private By ddlACManager = By.xpath("//select[@id='AcManagerValue']");
	private By ddlSecondaryDealer = By.xpath("//select[@id='SecondaryDealerValue']");
	private By ddlACExecutive = By.xpath("//select[@id='AcExecutiveValue']");
	private By ddlAEIntroducer = By.xpath("//select[@id='AEIntroducerValue']");
	private By ddlClientList = By.xpath("//select[@id='ClientTypeValue']");
	private By txtCampaignCode = By.xpath("//input[@id='CampaignCode']");
	private By ddlCategorisation = By.xpath("//select[@id='AbcGradeValue']");
	private By ddlSubCategorisation = By.xpath("//select[@id='SubCategorisationValue']");
	private By txtWebsite = By.xpath("//input[@id='WebsiteValue']");
	private By ddlDepartment = By.xpath("//select[@id='DepartmentValue']");
	private By ddlInactiveReason = By.xpath("//select[@name='InactiveReason']");
	private By txtCampaignLabel = By.xpath("//input[@id='CampaignLabel']");
	
	private By ddlForexTurnover = By.xpath("//select[@id='ForexTurnOverValue']");
	private By ddlTradeFrequency = By.xpath("//select[@id='TradeFrequencyValue']");
	private By ddlTradeSize = By.xpath("//select[@id='TradeSizeValue']");
	private By txtCreationDate = By.xpath("//input[@id='CreationDateValue']");
	private By txtCodedDateTime = By.xpath("//input[@id='ClientCodeDateTime']");
	private By ddlThirdParties = By.xpath("//select[@id='ThirdPartiesValue']");
	private By ddlIndustry = By.xpath("//select[@id='IndustryValue']");
	private By ddlTrading = By.xpath("//select[@id='TradingPotentialValue']");
	private By ddlOpportunity = By.xpath("//select[@id='TrafficLightValue']");
	private By ddlBuyCategory = By.xpath("//select[@id='BuyCurrenciesValue']");
	private By ddlSellCategory = By.xpath("//select[@id='SellCurrenciesValue']");
	private By txtEmail = By.xpath("//input[@id='EmailAddressValue']");
	private By ddlLeadMethod = By.xpath("//select[@id='LeadMethodValue']");
	private By ddlLeadMedium  = By.xpath("//select[@id='LeadMediumValue']");
	private By ddlLeadSource = By.xpath("//select[@id='LeadSourceValue']");
	private By txtPhoneNumber = By.xpath("//input[@id='PhoneNumberValue']");
	private By ddlBDDOwner = By.xpath("//select[@id='NbeMemberValue']");
	private By ddlAMLRisk = By.xpath("//select[@id='AmlRiskValue']");
	
	
	
	private By chkIBFX = By.xpath("//input[@id='ClientMode-IBFX']");
	private By chkClient = By.xpath("//input[@id='ClientMode-Client']");
	private By btnSearch = By.xpath("//input[@id='searchActionSubmit']");
	private By btnReset = By.xpath("//input[@id='searchReset']");
	private By btnAdvanceSearch = By.xpath("//input[@id='toggleMode']");
	private By btnPrint = By.xpath("//input[@id='printResults']");
	private By btnOpen = By.xpath("//input[@id='openResultItem']");
	
	private By tblAdvanceSearch = By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr");
	private By tblClientList (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[1]");
	}	
	private By tblClientCode (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[2]");
	}	
	private By tblLegacyClientCode (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[3]");
	}	
//	private By tblCodedBy 
	private By tblRegisteredTo (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[4]");
	}	
	private By tblCompany (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[5]");
	}	
	private By tblContactName (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[6]");
	}	
	private By tblACManager (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[18]");
	}	
	//	private By tblSecondaryDealer 
	/*
	private By tblACExecutive (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[19]");
	}
	//	private By tblDepartment 
	private By tblInactiveReason (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[24]");
	}	
	*/	
	//	private By tblAEIntroducer
	private By tblCampaignCode(int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[31]");
	}	
	private By tblCategorisation (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[22]");
	}	
	private By tblSubCategorisation (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[23]");
	}	
	private By tblWebsite (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[27]");
	}	

	private By tblCampaignLabel (int i){
		return By.xpath("//*[@id='AdvancedSearchTable']/tbody/tr["+i+"]/td[32]");
	}	
	
	public AdvanceSearchPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void inputDataSearch() throws Exception{
		String clientcode= Common.getCellDataProvider(data, "Client Code");
		String legacyclientcode= Common.getCellDataProvider(data, "Legacy Client Code");
		String codedby= Common.getCellDataProvider(data, "Coded By");
		String registeredto= Common.getCellDataProvider(data, "Registered to");
		String company= Common.getCellDataProvider(data, "Company");
		String contactname= Common.getCellDataProvider(data, "Contact Name");
		String acmanager= Common.getCellDataProvider(data, "AC Manager");
		String secondarydealer= Common.getCellDataProvider(data, "Secondary Dealer");
		String acexecutive= Common.getCellDataProvider(data, "AC Executive");
		String aeintroducer= Common.getCellDataProvider(data, "AE Introducer");
		String clientlist= Common.getCellDataProvider(data, "Client List");
		String campaigncode= Common.getCellDataProvider(data, "Campaign Code");
		String categorisation= Common.getCellDataProvider(data, "Categorisation");
		String subcategorisation= Common.getCellDataProvider(data, "Sub Categorisation");
		String website= Common.getCellDataProvider(data, "Website");
		String department= Common.getCellDataProvider(data, "Department");
		String inactivereason= Common.getCellDataProvider(data, "Inactive Reason");
		String campaignlabel= Common.getCellDataProvider(data, "Campaign Label");
		String clienttype= Common.getCellDataProvider(data, "Client Type");
		
		
		
		if (!clientcode.equalsIgnoreCase(""))
			driverMethod.inputText("txtClientCode", txtClientCode, clientcode);
		if (!legacyclientcode.equalsIgnoreCase(""))
			driverMethod.inputText("txtLegacyClientCode", txtLegacyClientCode, legacyclientcode);
		if (!company.equalsIgnoreCase(""))
			driverMethod.inputText("txtCompany", txtCompany, company);
		if (!contactname.equalsIgnoreCase(""))
			driverMethod.inputText("txtContactName", txtContactName, contactname);
		if (!campaigncode.equalsIgnoreCase(""))
			driverMethod.inputText("txtCampaignCode", txtCampaignCode, campaigncode);
		if (!website.equalsIgnoreCase(""))
			driverMethod.inputText("txtWebsite", txtWebsite, website);
		if (!campaignlabel.equalsIgnoreCase(""))
			driverMethod.inputText("txtCampaignLabel", txtCampaignLabel, campaignlabel);
		
		if (!codedby.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlCodedBy", ddlCodedBy, codedby);
		if (!registeredto.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlRegisteredTo", ddlRegisteredTo, registeredto);
		if (!acmanager.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlACManager", ddlACManager, acmanager);
		if (!secondarydealer.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlSecondaryDealer", ddlSecondaryDealer, secondarydealer);
		if (!acexecutive.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlACExecutive", ddlACExecutive, acexecutive);
		if (!aeintroducer.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlAEIntroducer", ddlAEIntroducer, aeintroducer);
		if (!clientlist.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlClientList", ddlClientList, clientlist);
		if (!categorisation.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlCategorisation", ddlCategorisation, categorisation);
		if (!subcategorisation.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlSubCategorisation", ddlSubCategorisation, subcategorisation);
		if (!department.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlDepartment", ddlDepartment, department);
		if (!inactivereason.equalsIgnoreCase(""))
			driverMethod.selectDDLByText("ddlInactiveReason", ddlInactiveReason, inactivereason);
		if (clienttype.equalsIgnoreCase("IBFX"))
			driverMethod.selectRadioButton("chkIBFX", chkIBFX);
		else if (clienttype.equalsIgnoreCase("Client"))
			driverMethod.selectRadioButton("chkClient", chkClient);
	}
	
	public void verifyDisplayFieldSimpleMode() throws Exception{
		driverMethod.isElementIsDisplayed("txtClientCode", txtClientCode, true);
		driverMethod.isElementIsDisplayed("txtLegacyClientCode", txtLegacyClientCode, true);
		driverMethod.isElementIsDisplayed("ddlCodedBy", ddlCodedBy, true);
		driverMethod.isElementIsDisplayed("ddlRegisteredTo", ddlRegisteredTo, true);
		driverMethod.isElementIsDisplayed("txtCompany", txtCompany, true);
		driverMethod.isElementIsDisplayed("txtContactName", txtContactName, true);
		driverMethod.isElementIsDisplayed("ddlACManager", ddlACManager, true);
		driverMethod.isElementIsDisplayed("ddlACExecutive", ddlACExecutive, true);
		driverMethod.isElementIsDisplayed("ddlAEIntroducer", ddlAEIntroducer, true);
		driverMethod.isElementIsDisplayed("ddlClientList", ddlClientList, true);
		driverMethod.isElementIsDisplayed("txtCampaignCode", txtCampaignCode, true);
		driverMethod.isElementIsDisplayed("ddlCategorisation", ddlCategorisation, true);
		driverMethod.isElementIsDisplayed("ddlSubCategorisation", ddlSubCategorisation, true);
		driverMethod.isElementIsDisplayed("txtWebsite", txtWebsite, true);
		driverMethod.isElementIsDisplayed("ddlDepartment", ddlDepartment, true);
		driverMethod.isElementIsDisplayed("ddlInactiveReason", ddlInactiveReason, true);
		driverMethod.isElementIsDisplayed("txtCampaignLabel", txtCampaignLabel, true);
		
		driverMethod.isElementIsDisplayed("ddlForexTurnover", ddlForexTurnover, false);
		driverMethod.isElementIsDisplayed("ddlTradeFrequency", ddlTradeFrequency, false);
		driverMethod.isElementIsDisplayed("ddlTradeSize", ddlTradeSize, false);
		driverMethod.isElementIsDisplayed("txtCreationDate", txtCreationDate, false);
		driverMethod.isElementIsDisplayed("txtCodedDateTime", txtCodedDateTime, false);
		driverMethod.isElementIsDisplayed("ddlThirdParties", ddlThirdParties, false);
		driverMethod.isElementIsDisplayed("ddlIndustry", ddlIndustry, false);
		driverMethod.isElementIsDisplayed("ddlTrading", ddlTrading, false);
		driverMethod.isElementIsDisplayed("ddlOpportunity", ddlOpportunity, false);
		driverMethod.isElementIsDisplayed("ddlBuyCategory", ddlBuyCategory, false);
		driverMethod.isElementIsDisplayed("ddlSellCategory", ddlSellCategory, false);
		driverMethod.isElementIsDisplayed("txtEmail", txtEmail, false);
		driverMethod.isElementIsDisplayed("ddlLeadMethod", ddlLeadMethod, false);
		driverMethod.isElementIsDisplayed("ddlLeadMedium", ddlLeadMedium, false);
		driverMethod.isElementIsDisplayed("ddlLeadSource", ddlLeadSource, false);
		driverMethod.isElementIsDisplayed("txtPhoneNumber", txtPhoneNumber, false);
		driverMethod.isElementIsDisplayed("ddlBDDOwner", ddlBDDOwner, false);
		driverMethod.isElementIsDisplayed("ddlAMLRisk", ddlAMLRisk, false);
	}

	public void verifyDisplayFieldAdvanceMode() throws Exception{
		driverMethod.isElementIsDisplayed("txtClientCode", txtClientCode, true);
		driverMethod.isElementIsDisplayed("txtLegacyClientCode", txtLegacyClientCode, true);
		driverMethod.isElementIsDisplayed("ddlCodedBy", ddlCodedBy, true);
		driverMethod.isElementIsDisplayed("ddlRegisteredTo", ddlRegisteredTo, true);
		driverMethod.isElementIsDisplayed("txtCompany", txtCompany, true);
		driverMethod.isElementIsDisplayed("txtContactName", txtContactName, true);
		driverMethod.isElementIsDisplayed("ddlACManager", ddlACManager, true);
		driverMethod.isElementIsDisplayed("ddlACExecutive", ddlACExecutive, true);
		driverMethod.isElementIsDisplayed("ddlAEIntroducer", ddlAEIntroducer, true);
		driverMethod.isElementIsDisplayed("ddlClientList", ddlClientList, true);
		driverMethod.isElementIsDisplayed("txtCampaignCode", txtCampaignCode, true);
		driverMethod.isElementIsDisplayed("ddlCategorisation", ddlCategorisation, true);
		driverMethod.isElementIsDisplayed("ddlSubCategorisation", ddlSubCategorisation, true);
		driverMethod.isElementIsDisplayed("txtWebsite", txtWebsite, true);
		driverMethod.isElementIsDisplayed("ddlDepartment", ddlDepartment, true);
		driverMethod.isElementIsDisplayed("ddlInactiveReason", ddlInactiveReason, true);
		driverMethod.isElementIsDisplayed("txtCampaignLabel", txtCampaignLabel, true);
		
		driverMethod.isElementIsDisplayed("ddlForexTurnover", ddlForexTurnover, true);
		driverMethod.isElementIsDisplayed("ddlTradeFrequency", ddlTradeFrequency, true);
		driverMethod.isElementIsDisplayed("ddlTradeSize", ddlTradeSize, true);
		driverMethod.isElementIsDisplayed("txtCreationDate", txtCreationDate, true);
		driverMethod.isElementIsDisplayed("txtCodedDateTime", txtCodedDateTime, true);
		driverMethod.isElementIsDisplayed("ddlThirdParties", ddlThirdParties, true);
		driverMethod.isElementIsDisplayed("ddlIndustry", ddlIndustry, true);
		driverMethod.isElementIsDisplayed("ddlTrading", ddlTrading, true);
		driverMethod.isElementIsDisplayed("ddlOpportunity", ddlOpportunity, true);
		driverMethod.isElementIsDisplayed("ddlBuyCategory", ddlBuyCategory, true);
		driverMethod.isElementIsDisplayed("ddlSellCategory", ddlSellCategory, true);
		driverMethod.isElementIsDisplayed("txtEmail", txtEmail, true);
		driverMethod.isElementIsDisplayed("ddlLeadMethod", ddlLeadMethod, true);
		driverMethod.isElementIsDisplayed("ddlLeadMedium", ddlLeadMedium, true);
		driverMethod.isElementIsDisplayed("ddlLeadSource", ddlLeadSource, true);
		driverMethod.isElementIsDisplayed("txtPhoneNumber", txtPhoneNumber, true);
		driverMethod.isElementIsDisplayed("ddlBDDOwner", ddlBDDOwner, true);
		driverMethod.isElementIsDisplayed("ddlAMLRisk", ddlAMLRisk, true);
	}
	
	public void clickBtnSearch() throws Exception{
		driverMethod.click("btnSearch", btnSearch);
	}
	public void clickBtnPrint() throws Exception{
		driverMethod.click("btnPrint", btnPrint);
	}
	public FindClientPage clickBtnOpen() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();		
		driverMethod.click("tblClientList", tblClientList(1));
		driverMethod.click("btnOpen", btnOpen);
		driverMethod.switchwindow(size);
		return new FindClientPage(driverMethod, data);
	}
	public void clickBtnResetSearch() throws Exception{
		driverMethod.click("btnReset", btnReset);
	}
	public void clickBtnSwitchMode() throws Exception{
		driverMethod.click("btnAdvanceSearch", btnAdvanceSearch);
	}
	public void verifySearchMode() throws Exception{
		verifyDisplayFieldSimpleMode();
		clickBtnSwitchMode();
		verifyDisplayFieldAdvanceMode();		
	}	
	public void verifyResetSearchButton() throws Exception{
		inputDataSearch();
		clickBtnResetSearch();
		verifyDefault();
	}
	public void verifySearchFunction() throws Exception{
		inputDataSearch();
		clickBtnSearch();
		Common.sleep(Constant.IMPLICIT_WAIT_TIME);
		String clientcode= Common.getCellDataProvider(data, "Client Code");
		String legacyclientcode= Common.getCellDataProvider(data, "Legacy Client Code");
//		String codedby= Common.getCellDataProvider(data, "Coded By");
		String registeredto= Common.getCellDataProvider(data, "Registered to");
		String company= Common.getCellDataProvider(data, "Company");
		String contactname= Common.getCellDataProvider(data, "Contact Name");
		String acmanager= Common.getCellDataProvider(data, "AC Manager");
//		String secondarydealer= Common.getCellDataProvider(data, "Secondary Dealer");
//		String acexecutive= Common.getCellDataProvider(data, "AC Executive");
//		String aeintroducer= Common.getCellDataProvider(data, "AE Introducer");
		String clientlist= Common.getCellDataProvider(data, "Client List");
		String campaigncode= Common.getCellDataProvider(data, "Campaign Code");
		String categorisation= Common.getCellDataProvider(data, "Categorisation");
		String subcategorisation= Common.getCellDataProvider(data, "Sub Categorisation");
		String website= Common.getCellDataProvider(data, "Website");
//		String department= Common.getCellDataProvider(data, "Department");
//		String inactivereason= Common.getCellDataProvider(data, "Inactive Reason");
		String campaignlabel= Common.getCellDataProvider(data, "Campaign Label");
//		String clienttype= Common.getCellDataProvider(data, "Client Type");
		
		int size = driverMethod.driver.findElements(tblAdvanceSearch).size();
		for (int i = 1; i<=size;i++){
			if(driverMethod.isContainText("tblClientList", tblClientList(i), clientlist) &&
				driverMethod.isContainText("tblClientCode", tblClientCode(i), clientcode)&&
				driverMethod.isContainText("tblLegacyClientCode", tblLegacyClientCode(i), legacyclientcode)&&
				driverMethod.isContainText("tblRegisteredTo", tblRegisteredTo(i), registeredto)&& 
				driverMethod.isContainText("tblCompany", tblCompany(i), company)&&
				driverMethod.isContainText("contactname", tblContactName(i), contactname)&&
				driverMethod.isContainText("tblACManager", tblACManager(i), acmanager)&&
				driverMethod.isContainText("tblCampaignCode", tblCampaignCode(i), campaigncode)&&
				driverMethod.isContainText("tblCategorisation", tblCategorisation(i), categorisation)&&		
				driverMethod.isContainText("tblSubCategorisation", tblSubCategorisation(i), subcategorisation)&&
				driverMethod.isContainText("tblWebsite", tblWebsite(i), website)&&
//				driverMethod.isContainText("tblInactiveReason", tblInactiveReason(i), inactivereason)&&
				driverMethod.isContainText("tblCampaignLabel", tblCampaignLabel(i), campaignlabel)) 
			Log.info("data correct");
			else{
				Log.error("Data incorrect");
				throw new Exception();
			}
		}
	}
	public void verifyPrintButton() throws Exception{
		inputDataSearch();
		clickBtnSearch();
		int size = driverMethod.driver.getWindowHandles().size();
		clickBtnPrint();
		driverMethod.switchwindow(size);
		driverMethod.waitForPresenceOfElementLocated(By.xpath("//*[@id='CrystalReportViewerBullet']"), Constant.DEFAULT_WAITTIME_SECONDS);
		String url = driverMethod.driver.getCurrentUrl();
		String temp[] = url.substring(url.lastIndexOf("?"), url.length()).split("&");
		driverMethod.verifyEqual(temp[1], Common.getCellDataProvider(data, "ReportName"));
	
	}
	public void verifyOpenButton() throws Exception{
		inputDataSearch();
		clickBtnSearch();
		FindClientPage findclient = clickBtnOpen();
		findclient.verifyOpenClient(Common.getCellDataProvider(data, "Client Code"), Common.getCellDataProvider(data, "Registered to"));
		
	
		
		
	}
	public void verifyDefault() throws Exception{
		driverMethod.verifyAttribute("txtClientCode", txtClientCode, "value", "");
		driverMethod.verifyAttribute("txtLegacyClientCode", txtLegacyClientCode, "value", "");
		driverMethod.verifyDisplayDDL("ddlCodedBy", ddlCodedBy, "");
		driverMethod.verifyDisplayDDL("ddlRegisteredTo", ddlRegisteredTo, "");
		driverMethod.verifyAttribute("txtCompany", txtCompany, "value", "");
		driverMethod.verifyAttribute("txtContactName", txtContactName, "value", "");
		driverMethod.verifyDisplayDDL("ddlACManager", ddlACManager, "");
		driverMethod.verifyDisplayDDL("ddlACExecutive", ddlACExecutive, "");
		driverMethod.verifyDisplayDDL("ddlAEIntroducer", ddlAEIntroducer, "");
		driverMethod.verifyDisplayDDL("ddlClientList", ddlClientList, "All");
		driverMethod.verifyAttribute("txtCampaignCode", txtCampaignCode, "value", "");
		driverMethod.verifyDisplayDDL("ddlCategorisation", ddlCategorisation, "ALL");
		driverMethod.verifyDisplayDDL("ddlSubCategorisation", ddlSubCategorisation,"ALL");
		driverMethod.verifyAttribute("txtWebsite", txtWebsite, "value", "");
		driverMethod.verifyDisplayDDL("ddlDepartment", ddlDepartment, "");
		driverMethod.verifyDisplayDDL("ddlInactiveReason", ddlInactiveReason, "");
		driverMethod.verifyAttribute("txtCampaignLabel", txtCampaignLabel, "value", "");
	}
}

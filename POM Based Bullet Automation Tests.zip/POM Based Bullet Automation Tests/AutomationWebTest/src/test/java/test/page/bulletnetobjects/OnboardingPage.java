package test.page.bulletnetobjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.nashtech.common.Common;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;


public class OnboardingPage {

	private WebDriverMethod driverMethod;
	//@SuppressWarnings("unused")
	private Object[] data;
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////                       Web Element Locators             ////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	String title = "Bullet - Index";
	private By chkBxCCBalanceSheet = By.xpath("//*[@id='BalanceSheet']");	
	private By chkBxCCAnnualTurnOver= By.xpath("//*[@id='AnnualTurnover']");	
	private By chkBxCCOwnFunds= By.xpath("//*[@id='OwnFunds']");	
	private By lstCCInstitutionType= By.xpath("//*[@id='cboInstitutionType']");	
	private By lstCCFinancialSB= By.xpath("//*[@id='cboFinancialBusinessService']");	
	private By txtCCFRNNumber= By.xpath("//*[@id='txtFrnNumber']");		
	private By lstCCClientClassification= By.xpath("//*[@id='cboClientClassification']");		
	private By txtCCData= By.xpath("//*[@id='txtClientClassComplianceDate']");	
	private By txtCCReasonForChange= By.xpath("//*[@id='txtClientClassComplianceReason']");	
	private By lstOBJForeignCurrency =By.xpath("//*[@id='cboCashFlowHedging']");
	private By lstOBJHedgingObjective =By.xpath("//*[@id='cboHedgingObjective']");
	private By lstRPInvestmentProducts =By.xpath("//*[@id='cboRiskProfile']");
	private By lstRPMaximunPeriod =By.xpath("//*[@id='cboHedgeRiskPeriod']");
	private By lstHPHedgingLast2Years = By.xpath("//*[@id='cboTwoYearsHedgingContracts']");
	private By chkBxHPKnockIn = By.xpath("//*[@id='KnockIn']");
	private By chkBxHPKnockOut = By.xpath("//*[@id='KnockOut']");	
	private By chkBxHPWindowBarrier = By.xpath("//*[@id='WindowBarriers']");
	private By chkBxHPLeveraged =By.xpath("//*[@id='Leverage']");
	private By chkBxHPBonus =By.xpath("//*[@id='Bonus']");	
	private By chkBxHPCombination =By.xpath("//*[@id='Combination']");
	private By chkBxHPBarrier =By.xpath("//*[@id='Barrier']");	
	private By chkBxHPVanilla =By.xpath("//*[@id='Vanilla']");	
	private By chkBxHPParticipatingForward =By.xpath("//*[@id='ParticipatingForward']");
	private By txtFPBusinessCost =By.xpath("//*[@id='cboDepositType']");	
	private By lstFPTypicalValue =By.xpath("//*[@id='cboTypicalHedgingValue']");	
	private By lstRPProfessionalExp =By.xpath("//*[@id='cboPreviousProfExperience']");
	private By lstRPAvgFXTransaction =By.xpath("//*[@id='cboTypicalAnnualFxTransactions']");
	private By lstRPLargestForeignExc =By.xpath("//*[@id='cboLargestFxTransaction']");
	private By lstRPSizeOfCurrentForeignExchnagePosition = By.xpath("//*[@id='cboCurrentFxPositionSize']");
	private By lstReportingDerivativeTrades =By.xpath("//*[@id='cboDelegatedReporting']");
	private By txtRPDate =By.xpath("//*[@id='txtDelegatedReportingStartDate']");
	private By txtRPLEICode =By.xpath("//*[@id='txtLeiCode']");
	private By txtRPLEIExpiryDate =By.xpath("//*[@id='txtLeiExpiryDate']");
	private By lstRPLEIRegisteredCountry = By.xpath("//*[@id='cboCountries']");
	private By chkBxRPTTCA =By.xpath("//*[@id='chkTtca']");
	private By lstFCCategorization =By.xpath("//*[@id='cboFcCategorisation']");
	private By lstProductClassDropdown =By.xpath("//*[@id='cboProductClass']");
	private By btnSave =By.xpath("//*[@id='cmdSaveOnBoarding']");
	private By btnEmail =By.xpath("//*[@id='cmdSendEmailCc']");	
	private By btnOnboradingConfirm =By.xpath("//div[@class='modal-content']/div[3]/button[1]");
	private By msgErrorMsgOnboarding=By.xpath("//div[@class='modal-content']/div[2]/div/table/tbody/tr/td[2]");
	private By btnErrorMsgOK=By.xpath("//div[@class='modal-content']/div[3]/button");
	private By lblOnboardingMsg =By.xpath("//td[contains(.,'The signup has been saved successfully')]");
	private By btnOKMsg =By.xpath("//div[@class='modal-footer']/button");
	public static By lblOnboardingLabels(int i) {
		return By.xpath("//*[@id='frmOnBoarding']/div[1]/h3["+i+"]");
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public OnboardingPage(WebDriverMethod driverMethod, Object[] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////            Methods to be used in Onboarding screen    /////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void verifyOnboadingPageTitle() throws Exception {
		driverMethod.verifyTitle(title);
	}
	public void verifyDropDownClientClassification() throws Exception {
		int count = 0;
		String[] exp = { "Professional - Per Se", "Retail", "Professional - Elected" };
		WebElement dropdown = driverMethod.driver.findElement(By.xpath("//*[@id='cboClientClassification']"));
		Select select = new Select(dropdown);
		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					Log.info("Expected DropDown value:" + we.getText() + " /////////////  Actual dropdown value:"+ exp[i]);
					TestngLogger.writeLog("Expected DropDown value:" + we.getText()+ " /////////////  Actual dropdown value:" + exp[i]);
					count++;
				}
			}
		}
		if (count == exp.length) {
			Log.info("First drop down displayed with correct values");
			TestngLogger.writeLog("First drop down displayed with correct values");
		} else {
			Log.error("First drop down list displayed incorrectly");
			TestngLogger.writeResult("First drop down list displayed incorrectly", false);
		}
	}	
	public void verifyClientClassification() throws Exception {
		driverMethod.findElement(chkBxCCBalanceSheet);
		driverMethod.findElement(chkBxCCAnnualTurnOver);
		driverMethod.findElement(chkBxCCOwnFunds);
		driverMethod.findElement(lstCCInstitutionType);
		driverMethod.findElement(lstCCFinancialSB);
		driverMethod.findElement(txtCCFRNNumber);
		driverMethod.findElement(lstCCClientClassification);
		driverMethod.findElement(txtCCData);
		driverMethod.findElement(txtCCReasonForChange);
	}
	public void verifyObjectives() throws Exception {
		driverMethod.findElement(lstOBJForeignCurrency);
		driverMethod.findElement(lstOBJHedgingObjective);
	}
	public void verifyRiskProfile() throws Exception{
		driverMethod.findElement(lstRPInvestmentProducts);
		driverMethod.findElement(lstRPMaximunPeriod);
	}
	public void verifyHistoricalProfile() throws Exception{
		driverMethod.findElement(lstHPHedgingLast2Years);
		driverMethod.findElement(chkBxHPKnockIn);
		driverMethod.findElement(chkBxHPKnockOut);
		driverMethod.findElement(chkBxHPWindowBarrier);
		driverMethod.findElement(chkBxHPLeveraged);
		driverMethod.findElement(chkBxHPBonus);
		driverMethod.findElement(chkBxHPCombination);
		driverMethod.findElement(chkBxHPBarrier);
		driverMethod.findElement(chkBxHPVanilla);
		driverMethod.findElement(chkBxHPParticipatingForward);
	}
	public void verifyFinacialProfile() throws Exception{
		driverMethod.findElement(txtFPBusinessCost);
		driverMethod.findElement(lstFPTypicalValue);
	}
	public void verifyResponsiblePerson() throws Exception{
		driverMethod.findElement(lstRPProfessionalExp);
		driverMethod.findElement(lstRPAvgFXTransaction);
		driverMethod.findElement(lstRPLargestForeignExc);
		driverMethod.findElement(lstRPSizeOfCurrentForeignExchnagePosition);
		driverMethod.findElement(lstReportingDerivativeTrades);
		driverMethod.findElement(txtRPDate);
		driverMethod.findElement(txtRPLEICode);
		driverMethod.findElement(txtRPLEIExpiryDate);
		driverMethod.findElement(lstRPLEIRegisteredCountry);
		driverMethod.findElement(chkBxRPTTCA);
		driverMethod.findElement(lstFCCategorization);
	}
	public void verifyProductClassDropdown() throws Exception{
		driverMethod.findElement(lstProductClassDropdown);
		int count = 0;
		String[] exp = { "Protect", "Participate", "Participate with ESS","Enhanced" };
		WebElement dropdown = driverMethod.driver.findElement(By.xpath("//*[@id='cboProductClass']"));
		Select select = new Select(dropdown);
		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			for (int i = 0; i < exp.length; i++) {
				if (we.getText().equals(exp[i])) {
					Log.info("Expected DropDown value:" + we.getText() + " /////////////  Actual dropdown value:"+ exp[i]);
					TestngLogger.writeLog("Expected DropDown value:" + we.getText()+ " /////////////  Actual dropdown value:" + exp[i]);
					count++;
				}
			}
		}
		if (count == exp.length) {
			Log.info("First drop down displayed with correct values");
			TestngLogger.writeLog("First drop down displayed with correct values");
		} else {
			Log.error("First drop down list displayed incorrectly");
			TestngLogger.writeResult("First drop down list displayed incorrectly", false);
		}	
	}
	public void verifySaveEmailButton() throws Exception{
		driverMethod.findElement(btnSave);
		driverMethod.findElement(btnEmail);
	}
	public void updateonboardingScreen() throws Exception{
 		driverMethod.selectDDLByText("InstitutionType", lstCCInstitutionType, Common.getCellDataProvider(data,"InstitutionType"));
 		driverMethod.selectDDLByText("FinancialSB", lstCCFinancialSB, Common.getCellDataProvider(data, "FinancialServicesBusiness"));
 		driverMethod.clear("FRN Number", txtCCFRNNumber);
 		driverMethod.sendkeys("FRN Number", txtCCFRNNumber, Common.getCellDataProvider(data, "FRNNumber")); 		
 		driverMethod.selectDDLByText("Client Classification", lstCCClientClassification, Common.getCellDataProvider(data, "ClientClassification")); 	
 		driverMethod.clear("CC Date", txtCCData);
 		driverMethod.sendkeys("Client Classification date", txtCCData, Common.getCellDataProvider(data, "CCDate"));
 		driverMethod.clear("Reason For Change", txtCCReasonForChange);
 		driverMethod.sendkeys("Reason For Change", txtCCReasonForChange, Common.getCellDataProvider(data, "ReasonForChange"));
 		driverMethod.selectDDLByText("Foreign Currency", lstOBJForeignCurrency, Common.getCellDataProvider(data, "ForeignCurrencyCashFlows")); 	
 		driverMethod.selectDDLByText("Hedging Objective", lstOBJHedgingObjective, Common.getCellDataProvider(data, "TypicalHedgingObjective")); 	
 		driverMethod.selectDDLByText("Risk investment Products", lstRPInvestmentProducts, Common.getCellDataProvider(data, "RiskinvestmentProducts"));
 		driverMethod.selectDDLByText("Maximum Period Hedge", lstRPMaximunPeriod, Common.getCellDataProvider(data, "MaximunPeriodHedge"));
 		driverMethod.selectDDLByText("Hedging Last 2Years", lstHPHedgingLast2Years, Common.getCellDataProvider(data, "HedgingLast2Years")); 		
 		driverMethod.selectDDLByText("Business Cost", txtFPBusinessCost, Common.getCellDataProvider(data, "FPBusinessCost"));
 		driverMethod.selectDDLByText("Typical Value", lstFPTypicalValue, Common.getCellDataProvider(data, "FPTypicalValue"));
 		driverMethod.selectDDLByText("Professional Exp", lstRPProfessionalExp, Common.getCellDataProvider(data, "RPProfessionalExp"));
 		driverMethod.selectDDLByText("Avg FXTransaction", lstRPAvgFXTransaction, Common.getCellDataProvider(data, "AvgFXTransaction"));
 		driverMethod.selectDDLByText("Largest ForeignExc", lstRPLargestForeignExc, Common.getCellDataProvider(data, "LargestForeignExc"));
 		driverMethod.selectDDLByText("Size Of Current Foreign Exc", lstRPSizeOfCurrentForeignExchnagePosition, Common.getCellDataProvider(data, "SizeOfCurrentForeignExc"));
 		driverMethod.selectDDLByText("Reporting Derivative Trades", lstReportingDerivativeTrades, Common.getCellDataProvider(data, "ReportingDerivativeTrades"));
 		driverMethod.clear("LEI Code", txtRPLEICode);
 		driverMethod.sendkeys("LEICode", txtRPLEICode, Common.getCellDataProvider(data, "LEICode"));
 		driverMethod.clear("LEI ExpiryDate", txtRPLEIExpiryDate);
 		driverMethod.sendkeys("LEI ExpiryDate", txtRPLEIExpiryDate, Common.getCellDataProvider(data, "LEIExpiryDate"));
 		driverMethod.selectDDLByText("LEI RegisteredCountry", lstRPLEIRegisteredCountry, Common.getCellDataProvider(data, "LEIRegisteredCountry"));
 		driverMethod.selectDDLByText("FC Categorization", lstFCCategorization, Common.getCellDataProvider(data, "FCCategorization"));
 		driverMethod.selectDDLByText("Product Class", lstProductClassDropdown, Common.getCellDataProvider(data, "ProductClass"));
 		driverMethod.clickByJS("Save Button", btnSave);
 		driverMethod.clickByJS("Save confirm", btnOnboradingConfirm);
	}
	public void validateOnboardingErrorMsg() throws Exception{
		driverMethod.waitForVisibilityOfElementLocated(msgErrorMsgOnboarding, 100);
		String Error=driverMethod.getText("ErrorMsgOnboarding", msgErrorMsgOnboarding);
		if (Error.contains(Common.getCellDataProvider(data, "ErrorMessage"))) {
			Log.info("Onboarding Error Message displaying correctly as expected");
			TestngLogger.writeResult("Onboarding Error Message displaying correctly as expected", true);
		}else {
			Log.error("Onboarding error message not displayed");
			TestngLogger.writeResult("Onboarding error message not displayed", false);
		}	
	}
	public void verifyOnboardingLabels() throws Exception{
		driverMethod.verifyText("Client Classification", lblOnboardingLabels(1),Common.getCellDataProvider(data,"ClientClassificationLabel"));
		driverMethod.verifyText("Objectives", lblOnboardingLabels(2),Common.getCellDataProvider(data, "Objectives"));		
		driverMethod.verifyText("Risk Profile", lblOnboardingLabels(3),Common.getCellDataProvider(data, "RiskProfile"));
		driverMethod.verifyText("Historical Profile", lblOnboardingLabels(4), Common.getCellDataProvider(data, "HistoricalProfile"));		
		driverMethod.verifyText("Financial Profile", lblOnboardingLabels(5),Common.getCellDataProvider(data, "FinancialProfile"));
		driverMethod.verifyText("Responsible Person", lblOnboardingLabels(6), Common.getCellDataProvider(data, "ResponsiblePerson"));		
		driverMethod.verifyText("Product Class", lblOnboardingLabels(7), Common.getCellDataProvider(data, "ProductClassLabel"));			
	}
	public void verifyDefaultListValue() throws Exception{
		driverMethod.verifyDisplayDDL("clientClassification", lstCCClientClassification,Common.getCellDataProvider(data, "Retail"));
		driverMethod.verifyDisplayDDL("productClass", lstProductClassDropdown,Common.getCellDataProvider(data, "Participate"));
	}
	public void clickTTCACheckbox() throws Exception{
		driverMethod.clickByJS("TTCA Check box", chkBxRPTTCA);
	}
	public void verifySave() throws Exception {
		driverMethod.clickByJS("Save button", btnSave);
		driverMethod.clickByJS("", btnOnboradingConfirm);
		driverMethod.verifyText("Verify Message", msgErrorMsgOnboarding,Common.getCellDataProvider(data, "ErrorMessage"));
		driverMethod.clickByJS("", btnErrorMsgOK);		
	}
	public void verifySaveDisabled() throws Exception{
		Boolean value = true;
		value = driverMethod.isElementEnable(btnSave);
		if(value.equals(false)) {
			Log.info("PASS: Save Button is disabled");
			TestngLogger.writeResult("PASS: Save Button is disabled", true);		
		}else {
			Log.error("FAIL: Save button is not disabled");
			TestngLogger.writeResult("FAIL: Save button is not disabled", false);
		}
	}
	public void verifyEmailDisabled() throws Exception{
		Boolean value = true;
		value = driverMethod.isElementEnable(btnEmail);
		if(value.equals(false)) {
			Log.info("PASS: Email Button is disabled");
			TestngLogger.writeResult("PASS: Email Button is disabled", true);		
		}else {
			Log.error("FAIL: Email button is not disabled");
			TestngLogger.writeResult("FAIL: Email button is not disabled", false);
		}
	}
	public void updateonboardingScreenNew() throws Exception{
 		driverMethod.selectDDLByText("InstitutionType", lstCCInstitutionType,Common.getCellDataProvider(data, "InstitutionType"));
 		driverMethod.selectDDLByText("FinancialSB", lstCCFinancialSB,Common.getCellDataProvider(data, "FinancialSB"));
 		driverMethod.clear("FRN Number", txtCCFRNNumber);
 		driverMethod.sendkeys("FRN Number", txtCCFRNNumber,Common.getCellDataProvider(data, "FRNNumber")); 		
 		driverMethod.selectDDLByText("Client Classification", lstCCClientClassification, Common.getCellDataProvider(data, "ClientClassification")); 	
 		driverMethod.clear("CC Date", txtCCData);
 		driverMethod.sendkeys("Client Classification date", txtCCData, Common.getCellDataProvider(data, "CCDate"));
 		driverMethod.sendkeys("Client Classification date", txtCCData,Keys.ENTER);
 		driverMethod.clear("Reason For Change", txtCCReasonForChange);
 		driverMethod.sendkeys("Reason For Change", txtCCReasonForChange,Common.getCellDataProvider(data, "Reason"));
 		driverMethod.selectDDLByText("Foreign Currency", lstOBJForeignCurrency,Common.getCellDataProvider(data, "ForeignCurrency")); 	
 		driverMethod.selectDDLByText("Hedging Objective", lstOBJHedgingObjective,Common.getCellDataProvider(data, "HedgingObjective")); 	
 		driverMethod.selectDDLByText("Risk investment Products", lstRPInvestmentProducts,Common.getCellDataProvider(data, "RiskinvestmentProducts"));
 		driverMethod.selectDDLByText("Maximum Period Hedge", lstRPMaximunPeriod,Common.getCellDataProvider(data, "MaximumPeriodHedge"));
 		driverMethod.selectDDLByText("Hedging Last 2Years", lstHPHedgingLast2Years,Common.getCellDataProvider(data, "HedgingLast2Years")); 		
 		driverMethod.selectDDLByValue("Business Cost", txtFPBusinessCost,Common.getCellDataProvider(data, "BusinessCost"));
 		driverMethod.selectDDLByText("Typical Value", lstFPTypicalValue,Common.getCellDataProvider(data, "TypicalValue"));
 		driverMethod.selectDDLByText("Professional Exp", lstRPProfessionalExp,Common.getCellDataProvider(data, "ProfessionalExp"));
 		driverMethod.selectDDLByText("Avg FXTransaction", lstRPAvgFXTransaction,Common.getCellDataProvider(data, "AvgFXTransaction"));
 		driverMethod.selectDDLByText("Largest ForeignExc", lstRPLargestForeignExc,Common.getCellDataProvider(data, "LargestForeignExc"));
 		driverMethod.selectDDLByText("Size Of Current Foreign Exc", lstRPSizeOfCurrentForeignExchnagePosition,Common.getCellDataProvider(data, "SizeOfCurrentForeignExc"));
 		driverMethod.selectDDLByText("Reporting Derivative Trades", lstReportingDerivativeTrades,Common.getCellDataProvider(data, "ReportingDerivativeTrades"));
 		driverMethod.clear("LEI Code", txtRPLEICode);
 		driverMethod.sendkeys("LEICode", txtRPLEICode,Common.getCellDataProvider(data, "RPLEICode"));
 		driverMethod.clear("LEI ExpiryDate", txtRPLEIExpiryDate);
 		driverMethod.sendkeys("LEI ExpiryDate", txtRPLEIExpiryDate,Common.getCellDataProvider(data, "LEIExpiryDate"));
 		driverMethod.sendkeys("LEI ExpiryDate", txtRPLEIExpiryDate,Keys.ENTER);
 		driverMethod.selectDDLByText("LEI RegisteredCountry", lstRPLEIRegisteredCountry,Common.getCellDataProvider(data, "LEIRegisteredCountry"));
 		driverMethod.selectDDLByText("FC Categorization", lstFCCategorization,Common.getCellDataProvider(data, "FCCategorization"));
 		driverMethod.selectDDLByText("Product Class", lstProductClassDropdown,Common.getCellDataProvider(data, "ProductClass"));
 		driverMethod.clickByJS("Save Button", btnSave);
 		driverMethod.clickByJS("Save confirm", btnOnboradingConfirm);
 		driverMethod.isElementIsDisplayed("lblOnboardingMsg", lblOnboardingMsg, true);
 		driverMethod.clickByJS("btnOKMsg", btnOKMsg);
 		
	}
	
	
	
 
  
	
	 
  
}

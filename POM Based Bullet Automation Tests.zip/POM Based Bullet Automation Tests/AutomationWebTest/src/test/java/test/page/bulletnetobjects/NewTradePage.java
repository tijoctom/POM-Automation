package test.page.bulletnetobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;
import com.nashtech.utils.report.HtmlReporter;
import com.nashtech.utils.report.TestngLogger;

public class NewTradePage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	
	private By txtInputDate = By.xpath("//*[@id='txtInputDate']");
	private By ddlClientCode = By.xpath("//*[@id='cboClientCode']");
	private By ddlClientName = By.xpath("//*[@id='cboClientName']");
//	private By txtFWTurnover = By.xpath("//*[@id='txtFWTurnover']");
	private By ddlAcManager = By.xpath("//*[@id='cboAcManager']");
	private By ddlSellCurr = By.xpath("//*[@id='cboSellCurr']");
	private By ddlBuyCurr = By.xpath("//*[@id='cboBuyCurr']");
	private By ddlNotationCurr = By.xpath("//*[@id='cboNotationCurr']");
	private By txtFxPrintAmount = By.xpath("//*[@id='txtFxPrintAmount']");
	private By txtFxPrintValueDate = By.xpath("//*[@id='txtFxPrintValueDate']");
	private By txtFXRate = By.xpath("//*[@id='txtFXRate']");
	private By ddlContractType = By.xpath("//*[@id='cboContractType']");
	private By ddlPromotion = By.xpath("//*[@id='cboPromotion']");
	private By ddlPaymentType = By.xpath("//*[@id='cboPaymentType']");
	private By ddlNoOfPayments = By.xpath("//*[@id='cboNoOfPayments']");
	private By ddlNoOfStrips = By.xpath("//*[@id='cboNoOfStrips']");
	private By chkInfoRequest = By.xpath("//*[@id='txtFxPrintInfoRequest']");
	private By chkDirectDebit = By.xpath("//*[@id='chkDirectDebit']");
	private By chkDirectDebitPayment = By.xpath("//*[@id='chkDirectDebitPayment']");
//	private By lsInstructionFrom = By.xpath("//tbody[tr[@id='instruction-from']]");
//	private By ddlThirdParties = By.xpath("//*[@id='cboThirdParties']");
	private By ddlRfpReasonForPaymentSelection = By.xpath("//*[@id='RfpReasonForPaymentSelection']");
	private By txtRfpReasonForPayment = By.xpath("//*[@id='RfpReasonForPayment']");
	private By btnPlus = By.xpath("//*[@id='StripsPlus']");
	private By btnEmail = By.xpath("//input[@id='cmdEmail']");
	
	private By txtMessage = By.xpath("//*[@class='jqimessage ']");
	private By txtMessage2 = By.xpath("//*[@class='modal-body']");
	
	private By btnInstructionFrom(String instructionFrom) {
		return By.xpath("//*[@id='instruction-from']//span[text()='" + instructionFrom + "']");
	}
	/*
	private By btnInstructionFrom(int location) {
		return By.xpath("//*[@id='instruction-from']/td["+location+"]/span");
	}
	private By tblTradeInformationDealNo(String rowNo) {
		return By.xpath("//*[@id='tblPrint']/tbody/tr[" + rowNo + "]/td[2]");
	}*/
	private By btnInstructionMethod(String instructionMethod) {
		return By.xpath("//*[@id='instruction-method-first-row']//span[text()='" + instructionMethod + "']");
	}
	private By tblTradeInformation(String rowNo) {
		return By.xpath("//*[@id='tblPrint']/tbody/tr[" + rowNo + "]");
	}
	public static By tblTradeInformationDealNo(String rowNo) {
		return By.xpath("//*[@id='tblPrint']/tbody/tr[" + rowNo + "]/td[2]");
	}
	
	private By tblBreachDealNo(int rowNo) {
		return By.xpath(".//*[@id='tblClientBreaches']/tbody/tr[" + rowNo + "]/td[4]");
	}
	
	private By tblBreachDealNoSort = By.xpath(".//*[@id='frmBreaches']//th[.='Deal No.']");
	private By tblBreachRow() {
		return By.xpath(".//*[@id='tblClientBreaches']/tbody/tr");
	}/*
	private By tblTradeInformationSelect(String rowNo) {
		String row = String.valueOf(Integer.parseInt(rowNo) - 1);
		return By.xpath("//*[@id='ckSelectTradeTicket_" + row + "']");
	}
	private By btnDeleteTrades = By.xpath("//*[@id='btnDeleteTrades']");	
	private By btnOk = By.xpath("//button[contains(.,'Ok')]");
	private By btnConfirm = By.xpath("//button[text()='Yes']");	
	private By btnSuspiciousAct = By.xpath("//*[@id='btnSuspiciousAct']");
	private By txtBreachReason = By.xpath("//*[@id='message']");
	private By lbPopup = By.xpath("//div [@class='modal-content']");
	private By tblAlertIDSort = By.xpath(".//*[@id='frmBreaches']//th[.='AlertID']");	
	private By tblBreachRow(String alert) {
	   return By.xpath("//*[@id='tblClientBreaches']/tbody/tr[td[.='"+alert+"']]");
	}
	private By tblBreachAlert(int rowNo) {
		   return By.xpath(".//*[@id='tblClientBreaches']/tbody/tr[" + rowNo + "]/td[7]");
	}
	private By tblBreachAlertNo(int rowNo) {
		   return By.xpath(".//*[@id='tblClientBreaches']/tbody/tr[" + rowNo + "]/td[1]");
	}	
	*/
	private By btnSaveTrades = By.xpath("//*[@id='btnSaveTrades']");
	private By btnClosePopup = By.xpath("//button[text()='Ok']");
	//////////////////////////////window forward//////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////
	private By txtfirstUtli = By.xpath("//*[@id='txtFxPrintFirstUtilisationDate']");
	private By btnNextAvaliDateOK = By.xpath("//div[@class='modal-content']/div[3]/button");
    private By lblClientPriceMessage =By.xpath("//div[@class='jqimessage ']/div//div[contains(.,'The Client Rate has not been entered correctly')]");
    private By lblFirstUtilMessage =By.xpath("//td[contains(.,'Please update 1st Utilisation Date for the updated Value Date')]");    
	///////////////////////////////////////////////////////////////////////////////////////
	public NewTradePage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void verifyDefault() throws Exception{
		Calendar cal = Calendar.getInstance();
		Date inputDate = cal.getTime();
        cal.setTime(inputDate);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String datadefaultquery = Common.getCellDataProvider(data, "SQL Default value").replace("@Compid", Common.getCellDataProvider(data, "Compid"));
        String datacurrencyquery = Common.getCellDataProvider(data, "SQL Currency").replace("@Compid", Common.getCellDataProvider(data, "Compid"))
        		.replace("@Groupid", Common.getCellDataProvider(data, "Groupid"));
        String datapaymenttypequery = Common.getCellDataProvider(data, "SQL Payment Type").replace("@Compid", Common.getCellDataProvider(data, "Compid"))
        		.replace("@Groupid", Common.getCellDataProvider(data, "Groupid"));
        String datadefault[][] = SqlServerJDBC.getValueInDatabase(datadefaultquery);
        String datacurrency[][] = SqlServerJDBC.getValueInDatabase(datacurrencyquery);
        String paymenttype = SqlServerJDBC.getValueInDatabase(datapaymenttypequery, "PaymentTypeID");
		// Verify default value of Input Date
		driverMethod.verifyAttribute("txtInputDate", txtInputDate, "value", sdf.format(inputDate));
		// Verify default value of Client Code
		driverMethod.verifyDisplayDDL("ddlClientCodeDefault", ddlClientCode, datadefault[0][0]);
		// Verify default value of Client Name
		driverMethod.verifyDisplayDDL("ddlClientNameDefault", ddlClientName, datadefault[0][1]);
		// Verify default value of AC Manager
		driverMethod.verifyDisplayValueDDL("ddlAcManagerDefault", ddlAcManager, datadefault[0][2]);
		// Verify default value of Sell Currency
		driverMethod.verifyDisplayValueDDL("ddlSellCurrDefault", ddlSellCurr, datacurrency[0][0]);
		// Verify default value of Buy Currency
		driverMethod.verifyDisplayValueDDL("ddlBuyCurrDefault", ddlBuyCurr, datacurrency[0][1]);
		// Verify default value of Notional Currency
		driverMethod.verifyDisplayValueDDL("ddlNotationCurrDefault", ddlNotationCurr, "Buy");
		// Verify default value of Amount
		driverMethod.verifyAttribute("txtFxPrintAmount", txtFxPrintAmount, "value", CommonObject.CurrencyAmount);
		// Verify default value of Client Price
		driverMethod.verifyText("txtFXRate", txtFXRate, CommonObject.EmptyValue);
		// Verify default value of Contract Type
		driverMethod.verifyDisplayDDL("ddlContractType", ddlContractType, CommonObject.ContractType);
		// Verify default value of Info Request		
		driverMethod.verifyStatusCheckbox("chkInfoRequest", chkInfoRequest, datadefault[0][1].equalsIgnoreCase("1")? true:false);
		// Verify default value of Direct Debit
		driverMethod.verifyStatusCheckbox("chkDirectDebit", chkDirectDebit, datadefault[0][1].equalsIgnoreCase("1")? true:false);
		// Verify default value of Pay By DD
		driverMethod.verifyStatusCheckbox("chkDirectDebitPayment", chkDirectDebitPayment, 
				CommonObject.PayByDD);
		// Verify default value of Promotion
		driverMethod.verifyDisplayDDL("ddlPromotion", ddlPromotion, 
				CommonObject.Promotion);
		// Verify default value of Payment Type 
		driverMethod.verifyDisplayValueDDL("ddlPaymentTypeDefault", ddlPaymentType, paymenttype);
		// Verify default value of No. of Payment
		driverMethod.verifyDisplayValueDDL("ddlNoOfPaymentsDefault", ddlNoOfPayments, CommonObject.NoOfPayment);
		// Verify default value of No. of Strips
		driverMethod.verifyDisplayValueDDL("ddlNoOfStripsDefault", ddlNoOfStrips, CommonObject.NoOfStrips);		
	}

	public void inputDate() throws Exception{
		// Select Buy Ccy
		driverMethod.selectDDLByText("ddlBuyCurr", ddlBuyCurr, Common.getCellDataProvider(data, "Buy Ccy"));
		// Select Sell Ccy
		driverMethod.selectDDLByText("ddlSellCurr", ddlSellCurr, Common.getCellDataProvider(data, "Sell Ccy"));
		// Input Value Date
		driverMethod.inputText("txtFxPrintValueDate", txtFxPrintValueDate, Common.getCellDataProvider(data, "Value Date"));
		driverMethod.sendkeys("txtFxPrintValueDate", txtFxPrintValueDate, Keys.ENTER);
	}
	public void inputDate(String date) throws Exception{
		// Select Buy Ccy
		driverMethod.selectDDLByText("ddlBuyCurr", ddlBuyCurr, Common.getCellDataProvider(data, "Buy Ccy"));
		// Select Sell Ccy
		driverMethod.selectDDLByText("ddlSellCurr", ddlSellCurr, Common.getCellDataProvider(data, "Sell Ccy"));
		// Input Value Date
		driverMethod.inputText("txtFxPrintValueDate", txtFxPrintValueDate, date);
		driverMethod.sendkeys("txtFxPrintValueDate", txtFxPrintValueDate, Keys.ENTER);
	}
	public void inputData() throws Exception{
		// Input amount 
		driverMethod.inputText("txtFxPrintAmount", txtFxPrintAmount, Common.getCellDataProvider(data, "Amount"));
		// Input Client Price 
		driverMethod.inputText("txtFXRate", txtFXRate, Common.getCellDataProvider(data, "Client Price"));	
	}
	public void clickPlusButton() throws Exception{
		driverMethod.click("btnPlus", btnPlus);
	}
	public void clickSaveButton() throws Exception{
		driverMethod.click("btnSaveTrades", btnSaveTrades);
	}
	public void selectInstruction() throws Exception{
		// Select Instruction Method
		if (!Common.getCellDataProvider(data, "Instruction From").equalsIgnoreCase("")){
		driverMethod.click("btnInstructionFrom", btnInstructionFrom(Common.getCellDataProvider(data, "Instruction From")));
		}
		// Select Instruction Method
		if (!Common.getCellDataProvider(data, "Instruction Method").equalsIgnoreCase("")){
			driverMethod.click("btnInstructionMethod", btnInstructionMethod(Common.getCellDataProvider(data, "Instruction Method")));
		}
		if (!Common.getCellDataProvider(data, "Reason for payment").equalsIgnoreCase("")){
			driverMethod.selectDDLByText("ddlRfpReasonForPaymentSelection", ddlRfpReasonForPaymentSelection, Common.getCellDataProvider(data, "Reason for payment"));
			if (Common.getCellDataProvider(data, "Reason for payment").equalsIgnoreCase("Other"))
				driverMethod.inputText("txtRfpReasonForPayment", txtRfpReasonForPayment, Common.getCellDataProvider(data, "Other Reason"));
		}
	}
	public void verifyInputDateValidation() throws Exception{
		//Verify warning message		
		if (!Common.getCellDataProvider(data, "Error Message").contains("The Value Date is a bad day"))
				driverMethod.verifyText("txtErrorMessage", txtMessage2, 
						Common.getCellDataProvider(data, "Error Message"));
		// verify error message for Value date: message + next value date
		else{
			driverMethod.verifyText("txtErrorMessage", txtMessage2,
					Common.getCellDataProvider(data, "Error Message")+" "+CommonObject.validDate(
							Common.getCellDataProvider(data, "Value Date"), 
							Common.getCellDataProvider(data, "Buy Ccy").split(",",2)[0], 
							Common.getCellDataProvider(data, "Sell Ccy").split(",",2)[0]
							)
					);
		}
	}
	
	public void verifyInputDateSuccess() throws Exception{
		// Verify Contract Type is changed according to value date
		driverMethod.verifyDisplayDDL("ddlContractTypeDefault", ddlContractType, Common.getCellDataProvider(data, "Payment Type"));
	}
	public void verifyPlusButtonValidation() throws Exception{
		inputData();
		clickPlusButton();
		verifyPopupMessage();
	}
	public void verifyPlusButtonSuccess() throws Exception{
		inputData();
		clickPlusButton();
		driverMethod.waitForVisibilityOfElementLocated(tblTradeInformation("1"), Constant.DEFAULT_WAITTIME_SECONDS);
	}	
	public void createNewTrade() throws Exception{
		inputData();
		clickPlusButton();
		selectInstruction();
		clickSaveButton();
	}
	public void verifySaveButtonValidation() throws Exception{
		createNewTrade();
		verifyPopupMessage();
	}
	public void verifySaveButtonSuccess() throws Exception{
		createNewTrade();
		boolean loop = true;
		while (loop){
			String message = driverMethod.getText("txtErrorMessageChangeDateAndSaveButton", txtMessage2);
			if (message.equalsIgnoreCase(Common.getCellDataProvider(data, "Message")))
				break;
			driverMethod.click("btnClosePopup", btnClosePopup);			
		} 
		verifyPopupMessage();
	}
	public void emailTradeDetail() throws Exception{
		createNewTrade();		
		while (driverMethod.isElementDisplayed(txtMessage2))			
			driverMethod.click("btnClosePopup", btnClosePopup);			
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.doubleClick("tblTradeInformation", tblTradeInformation("1"));
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnEmail", btnEmail);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnClosePopup", btnClosePopup);			
	}
	public void verifyPopupMessage() throws Exception{
		//driverMethod.waitForPresenceOfElementLocated(imgInfo, Constant.SMALL_WAITTIME_SECONDS);
		if (driverMethod.isElementDisplayed(txtMessage))
			driverMethod.verifyContainText("txtMessage", txtMessage, Common.getCellDataProvider(data,"Message"));
		else if (driverMethod.isElementDisplayed(txtMessage2))
			driverMethod.verifyContainText("txtMessage", txtMessage2, Common.getCellDataProvider(data,"Message"));
	}
	public void selectCCYPair(String buyccy, String sellccy) throws Exception{
		driverMethod.selectDDLByText("ddlBuyCurr", ddlBuyCurr, buyccy);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.selectDDLByText("ddlSellCurr", ddlSellCurr, sellccy);
	}
	public String createTradeDealNo() throws Exception{
		selectCCYPair(Common.getCellDataProvider(data, "BuyCCY"), Common.getCellDataProvider(data, "SellCCY"));
		inputData();
		clickPlusButton();
		selectInstruction();
		clickSaveButton();
		while (driverMethod.isElementDisplayed(txtMessage2))	
			driverMethod.click("btnClosePopup", btnClosePopup);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		String dealno; 
		String url= driverMethod.driver.getCurrentUrl();
		if (url.contains("/Compliance/Breaches")){
			driverMethod.click("tblBreachDealNoSort", tblBreachDealNoSort);
			int rowNo = driverMethod.driver.findElements(tblBreachRow()).size();
			dealno=driverMethod.getText("tblBreachDealNo",tblBreachDealNo(rowNo));
		}
		else
		dealno=driverMethod.getText("tblTradeInformationDealNo", tblTradeInformationDealNo("1"));
		driverMethod.closeOtherWindow();
		return dealno;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
///////////////////////////////          For Windows Forward             /////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void inputDataUtilDate() throws Exception {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		Date dateObject = cal.getTime();
		SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String valueDate = date.format(dateObject);
		Calendar cal2 = Calendar.getInstance();
		cal2.add(Calendar.DATE, 5);
		Date dateObject2 = cal2.getTime();
		SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String firstUtilization = date2.format(dateObject2);
		com.nashtech.utils.report.Log.info("valueDate" + valueDate);
		com.nashtech.utils.report.Log.info("firstUtilization" + firstUtilization);
		// Input amount
		driverMethod.inputText("txtFxPrintAmount", txtFxPrintAmount, Common.getCellDataProvider(data, "Amount"));
		// Input Client Price
		driverMethod.inputText("txtFXRate", txtFXRate, Common.getCellDataProvider(data, "Client Price"));
		// Input value date
		driverMethod.inputText("txtFxPrintValueDate", txtFxPrintValueDate, valueDate);
		driverMethod.sendkeys("txtFxPrintValueDate", txtFxPrintValueDate, Keys.ENTER);
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}
		// Log.info(""+);
		driverMethod.inputText("txtfirstUtli", txtfirstUtli, firstUtilization);
		driverMethod.sendkeys("txtfirstUtli", txtfirstUtli, Keys.ENTER);
		// Log.info("Click on the element: [" + elementName + "]");
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}
	}


	public String createTradeDealNoWithUtilDate() throws Exception {
		selectCCYPair(Common.getCellDataProvider(data, "BuyCCY"), Common.getCellDataProvider(data, "SellCCY"));
		inputDataUtilDate();
		clickPlusButton();
		selectInstruction();
		clickSaveButton();
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		while (driverMethod.isElementDisplayed(txtMessage2))
			driverMethod.click("btnClosePopup", btnClosePopup);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		String dealno;
		String url = driverMethod.driver.getCurrentUrl();
		if (url.contains("/Compliance/Breaches")) {
			driverMethod.click("tblBreachDealNoSort", tblBreachDealNoSort);
			int rowNo = driverMethod.driver.findElements(tblBreachRow()).size();
			dealno = driverMethod.getText("tblBreachDealNo", tblBreachDealNo(rowNo));
		} else
			dealno = driverMethod.getText("tblTradeInformationDealNo", tblTradeInformationDealNo("1"));
		driverMethod.closeOtherWindow();
		TestngLogger.writeResult("Tread deal created. Deal Number" + dealno, true);
		HtmlReporter.pass("Tread deal created. Deal Number" + dealno);
		return dealno;
	}
	///////////////////////////////////   window forward /////////////////////////////////////////////////
	public void verifyFieldMandatoryMessage() throws Exception {
		driverMethod.clear("", txtFxPrintAmount);
		driverMethod.sendkeys("Amount", txtFxPrintAmount, Common.getCellDataProvider(data, "Amount"));
		driverMethod.clickByJS("Plus button", btnPlus);
		if(driverMethod.isElementPresent(lblClientPriceMessage)){
			TestngLogger.writeResult("Pass: Client Rate error message is displayed as expected", true);
		}else {
			TestngLogger.writeResult("Fail: Client rate error message is not displayed", false);
		}
		driverMethod.clickByJS("OK Button", btnClosePopup);	
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 10);
		Date dateObject = cal.getTime();
		SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String valueDate = date.format(dateObject);
		// Input value date
		driverMethod.inputText("ValueDate", txtFxPrintValueDate, valueDate);
		driverMethod.sendkeys("ValueDate", txtFxPrintValueDate,Keys.ENTER );
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}
		driverMethod.sendkeys("Client Price", txtFXRate, "1.2");
		driverMethod.clickByJS("Plus button", btnPlus);  
		if(driverMethod.isElementPresent(lblFirstUtilMessage)){
			TestngLogger.writeResult("Pass: FirstUtil date error message is displayed as expected", true);
		}else {
			TestngLogger.writeResult("Fail: FirstUtil date error message is not displayed", false);
		}
		driverMethod.clickByJS("OK Button", btnClosePopup);		
	}
	public void verifyFirstUtilisationDateGRM() throws Exception{
		
		if (!driverMethod.isElementPresent(txtfirstUtli)) {
			 TestngLogger.writeLog("PASS: First utilisation date is not present for GRM ");
		}else {
			TestngLogger.writeResult("FAIL: First utilisation date is present for GRM", false);
		}
	}
	public void createTradeDealNoNew() throws Exception {
		selectCCYPair(Common.getCellDataProvider(data, "BuyCCY"), Common.getCellDataProvider(data, "SellCCY"));
		inputData();
		clickPlusButton();
		selectInstruction();
		clickSaveButton();
		if (driverMethod.isElementDisplayed(txtMessage2)) {
			driverMethod.click("btnClosePopup", btnClosePopup);
			if (driverMethod.isElementDisplayed(btnClosePopup)) {
				driverMethod.click("btnClosePopup", btnClosePopup);
			}
		}
	}
	public void inputSpotData()throws Exception{
		driverMethod.inputText("txtFxPrintAmount", txtFxPrintAmount, Common.getCellDataProvider(data, "Amount"));
		// Input Client Price 
		driverMethod.inputText("txtFXRate", txtFXRate, Common.getCellDataProvider(data, "Client Price"));	
	}
	public void saveSpot() throws Exception {
		inputSpotData();
		clickPlusButton();
		selectInstruction();
		clickSaveButton();
		while (driverMethod.isElementDisplayed(txtMessage2))
		driverMethod.click("btnClosePopup", btnClosePopup);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
	}
	
	
}


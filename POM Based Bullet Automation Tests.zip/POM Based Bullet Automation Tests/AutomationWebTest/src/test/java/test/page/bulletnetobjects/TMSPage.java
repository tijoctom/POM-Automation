package test.page.bulletnetobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

import test.common.WebProjectConstant;

public class TMSPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	private By txtSearch = By.xpath("//input[@id='txtAlertId']");
	private By txtReason = By.xpath("//textarea[@id='txtReason']");
	private By txtAction = By.xpath("//textarea[@id='txtAction']");
	private By cmdAccept = By.xpath("//input[@id='cmdAccept']");
	private By cmdReject = By.xpath("//input[@id='cmdReject']");
	private By cmdSave = By.xpath("//input[@id='cmdSave']");	
	//private By btnYes = By.xpath("//button[contains(@id,'buttonYes')]");
	private By lblMessage = By.xpath("//*[@id='jqistate_state0']/div[2]//tr/td[2]");
	private By btnOk = By.xpath("//button[contains(.,'Ok')]");	
	//private By btnRefresh = By.xpath("//input[@value='Refresh']");	
	private By AlertFirstLabel = By.xpath("//*[@id='tblClientBreaches']//tbody/tr[1]/td[1]");
	private By AlertFirstLabelDetails(int column){
		return By.xpath("//*[@id='tblClientBreaches']//tbody/tr[1]/td["+column+"]");
	}
	private By AlertLabel (String alertid){
		return By.xpath("//*[@id='tblClientBreaches']//td[contains(.,'" + alertid + "')]");
	}
	private By ddlReport = By.xpath("//select[@id='cboReport']");
	private By btnPreview = By.xpath(".//*[@id='tblFilter']//input[@value='Preview']");
	private By btnRefresh = By.xpath(".//*[@id='tblFilter']//input[@value='Refresh']");
	private By btnDelete = By.xpath(".//*[@id='tblFilter']//input[@value='Delete']");
	private By btnReport = By.xpath(".//*[@id='tblFilter']//input[@value='Report']");
	private By btnYes = By.xpath("//button[text()='Yes']");	
	
	private By txtMessage = By.xpath("//*[contains(@class,'jqimessage')]//td[2]");	
	private By txtMessage2 = By.xpath("//*[contains(@class,'bootbox-body')]//td[2]");	
	
	private By lblAlertFieldset = By.xpath("//table/tbody/tr[3]/td/fieldset");	
	private By lblClientCode = By.xpath("//fieldset/table/tbody/tr[1]/td[2]/span");	
	private By lblClientName = By.xpath("//fieldset/table/tbody/tr[2]/td[2]/span");	
	private By lblAlertID = By.xpath("//fieldset/table/tbody/tr[5]/td[2]/span");
	
	
	public TMSPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void verifyAcceptTMS() throws Exception{
		driverMethod.click("AlertLabel", AlertFirstLabel);
		// Enter the reason
		driverMethod.inputText("txtReason", txtReason, Common.getCellDataProvider(data,"Reason"));
		// Enter the action
		driverMethod.inputText("txtAction", txtAction, Common.getCellDataProvider(data,"Action"));
		// Click on the accept button
		driverMethod.click("cmdAccept", cmdAccept);
		// Click on Yes button
		driverMethod.click("btnYes", btnYes);
		// Verify the message
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"Verify"));	
	}
	public void verifyAlertUpdateData() throws Exception{
		// Click on the alert label
		driverMethod.click("AlertLabel", AlertFirstLabel);
		String alertid=driverMethod.getText("AlertLabel", AlertFirstLabel);
		String clientcode=driverMethod.getText("AlertLabel", AlertFirstLabelDetails(2));
		String clientname=driverMethod.getText("AlertLabel", AlertFirstLabelDetails(3));
		// Verify the message
		driverMethod.verifyText("lblClientCode", lblClientCode, clientcode);
		driverMethod.verifyText("lblClientName", lblClientName, clientname);
		driverMethod.verifyText("lblAlertFieldset", lblAlertID, alertid);
	}
	public void verifyTMSDelete() throws Exception{
		driverMethod.click("AlertLabel", AlertFirstLabel);
		// Click button Delete
		driverMethod.click("btnDelete", btnDelete);
		driverMethod.click("btnYes", btnYes);
		// Verify success message
		driverMethod.verifyText("txtMessage", txtMessage, Common.getCellDataProvider(data, "Message"));
		
	}
	public void verifyTMSPreview() throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String date = sdf.format(Calendar.getInstance().getTime());
	
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnPreview", btnPreview);
		// Switch window
		driverMethod.switchwindow(size);
		String url = driverMethod.driver.getCurrentUrl();
		url=url.substring(url.indexOf('?')+1);
		String s[] = url.split("&");
		// Verify url is opened correctly
		driverMethod.compareText("URL", s[0], "dateFrom="+date);
		driverMethod.compareText("URL", s[1], "dateTo="+date);
		driverMethod.compareText("URL", s[2], Common.getCellDataProvider(data, "Report name"));
		driverMethod.compareText("URL", s[3], Common.getCellDataProvider(data, "View Type"));
	}
	
	public void verifyTMSReject() throws Exception{
		// Click on the alert label		
		driverMethod.click("AlertLabel", AlertFirstLabel);		
		// Enter the reason
		driverMethod.inputText("txtReason", txtReason, Common.getCellDataProvider(data,"Reason"));
		// Enter the action
		driverMethod.inputText("txtAction", txtAction, Common.getCellDataProvider(data,"Action"));
		// Click on the accept button
		driverMethod.click("cmdReject", cmdReject);
		// Click on Yes button
		driverMethod.click("btnYes", btnYes);
		// Verify the message
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"Verify"));
		
	}
	public void verifySave() throws Exception{
		// Click on the alert label		
		driverMethod.click("AlertLabel", AlertFirstLabel);		
		// Enter the reason
		driverMethod.inputText("txtReason", txtReason, Common.getCellDataProvider(data,"Reason"));
		// Enter the action
		driverMethod.inputText("txtAction", txtAction, Common.getCellDataProvider(data,"Action"));
		// Click on the accept button
		driverMethod.click("cmdSave", cmdSave);
		// Verify the message
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"Verify"));
		
	}
	public void verifyReportInvalid() throws Exception{
		if (driverMethod.isElementPresent(btnOk))
			driverMethod.click("btnOk", btnOk);		
		driverMethod.click("btnReport", btnReport);
		// Verify success message
		driverMethod.verifyText("txtMessage", txtMessage2, Common.getCellDataProvider(data, "Message"));
		
	}
	public void verifyReportValid() throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String date = sdf.format(Calendar.getInstance().getTime());
	
		// Select Report view
		driverMethod.selectDDLByText("ddlReport", ddlReport, Common.getCellDataProvider(data, "Report View"));
		// Click button report
		driverMethod.closeOtherWindow();
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnReport", btnReport);
		driverMethod.switchwindow(size);
		String url = driverMethod.driver.getCurrentUrl();
		url=url.substring(url.indexOf('?')+1);
		String s[] = url.split("&");
		// Verify url is opened correctly
		driverMethod.compareText("URL", s[0], "screenSource=TmsReport");
		driverMethod.compareText("URL", s[1], "dateFrom="+date);
		driverMethod.compareText("URL", s[2], "dateTo="+date);
		driverMethod.compareText("URL", s[3], Common.getCellDataProvider(data, "Report Name"));
		driverMethod.switchwindow();
		driverMethod.closeOtherWindow();
		
	}
		
		

}

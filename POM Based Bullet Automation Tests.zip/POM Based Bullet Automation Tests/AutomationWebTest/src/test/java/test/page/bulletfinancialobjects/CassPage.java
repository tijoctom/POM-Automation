package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebProjectConstant;
import test.page.bulletnetobjects.CommonObject;

public class CassPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By btncassIBR = By.xpath(".//*[@id='cassIBR']");	
	private By btnchkAgree = By.xpath(".//*[@id='chkAgree']");
	private By btnConfirm = By.xpath(".//*[@id='btnConfirm']");
	private By btnConfirmPopup = By.xpath("//h4[contains(.,'Internal Business Reconciliation')]");
	private By btnInternalCass = By.xpath(".//*[@id='btnInternalCass']");
	private By btnExternalCass = By.xpath("//input[@value='External CASS']");
	
	private By txtComment = By.xpath(".//*[@id='txtComment']");
	private By btnSaveComment = By.xpath(".//*[@id='btnSaveComment']");
	private By lblVerify = By.xpath(".//*[@id='jqistate_state0']//td[2]");
//	private By tblAmountInBank = By.xpath(".//*[@id='tblAmountInBank']");
	private By tblAmountInBankBroker = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[1]/select");
	private By tblAmountInBankCCY = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[2]/select");
	private By tblAmountInBankAMT = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[3]/input");
	private By tblAmountInBankGBPAMT = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[4]/input");
	private By tblAmountInBankFromACC = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[5]/select");
	private By tblAmountInBankToACC = By.xpath(".//*[@id='tblAmountInBank']/tbody/tr[2]/td[6]/select");
	
	private By btnAdd = By.xpath(".//*[@id='btnAdd']");		
	private By txtAmt = By.xpath("//table/tbody/tr[2]/td[3]/input");
//	private By txtVal = By.xpath("//table/tbody/tr[2]/td[4]/input");
//	private By txtGBPVal = By.xpath("//table/tbody/tr[2]/td[4]/input");
	private By btnSubmit = By.xpath(".//*[@id='btnSubmit']");
//	private By lblSubmitVerify = By.xpath("//table/tbody/tr/td[2]");
	private By lblSubmitButtonVerify = By.xpath("//*[@id='jqistate_state0']/div[2]/table/tbody/tr/td[2]");
	private By btnOK = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");
	
	private By txtCommentBox = By.xpath("//*[@id='txtComment']");
	private By btnSubmitComment = By.xpath("//*[@id='btnSaveCmt']");
	private By txtCommentHistory = By.xpath("//*[@id='tblHistoricComment']");
	private By btnImport = By.xpath("//*[@id='tblFileNames']/tbody/tr/td[1]/label");
	private By txtImportSuccess = By.xpath("//*['@id=tblFileNames']/tbody/tr[1]/td[2]/p");
	private By txtBankAccount = By.xpath(".//*[@id='cbbBankAccount']");
	private By txtExternalBankAmount = By.xpath(".//*[@id='txtExternalBankAmount']");
	private By btnAddExternalBank = By.xpath(".//*[@id='btnAddExternalBank']");
	private By lblVerifyValueAdded = By.xpath(".//*[@id='tblExternalBank']/tbody/tr/td[2]");
	private By btnSubmitExternal = By.xpath(".//*[@id='btnSubmit']");

	public CassPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public static void precondition() throws Exception{
		String sql[] = new String[10];
		sql[1] = "delete from tblCASSInternalSnapShotInternalBankBalances";
		sql[2] = "delete from tblCASSExternalSnapShotExternalBankBalances";
		sql[3] = "delete from tblCASSDailyBankSnapShotMain";
		sql[4] = "delete from tblCASSInternalClientDetails";
		sql[5] = "delete from tblCASSInternalSnapShotDetail";
		sql[6] = "delete from tblCASSSignOffSnapShot";
		sql[7] = "delete from tblCASSExternalSnapShotFileName";
		sql[8] = "delete from tblCASSComments";
		sql[9] = "delete from tblCASSInternalBusinessReconciledLog";
		sql[0] = "delete from tblCASSExternalLogMain";
		SqlServerJDBC.getConnection();
		for (int i =0; i<10;i++)
			SqlServerJDBC.executeQuery(sql[i]);;
	}
	public void cassIBR() throws Exception{				
		// Click on cassIBR
		driverMethod.click("btncassIBR", btncassIBR);
		// Click on chkAgree
		driverMethod.waitForVisibilityOfElementLocated(btnConfirmPopup, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("chkAgree", btnchkAgree);
		// Click on Confirm button
		driverMethod.click("btnConfirm", btnConfirm);
		// Wait 60s
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
	
	}
	public void navigateInternalCass() throws Exception{
		driverMethod.click("btnInternalCass", btnInternalCass);		
	}
	public void verifyInternalCassAddRecord() throws Exception{

		driverMethod.click("btnInternalCass", btnInternalCass);
		// Click on button Add
		driverMethod.click("btnAdd", btnAdd);
		driverMethod.isElementIsDisplayed("tblAmountInBankAMT", tblAmountInBankAMT,  true);
		driverMethod.isElementIsDisplayed("tblAmountInBankGBPAMT", tblAmountInBankGBPAMT, true);
		driverMethod.isElementIsDisplayed("tblAmountInBankBroker", tblAmountInBankBroker,  true);
		driverMethod.isElementIsDisplayed("tblAmountInBankCCY", tblAmountInBankCCY, true);
		driverMethod.isElementIsDisplayed("tblAmountInBankFromACC", tblAmountInBankFromACC, true);
		driverMethod.isElementIsDisplayed("tblAmountInBankToACC", tblAmountInBankToACC, true);	
		// Enter Ant
		/*
		String Ant = Common.getCellDataProvider(data,"Ant");
		driverMethod.sendkeys("txtAmt", txtAmt, Ant);
		driverMethod.sendkeyboard("txtAmt", txtAmt, Keys.TAB);			
		String Broker	= Common.getCellDataProvider(data,"Broker");
		String CCY	= Common.getCellDataProvider(data,"CCY");
		String BankAMT	= Common.getCellDataProvider(data,"BankAMT");
		String BankGMPAMT	= Common.getCellDataProvider(data,"BankGMPAMT");
		String FromACC	= Common.getCellDataProvider(data,"FromACC");
		String ToACC= Common.getCellDataProvider(data,"ToACC");		
		driverMethod.verifyAttribute("tblAmountInBankAMT", tblAmountInBankAMT, "value", BankAMT);
		driverMethod.verifyAttribute("tblAmountInBankGBPAMT", tblAmountInBankGBPAMT, "value", BankGMPAMT);
		driverMethod.verifyDisplayDDL("tblAmountInBankBroker", tblAmountInBankBroker,  Broker);
		driverMethod.verifyDisplayDDL("tblAmountInBankCCY", tblAmountInBankCCY, CCY);
		driverMethod.verifyDisplayDDL("tblAmountInBankFromACC", tblAmountInBankFromACC, FromACC);
		driverMethod.verifyDisplayDDL("tblAmountInBankToACC", tblAmountInBankToACC, ToACC);	
		*/
	}
	public void verifyInternalCassSaveComment() throws Exception{
		String comment = Common.getCellDataProvider(data,"Comment");
		String verify = Common.getCellDataProvider(data,"Verify");
		driverMethod.click("btnInternalCass", btnInternalCass);
		// Input the comment		
		driverMethod.sendkeys("txtComment",  txtComment,comment );
		// Click on submit button
		driverMethod.click("btnSaveComment", btnSaveComment);
		// Verify the results;
		driverMethod.waitForVisibilityOfElementLocated(lblVerify, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lblVerify", lblVerify,verify);
	}
	public void verifyInternalCassSubmit() throws Exception{
		driverMethod.click("btnInternalCass", btnInternalCass);
		// Click on button Add
		driverMethod.click("btnAdd", btnAdd);
		// Enter Ant
		String Ant = Common.getCellDataProvider(data,"Ant");
		driverMethod.sendkeys("txtAmt", txtAmt, Ant);
		driverMethod.sendkeys("txtAmt", txtAmt, Ant);			
		// Input the comment
		String Comment = Common.getCellDataProvider(data,"Comment");		
		driverMethod.inputText("txtComment",  txtComment, Comment);
		// Click on submit button
		driverMethod.click("btnSaveComment", btnSaveComment);
		// Verify the results
		driverMethod.verifyText("lblVerify", lblVerify,Common.getCellDataProvider(data,"VerifyComment"));
		driverMethod.click("btnOK", btnOK);		
		// Click on submit button
		driverMethod.click("btnSubmit", btnSubmit);
		driverMethod.click("chkAgree", btnchkAgree);
		// Click on Confirm button
		driverMethod.click("btnConfirm", btnConfirm);			
		// Verify the result
		String Verify = Common.getCellDataProvider(data,"Verify");
		driverMethod.waitForVisibilityOfElementLocated(lblSubmitButtonVerify, Constant.DEFAULT_WAITTIME_SECONDS);		
		driverMethod.verifyText("lblSubmitButtonVerify", lblSubmitButtonVerify, Verify);	
		driverMethod.click("btnOK", btnOK);
	}
	public void verifyExternalAddbank() throws Exception{
		driverMethod.click("btnExternalCass", btnExternalCass);
        // Select the bank
        String value1 = Common.getCellDataProvider(data, "Value1");
        driverMethod.sendkeys("txtBankAccount", txtBankAccount, value1); 
        // Send value to BankAmount
        String ExternalBankAmount = Common.getCellDataProvider(data, "ExternalBankAmount");
        driverMethod.sendkeys("txtExternalBankAmount", txtExternalBankAmount, ExternalBankAmount);        
        // Click on Add button
        driverMethod.click("btnAddExternalBank", btnAddExternalBank);       
        // Verify value added
        String VerifyValueAdded = Common.getCellDataProvider(data, "VerifyValueAdded");
        driverMethod.waitForVisibilityOfElementLocated(lblVerifyValueAdded, Constant.DEFAULT_WAITTIME_SECONDS);
        driverMethod.verifyText("lblVerifyValueAdded", lblVerifyValueAdded, VerifyValueAdded);
	
	}
	public void verifyExternalSaveComment() throws Exception{
		String CommentField = Common.getCellDataProvider(data,"Comment");		
		driverMethod.inputText("txtComment",  txtCommentBox, CommentField);
		// Click on submit comment button	
		driverMethod.click("btnSubmitComment", btnSubmitComment);
		// Verify the comment value	
		String CommentHistoryContainText = Common.getCellDataProvider(data,"CommentHistoryContainText");
		driverMethod.waitForVisibilityOfElementLocated(txtCommentHistory, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyContainText("CommentHistoryContainText", txtCommentHistory, CommentHistoryContainText);
		
	}
	public void verifyExternalSubmit() throws Exception{
		// Click on cassIBR
		driverMethod.click("btnExternalCass", btnExternalCass);							
		String CommentField = Common.getCellDataProvider(data,"Comment");		
		driverMethod.inputText("txtComment",  txtCommentBox, CommentField);
		// Click on submit comment button	
		driverMethod.click("btnSubmitComment", btnSubmitComment);
		driverMethod.waitForVisibilityOfElementLocated(txtCommentHistory, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.getText("txtCommentHistory", txtCommentHistory);
	
		int arr[]={122000,122001,122002,122003,122004,122005,122006,122007,122008,122009,122010,122011,122012,122014,122016,122017,122020,122022,122024,122025,122026,122031,122032,122041};  
		for(int i:arr){  
			 // Select the bank		
			String valueBankAccount = String.valueOf(i);     
			driverMethod.selectDDLByText("txtBankAccount", txtBankAccount, valueBankAccount);	        
	        // Send value to BankAmount
	        String ExternalBankAmount = Common.getCellDataProvider(data, "ExternalBankAmount");
	        driverMethod.clear("txtExternalBankAmount", txtExternalBankAmount);	       
	        driverMethod.sendkeys("txtExternalBankAmount", txtExternalBankAmount, ExternalBankAmount);
	        // Click on Add button
	        driverMethod.click("btnAddExternalBank", btnAddExternalBank);      
		}
       			// Click on Add button
        String url = Common.getCellDataProvider(data, "Upload URL");
		url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + url;
		
		driverMethod.uploadfile(btnImport, url);	
		driverMethod.waitForVisibilityOfElementLocated(txtImportSuccess, Constant.DEFAULT_WAITTIME_SECONDS);
        driverMethod.click("btnSubmitExternal", btnSubmitExternal);               
        driverMethod.verifyAttribute("btnSubmitComment", btnSubmitComment, "disabled", "true");
    
	}
	public void verifyExternalAddfile() throws Exception{
		driverMethod.click("btnExternalCass", btnExternalCass);
		String CommentField = Common.getCellDataProvider(data,"Comment");		
		driverMethod.inputText(" ",  txtCommentBox, CommentField);
		// Click on submit comment button	
		driverMethod.click("btnSubmitComment", btnSubmitComment);
		driverMethod.getText("txtCommentHistory", txtCommentHistory);
		
		// Click on Add button
		String url = Common.getCellDataProvider(data, "Upload URL");
		url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + url;
		driverMethod.uploadfile(btnImport, url);		
			
		// Verify uploaded
		String verifyImage = Common.getCellDataProvider(data, "VerifyImage");
		driverMethod.waitForVisibilityOfElementLocated(txtImportSuccess, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("txtImportSuccess", txtImportSuccess, verifyImage);        
	
	}
}

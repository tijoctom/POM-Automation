package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;


public class SearchFXTrade{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtTradeSearch = By.xpath("//input[@id='txtCFXTradeSearch']");
	private By btnTradeSearch = By.xpath("//button[@id='btnCFXTradeSearch']");
	private By txtTradeOpen = By.xpath("//input[@id='SearchTradeNo']");
	private By btnOpenRecord = By.xpath("//button[@id='OpenRecord']");
	private By tblContractRow =  By.xpath("//*[@id='ListOfContracts']/tr");
	private By tblContractTradeNo(int i){
		return By.xpath("//*[@id='ListOfContracts']/tr["+i+"]/td[1]");
	}
	
	private By tblContractDate (int row){
		return By.xpath("//*[@id='ListOfContracts']/tr["+row+"]/td[2]");
	}
	private By tblContractClientCode (int row){
		return By.xpath("//*[@id='ListOfContracts']/tr["+row+"]/td[3]");
	}
	private By tblContractBuyCurrency (int row){
		return By.xpath("//*[@id='ListOfContracts']/tr["+row+"]/td[4]");
	}
	private By tblContractBuyAmount (int row){
		return By.xpath("//*[@id='ListOfContracts']/tr["+row+"]/td[5]");
	}
	private By tblContractManager (int row){
		return By.xpath("//*[@id='ListOfContracts']/tr["+row+"]/td[6]");
	}
	
	public SearchFXTrade(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void inputSearchData(String key) throws Exception{
		driverMethod.inputText("txtTradeSearch", txtTradeSearch, key);
	}
	public void inputTradeOpenData(String key) throws Exception{
		driverMethod.inputText("txtTradeOpen", txtTradeOpen, key);
	} 
	public void clickBtnSearch() throws Exception{
		driverMethod.click("btnTradeSearch", btnTradeSearch);
	}
	public void clickBtnOpen() throws Exception{
		driverMethod.click("btnOpenRecord", btnOpenRecord);
	}
	public void verifySearchDataReturn() throws Exception{
		inputSearchData(Common.getCellDataProvider(data, "Search Key"));
		clickBtnSearch();
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		// Get quantity of return data
		int size = driverMethod.driver.findElements(tblContractRow).size();
		// Verify return data 
		for (int i = 1; i<=size;i++){	
			if (
			driverMethod.isContainText("tblContractTradeNo", tblContractTradeNo(i), Common.getCellDataProvider(data, "Search Key"))||
			driverMethod.isContainText("tblContractDate", tblContractDate(i), Common.getCellDataProvider(data, "Search Key"))||
			driverMethod.isContainText("tblContractClientCode", tblContractClientCode(i), Common.getCellDataProvider(data, "Search Key"))||
			driverMethod.isContainText("tblContractBuyCurrency", tblContractBuyCurrency(i), Common.getCellDataProvider(data, "Search Key"))||
			driverMethod.isContainText("tblContractBuyAmount", tblContractBuyAmount(i), Common.getCellDataProvider(data,"Search Key"))||
			driverMethod.isContainText("tblContractManager", tblContractManager(i), Common.getCellDataProvider(data,"Search Key"))
			)
				Log.info("data row "+i+" is correct");
			if (
			!driverMethod.isContainText("tblContractTradeNo", tblContractTradeNo(i), Common.getCellDataProvider(data, "Search Key"))&&
			!driverMethod.isContainText("tblContractDate", tblContractDate(i), Common.getCellDataProvider(data, "Search Key"))&&
			!driverMethod.isContainText("tblContractClientCode", tblContractClientCode(i), Common.getCellDataProvider(data, "Search Key"))&&
			!driverMethod.isContainText("tblContractBuyCurrency", tblContractBuyCurrency(i), Common.getCellDataProvider(data, "Search Key"))&&
			!driverMethod.isContainText("tblContractBuyAmount", tblContractBuyAmount(i), Common.getCellDataProvider(data,"Search Key"))&&
			!driverMethod.isContainText("tblContractManager", tblContractManager(i), Common.getCellDataProvider(data,"Search Key"))
			)
				throw new Exception("Search function works wrong");
		}
	}
	public TradeEntryPage doubleclickTrade() throws Exception{
		String key=Common.getCellDataProvider(data, "Search Key");
		inputSearchData(key);
		clickBtnSearch();
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.doubleClick("tblContractTradeNo", tblContractTradeNo(1));
		driverMethod.switchwindow(size);
		return new TradeEntryPage(driverMethod, data);
	}
	public TradeEntryPage openTrade() throws Exception{
		String key=Common.getCellDataProvider(data, "Search Key");
		inputTradeOpenData(key);
		int size = driverMethod.driver.getWindowHandles().size();
		clickBtnOpen();
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		return new TradeEntryPage(driverMethod, data);
	}
	public TradeEntryPage openFirstRow() throws Exception{
		driverMethod.closeOtherWindow();
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.doubleClick("tblContractTradeNo", tblContractTradeNo(1));
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		return new TradeEntryPage(driverMethod, data);
	}
	
}

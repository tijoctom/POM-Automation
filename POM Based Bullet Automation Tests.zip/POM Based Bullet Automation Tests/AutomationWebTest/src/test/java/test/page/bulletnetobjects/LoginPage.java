package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

import test.common.WebProjectConstant;

public class LoginPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtUsername = By.xpath(".//*[@id='UserName']");
	private By txtPassword = By.xpath(".//*[@id='Password']");
	private By ddlAppName = By.xpath(".//*[@id='appName']");
	private By btnLogin = By.xpath(".//*[@id='btnLogon']");
	private By lblForgotPassword = By.xpath(".//*[@id='Forgotten']/img");
	private By lblMessage = By.xpath(".//*[@id='jqistate_state0']/div[2]");
//	private By btnOk = By.xpath(".//*[@id='jqi_state0_buttonOk']");
	
	
	public LoginPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		driverMethod.openUrl(WebProjectConstant.url);
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public BulletNetHomePage LoginSubmit() throws Exception {
		driverMethod.inputText("user name", txtUsername, Common.getCellDataProvider(data,"Username"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password"));
		driverMethod.selectDDLByText("Application Name", ddlAppName, Common.getCellDataProvider(data,"AppName"));
		driverMethod.click("Login", btnLogin);
		return new BulletNetHomePage(driverMethod, data);
	}
	
	public ForgetPasswordPage navigateForgetPassword() throws Exception {
		driverMethod.inputText("txtUsername", txtUsername, Common.getCellDataProvider(data,"LoginUsername"));;
		// Click forgot password button		
		driverMethod.click("lblForgotPassword", lblForgotPassword);	
		return new ForgetPasswordPage(driverMethod, data);
	}
	
	public void verifyLoginUnsuccess() throws Exception {
		driverMethod.waitForVisibilityOfElementLocated(lblMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"Verify"));
		
	}
	
	public BulletNetHomePage verifyLoginSuccess() throws Exception {	
		BulletNetHomePage homepage= new BulletNetHomePage(driverMethod, data);
		homepage.checkHomepage();		
		return homepage;
	}
	public BulletNetHomePage loginAgain() throws Exception {
		driverMethod.inputText("user name", txtUsername, Common.getCellDataProvider(data, "UserName2"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password2"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password2"));
		driverMethod.selectDDLByText("Application Name", ddlAppName, Common.getCellDataProvider(data,"AppName"));	
		driverMethod.click("Login", btnLogin);
		return new BulletNetHomePage(driverMethod, data);
	}
	public BulletNetHomePage loginAgain2() throws Exception {
		driverMethod.inputText("user name", txtUsername, Common.getCellDataProvider(data, "UserName3"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password3"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password3"));
		driverMethod.selectDDLByText("Application Name", ddlAppName, Common.getCellDataProvider(data,"AppName"));	
		driverMethod.click("Login", btnLogin);
		return new BulletNetHomePage(driverMethod, data);
	}
}

package test.page.bulletnetobjects;

import org.openqa.selenium.By;
import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.HtmlReporter;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;


public class OptionsPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By lblNewOptions = By.xpath("//*[@id='mniOptionNew']");
	private By lblOptionOpen =By.xpath("//*[@id='tblMenuMain']/tbody/tr[7]/td[2]/table/tbody/tr[1]/td/a");
    private By lblProductClass =By.xpath("//*[@id='ProductClass']");
    private By lblClientCategorisation =By.xpath("//*[@id='ClientCategorisation']");
    private By txtCompRate =By.xpath("//*[@id='txtCompRate']");
    private By txtBbgRef =By.xpath("//*[@id='txtBbgLegRef_0']");
    private By txtNationalEmt =By.xpath("//*[@id='txtNotionalAmount_0']");
    private By txtStrike =By.xpath("//*[@id='txtStrike_0']");
    private By btnRefPrice =By.xpath("//*[@id='cmdRefPrice']");
    private By txtClientPremium =By.xpath("//*[@id='txtClientsidePremium_0']");
    private By btnCalc =By.xpath("//*[@id='btnCal']");
    private By lblInstFrom =By.xpath("//*[@id='instruction-from']/td[2]/span");
    private By lblInstMethod =By.xpath("//*[@id='instruction-method-first-row']/td[1]/span");
    private By lblReason =By.xpath("//*[@id='cboReasonForPayment']");
    private By btnOptionSave =By.xpath("//*[@id='cmdSave']");
    private By lblSucessMsg =By.xpath("//td[contains(.,'The option has been saved successfully')]");
    private By lblBrokerErrorMsg =By.xpath("//td[contains(.,'The option status is not set to contract')]");
    private By btnOk =By.xpath("//*[@id='jqi_state0_buttonOk']");
    private By btnCreateContract =By.xpath("//*[@id='btnCreateContract']");
    private By lblFirstCell =By.xpath("//*[@id='ListOfContracts']/tr[1]/td[1]");
    private By lstBroker =By.xpath("//*[@id='cboBrokerCode_0']"); 
    private By txtBrokerDealer =By.xpath("//*[@id='txtBrokerDealer_0']");
    private By txtBrokerRef =By.xpath("//*[@id='txtBrokerRef_0']");
    private By btnVerify =By.xpath("//*[@id='cmdVerify']");
    private By btnYes =By.xpath("//*[@id='jqi_state0_buttonYes']");
    ////////////////////////Emergency release ////////////////////////////////////////////////////////////////////////////
    private By lblBrokerMsg =By.xpath("//div[@id='jqistate_state0']//td[contains(.,'This Broker BARCGRM is only allowed to trade Professional Clients.')]");
    private By lblOptionVerifyMsg=By.xpath("//div[@id='jqistate_state0']//td[contains(.,'The option has been verified successfully')]");
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public OptionsPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	//Methods
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public void clickNewOptions() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("New Option", lblNewOptions);
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
	}
	public void clickOptionOpen() throws Exception{
		//int size = driverMethod.driver.getWindowHandles().size();
		//driverMethod.click("Option Open", lblOptionOpen);
		//driverMethod.openUrl(Common.getCellDataProvider(data, "url"));
		driverMethod.clickByJS("OPTION OPEN", lblOptionOpen);
		//driverMethod.switchwindow(size);
		//driverMethod.closeOtherWindow();
	}
	public void clickFirstCell() throws Exception {
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.doubleClick("lblFirstCell", lblFirstCell);
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
	}
	public void verifyProductCC()throws Exception{
		String productClass= driverMethod.getAttribute("product class", lblProductClass, "value");
		String clientcategory =driverMethod.getAttribute("", lblClientCategorisation, "value");
		Log.info("Application data --Product class:"+productClass);
		Log.info("Application data --Client Categorisation:"+clientcategory);
		Log.info("Excel data --Product class:"+Common.getCellDataProvider(data, "ProductClass"));
		Log.info("Excel data --Client Categorisation:"+Common.getCellDataProvider(data, "ClientClassification"));		
		if (productClass.contains(Common.getCellDataProvider(data, "ProductClass"))&&(clientcategory.contains(Common.getCellDataProvider(data, "ClientClassification")))) {
			Log.info("PASS: Onboarding details Updated in Options screen");
			TestngLogger.writeResult("PASS: Onboarding details Updated in Options screen", true);
			HtmlReporter.pass("PASS: Onboarding details Updated in Options screen");
		}else {
			Log.error("FAIL: Onboarding details not updated in options screen");
			TestngLogger.writeResult("FAIL: Onboarding details not updated in options screen", false);
			HtmlReporter.fail("FAIL: Onboarding details not updated in options screen", "");
		}
	}
	public void createOptions() throws Exception {
		driverMethod.sendkeys("Comp Rate ", txtCompRate,Common.getCellDataProvider(data, "CompRate"));
		driverMethod.sendkeys("Bbg Ref", txtBbgRef,Common.getCellDataProvider(data, "BbgRef"));
		driverMethod.sendkeys("National Amount", txtNationalEmt, Common.getCellDataProvider(data, "NationalAmount"));
		driverMethod.sendkeys("Strike Rate", txtStrike,Common.getCellDataProvider(data, "StrikeRate"));
		driverMethod.clickByJS("Ref Price", btnRefPrice);
		driverMethod.clear("Client Premium", txtClientPremium);
		driverMethod.sendkeys("Client Premium", txtClientPremium, "2");
		driverMethod.clickByJS("Byn Calc", btnCalc);
		driverMethod.clickByJS("Instruction Form", lblInstFrom);
		driverMethod.clickByJS("Instruction method", lblInstMethod);
		driverMethod.selectDDLByText("Reason", lblReason,Common.getCellDataProvider(data,"Reason"));
		driverMethod.clickByJS("Option Save", btnOptionSave);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		String str = driverMethod.getText("Save sucess message", lblSucessMsg);
		if(str.contains(Common.getCellDataProvider(data,"SaveMsg"))) {
			Log.info("PASS: Save Message displayed successfully");
			TestngLogger.writeResult("PASS: Save Message displayed successfully", true);
			driverMethod.clickByJS("Option save sucessfull ok button", btnOk);
			driverMethod.clickByJS("Create contract button", btnCreateContract);
			driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
			driverMethod.clickByJS("New contract successfull ok button", btnOk);
			
		}else {
			Log.error("FAIL: Option save message not displayed correctly");
			TestngLogger.writeResult("Fail: Option save not displayed correctly", false);
		}
	}
	public void verifyOptions() throws Exception {
		driverMethod.selectDDLByText("Broker select list", lstBroker,Common.getCellDataProvider(data, "Broker"));
		driverMethod.sendkeys("Broker Dealer", txtBrokerDealer,Common.getCellDataProvider(data, "BrokerDealer"));
		driverMethod.sendkeys("broker ref", txtBrokerRef,Common.getCellDataProvider(data, "BrokerRef"));
		driverMethod.clear("Client Premium", txtClientPremium);
		driverMethod.sendkeys("Client Premium", txtClientPremium,Common.getCellDataProvider(data, "ClientPremium"));
		driverMethod.clickByJS("Calculate button", btnCalc);
		driverMethod.clickByJS("Verify button", btnVerify);
		driverMethod.clickByJS("Yes confirm button", btnYes);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("lblOptionVerifyMsg", lblOptionVerifyMsg, true);
		driverMethod.clickByJS("option save sucessfull ok button", btnOk);
		Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
	}
	public void verifyOptionVerifyMsg() throws Exception {
		driverMethod.selectDDLByText("Broker select list", lstBroker, Common.getCellDataProvider(data, "Broker"));
		driverMethod.sendkeys("Broker Dealer", txtBrokerDealer, Common.getCellDataProvider(data, "BrokerDealer"));
		driverMethod.sendkeys("broker ref", txtBrokerRef, Common.getCellDataProvider(data, "BrokerRef"));
		driverMethod.clear("Client Premium", txtClientPremium);
		driverMethod.sendkeys("Client Premium", txtClientPremium, Common.getCellDataProvider(data, "ClientPremium"));
		driverMethod.clickByJS("Calculate button", btnCalc);
		driverMethod.clickByJS("Verify button", btnVerify);
		Common.sleep(Constant.SMALL_WAITTIME_SECONDS);
		if (driverMethod.isElementDisplayed(lblBrokerMsg)) {
			TestngLogger.writeResult("Broker error message is displayed correctly", true);
		} else {
			TestngLogger.writeResult("Broker error message is not displayed", false);
		}
	}
	public void verifyCreateOptionsMsg() throws Exception {
		driverMethod.sendkeys("Comp Rate ", txtCompRate,Common.getCellDataProvider(data, "CompRate"));
		driverMethod.sendkeys("Bbg Ref", txtBbgRef,Common.getCellDataProvider(data, "BbgRef"));
		driverMethod.sendkeys("National Amount", txtNationalEmt, Common.getCellDataProvider(data, "NationalAmount"));
		driverMethod.sendkeys("Strike Rate", txtStrike,Common.getCellDataProvider(data, "StrikeRate"));
		driverMethod.clickByJS("Ref Price", btnRefPrice);
		driverMethod.clear("Client Premium", txtClientPremium);
		driverMethod.sendkeys("Client Premium", txtClientPremium,Common.getCellDataProvider(data, "ClientPremium"));
		driverMethod.clickByJS("Byn Calc", btnCalc);
		driverMethod.clickByJS("Instruction Form", lblInstFrom);
		driverMethod.clickByJS("Instruction method", lblInstMethod);
		driverMethod.selectDDLByText("Reason", lblReason,Common.getCellDataProvider(data,"Reason"));
		driverMethod.selectDDLByText("lstBroker", lstBroker,Common.getCellDataProvider(data, "Broker"));
		driverMethod.sendkeys("txtBrokerDealer", txtBrokerDealer,Common.getCellDataProvider(data, "BrokerDealer"));
		driverMethod.sendkeys("txtBrokerRef", txtBrokerRef,Common.getCellDataProvider(data, "BrokerRef"));		
		driverMethod.clickByJS("Option Save", btnOptionSave);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		String str = driverMethod.getText("Broker error message", lblBrokerErrorMsg);
		if(str.contains("The option status is not set to contract")){
			Log.info("PASS: Error message displayed correctly");
			TestngLogger.writeResult("PASS: Error message displayed correctly", true);
			
		}else {
			Log.error("FAIL:Error message not displayed correctly");
			TestngLogger.writeResult("FAIL:Error message not displayed correctly", false);
		}
	}
	
	
  
	
}

package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.page.bulletnetobjects.CommonObject;

public class OPIHistoryPage {
	
	private WebDriverMethod driverMethod;
	private Object [] data;
	
	// Web Element Locators
	private By txtAmount = By.xpath("//input[@id='Amount']");
	private By txtDateFrom = By.xpath("//input[@id='DateFrom']");
	private By txtDateTo = By.xpath("//input[@id='DateTo']");
	private By tblListOfOpiHistoryRow = By.xpath(".//*[@id='ListOfOpiHistory']/tr");
	private By tblListOfOpiHistoryRowOPIOD(int i){
		return By.xpath(".//*[@id='ListOfOpiHistory']/tr["+i+"]/td[1]");
	}
	
	
	private By btnSearch = By.xpath("//input[@id='cmdSearch']");
	
	public OPIHistoryPage(WebDriverMethod driverMethod, Object [] data) {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void inputSearchData() throws Exception{
		driverMethod.inputText("txtAmount", txtAmount, Common.getCellDataProvider(data, "Amount"));
		driverMethod.inputText("txtDateFrom", txtDateFrom, Common.getCellDataProvider(data, "Date From"));
		driverMethod.inputText("txtDateTo", txtDateTo, Common.getCellDataProvider(data, "Date To"));
	}
	public void clickSearchButton() throws Exception{
		driverMethod.click("btnSearch", btnSearch);
	}
	private String convertDate(String date){
		String convert[]=date.split("/");
		return convert[2]+"-"+ convert[1]+"-"+ convert[0];
	}
	public void verifySearchAmountData() throws Exception{
		SqlServerJDBC.getConnection();
		inputSearchData();
		clickSearchButton();
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		String query = "SELECT OPIID,ExportDateTime FROM tblOPIs (NOLOCK) LEFT JOIN tblCountries (NOLOCK) ON tblCountries.countryName = tblOPIs.Country LEFT JOIN tblCurrencies (NOLOCK) ON tblCurrencies.CurrencyName = tblOPIs.PaymentCurrency LEFT JOIN tblBanks (NOLOCK) ON tblBanks.fBrokerID = tblOPIs.fBrokerID LEFT JOIN tblBankACs (NOLOCK) ON tblBankACs.fBankID = tblBanks.BankID AND tblBankACs.fcurrencyID = tblCurrencies.currencyID LEFT JOIN tblFXContracts (NOLOCK) ON tblFXContracts.DealNo = tblOPIs.DealNo INNER JOIN tblCompanies (NOLOCK) ON tblCompanies.compID = tblOPIs.compID INNER JOIN tblAddresses (NOLOCK) ON tblAddresses.fcompID = tblCompanies.compID INNER JOIN tblContacts (NOLOCK) ON tblContacts.faddrID = tblAddresses.addrID WHERE tblOPIs.Export = 1 AND tblOPIs.Approved = 1 AND tblOPIs.GroupID = 1 AND REPLACE(tblOPIs.PaymentAmount, ',', '') LIKE '%"+Common.getCellDataProvider(data, "Amount")+"%'  "
				+ "AND tblOPIs.ExportDateTime BETWEEN '"+convertDate(Common.getCellDataProvider(data, "Date From"))+" 00:00:00' "
				+ "AND '"+convertDate(Common.getCellDataProvider(data, "Date To"))+" 23:59:29' order by ExportDateTime asc";
		String datasql[][]=SqlServerJDBC.getValueInDatabase(query);
		for (int i =0; i<driverMethod.driver.findElements(tblListOfOpiHistoryRow).size();i++){
			driverMethod.verifyContainText("tblListOfOpiHistoryRowOPIOD", tblListOfOpiHistoryRowOPIOD(i+1), datasql[i][0]);
		}
		SqlServerJDBC.closeConnection();
	}
}

package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

import test.common.WebProjectConstant;

public class TradeReconciliationPage{

	private WebDriverMethod driverMethod;
	@SuppressWarnings("unused")
	private Object [] data;

	// Web Element Locators
	private By btnFileImport = By.xpath("//input[@name='FileImport']");
	private By btnImport = By.xpath("//input[@value='Import']");
	private By btnPreview = By.xpath("//input[@id='btnPreview']");
	private By ddlCounterParties = By.xpath("//select[@id='cboCounterparties']");
	private By lbErrorMessage = By.xpath("//div[@class='jqimessage ']//td[2]");
	private By btnOK = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");
	
	public TradeReconciliationPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void importFile(String filename) throws Exception{
		String url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + filename;
		driverMethod.uploadfile(btnFileImport, url);
		Common.sleep(Constant.DEFAULT_WAITTIME_SECONDS);
		
	}
	public void selectCounterparties(String counterparty) throws Exception{
		driverMethod.selectDDLByText("ddlCounterParties", ddlCounterParties, counterparty);		
	}
	public void clickImport() throws Exception{
		driverMethod.click("btnImport", btnImport);		
	}
	public void clickPreview() throws Exception{
		driverMethod.click("btnPreview", btnPreview);
	}
	public void verifyMessage(String message) throws Exception{
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbErrorMessage", lbErrorMessage, message);
		driverMethod.click("btnOK", btnOK);
	}
	public void verifyImport(String report) throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		clickImport();
		// Switch window
		driverMethod.switchwindow(size);	
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);;
		
		String url = driverMethod.driver.getCurrentUrl();
		url=url.substring(url.lastIndexOf("?")+1);
		driverMethod.compareText("Reportname", report, url);
	}
	public void verifyPreview(String report) throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		clickPreview();
		// Switch window
		driverMethod.switchwindow(size);	
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);;
		
		String url = driverMethod.driver.getCurrentUrl();
		url=url.substring(url.lastIndexOf("?")+1);
		driverMethod.compareText("Reportname", report, url);
	}
}

package test.page.bulletnetobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;

import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;

public class CommonObject {
	
	@SuppressWarnings("unused")
	private WebDriverMethod driverMethod;
	@SuppressWarnings("unused")
	private Object [] data;
	
	// Web Element Locators
	public static final By imgLoading = By.xpath("//*[@id='divBusyIndicator']/img");
	public static final By crystalreport = By.xpath("//*[@id='CrystalReportViewerBullet']");
	
	public static final By menuNewTradeFX = By.xpath("//a[@id='mniNewFX']");
	public static final By menuSwapV2 = By.xpath("//a[@id='mniSwapV2']");
	public static final By menuTradeApproval = By.xpath("//*[@id='tblMenuMain']/tbody/tr[3]/td[3]/table/tbody/tr[3]/td/a");	
	public static final By menuOnboarding = By.xpath("//*[@id=\"tblMenuMain\"]/tbody/tr[7]/td[2]/table/tbody/tr[1]/td/a");	
	public static final String ContractType = "Spot";
	public static final String Promotion = "--";
	public static final String NewTradeTitle = "Bullet - Trade Tickets";
	public static final String CurrencyAmount = "0.00";
	public static final String EmptyValue = "";
	public static boolean PayByDD= false;
	
	public static final String  NoOfPayment = "1";
	public static final String  NoOfStrips = "1";
	public static int NoOfPaymentMax = 500;
	public static int NoOfStripsMax = 500;
	public static String NumberGenerate (int n){
		String s="";
		for (int i = 0; i<=n;i++){
			s+= i + "\n";
		}
		return StringUtils.trimToEmpty(s);
	}
	/*
	 * Get the valid date of system
	 */
	public static String validDate(String valueDate, String buyCurr, String sellCurr) throws Exception{		
		Calendar cal = Calendar.getInstance();		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		cal.setTime(simpleDateFormat.parse(valueDate));
		// if date is weekend, add date to become monday
		while (isweekend(cal) || isholiday(cal, buyCurr) || isholiday(cal, sellCurr)){
			cal=weekend(cal);
			cal=holiday(cal, buyCurr);
			cal=holiday(cal, sellCurr);
		}
		return simpleDateFormat.format(cal.getTime());		
	}
	private static boolean isweekend(Calendar cal) throws Exception{
		// if date is holiday, add 1 day
		if (cal.get(Calendar.DAY_OF_WEEK)==7 ||cal.get(Calendar.DAY_OF_WEEK)==1 )
			return true;
		return false;
	}
	// next available date for input currency
	@SuppressWarnings("deprecation")
	public static boolean isholiday(Calendar cal,String Curr) throws Exception{
		Date date = cal.getTime();	
		// if date is holiday, add 1 day
		if (!SqlServerJDBC.getValueInDatabase(isHoliday(Curr, date.getYear()+1900,date.getMonth()+1, date.getDate()), "Count").equalsIgnoreCase("0"))
			return true;
		return false;
	}
	private static String isHoliday(String curr, int year, int month, int date){
		return " Select count (*) as Count FROM tblSmartFXCurrencyHolidays "
				+ "where curr = '"+curr+"'  and  "
				+ "(DATEPART(yy, HolidayDate) = "+year+"  "
				+ "AND DATEPART(mm, HolidayDate) = "+month+" "
				+ "AND DATEPART(dd, HolidayDate) = "+date+")";
	}
	private static Calendar holiday(Calendar cal,String Curr) throws Exception{
		// if date is holiday, add 1 day
		while (isholiday(cal, Curr)){
			cal.add(Calendar.DATE, 1);
		}
		return cal;
	}
	private static Calendar weekend(Calendar cal) throws Exception{
		// if date is holiday, add 1 day
		while (isweekend(cal)){
			cal.add(Calendar.DATE, 1);
		}
		return cal;
	}
	
	
	
	public CommonObject(WebDriverMethod driverMethod, Object [] data) {
		this.driverMethod = driverMethod;
		this.data = data;
	}
}

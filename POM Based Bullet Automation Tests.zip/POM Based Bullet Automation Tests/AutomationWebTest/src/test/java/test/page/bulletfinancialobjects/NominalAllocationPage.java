package test.page.bulletfinancialobjects;

import java.util.Calendar;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

import test.page.bulletnetobjects.CommonObject;


public class NominalAllocationPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	String title = "Bullet Financial - Credit Allocation";
	private By btnExpandClientSearch = By.xpath("//*[@id='showNav']");
	private By btnExpandAutoAllocation = By.xpath("//*[@id='btShowAllocation']");
	private By divClientSearch = By.xpath("//*[@id='rightNominalAllocation']");
	private By txtClientSearch = By.xpath("//*[@id='txtClientSearch']");
	private By btnClientSearch = By.xpath("//*[@id='btnClientSearch']");
//	private By btnClientSearchNext = By.xpath("//*[@id='divAllCompanies']//a[text()='�']");
	private By imgLoading = By.xpath("//*[@id='divBusyIndicator']/img");	
//	private By txtDateFrom = By.xpath("//*[@id='dateFrom']");	
//	private By txtDateTo = By.xpath("//*[@id='dateTo']");	
	private By txtDealSearch = By.xpath("//*[@id='dealNum']");	
	private By btnDealSearch = By.xpath("//*[@id='SearchClientTrade']");	
	private By txtApproveAmount = By.xpath("//*[@id='Amount']");	
	private By btnApprove = By.xpath("//*[@id='btApprove']");	
	private By lbJQMessage = By.xpath("//div[contains(@class,'jqimessage')]//div[2]");
	private By lbJQMessage2 = By.xpath("//div[contains(@class,'jqimessage')]//td[2]");
	private By lbModalMessage = By.xpath("//div[@class='bootbox-body']");
//	private By btnJQOK = By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By btnRefresh = By.xpath("//*[@id='btRefresh']");
	private By lbClientName = By.xpath("//*[@id='h4currName']");
	private By btnReset = By.xpath("//*[@id='btnReset']");
	private By btnEmail = By.xpath("//*[@id='btEmail']");
	private By btnClear = By.xpath("//*[@id='btClear']");
	private By btnPreview = By.xpath("//*[@id='btnPreview']");		
	private By btnAutoAllocationDate (int month, int year, int date){
		return By.xpath("//*[@id='nominalDatepicker']//td[@data-month="+month+" and @data-year="+year+"]/a[text()='"+date+"']");
	}
	private By btnAutoAllocationChangeMonth(String action){
		return By.xpath("//*[@id='nominalDatepicker']//span[text()='"+action+"']");
	}
	private By btnAutoAllocationSelectByRow(int i){
		return By.xpath("//*[@id='allocationBody']/tr["+i+"]");
	}
	private By btnAutoAllocationSelectStatusByRow(int i){
		return By.xpath("//*[@id='allocationBody']/tr["+i+"]/td/span");
	}		
	public static By lbSourceNominal (String source){
		return By.xpath(".//*[@id='tblSourceNominal']/tbody//td[contains(text(),'"+source+"')]");
	}
	public static By lbSourceClient (String clientcode, String Ccy){
		return By.xpath(".//*[@id='SuspenceList']/tbody/tr[td[contains(text(),'"+clientcode+"')] and td[contains(text(),'"+Ccy+"')]]");
	}
	private By lbDestinationNominal = By.xpath(".//*[@id='tblDestinationNominal']/tbody/tr");
	private By lbCompany = By.xpath(".//*[@id='companies']/tbody/tr");
	public static By lbCompanyByRow(int i){
		return By.xpath(".//*[@id='companies']/tbody/tr["+i+"]");
	}
	public static By lbClientNameCompanyByRow(int i){
		return By.xpath(".//*[@id='companies']/tbody/tr["+i+"]/td[1]");
	}
	public static By lbClientCodeCompanyByRow(int i){
		return By.xpath(".//*[@id='companies']/tbody/tr["+i+"]/td[2]");
	}
	private By lbDealSearchResult = By.xpath(".//*[@id='TradesList']/tbody/tr");
	private By lbDealSearchClientCodeResultByRow(int i) {
		return By.xpath(".//*[@id='TradesList']/tbody/tr["+i+"]/td[1]");
	}
	public NominalAllocationPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void verifyTitle() throws Exception{
		driverMethod.compareText("Title", driverMethod.getTitle(), title);
	}
	public void preselect() throws Exception{
		
	}
	public void verifyRefresh() throws Exception{
		String sourcenominal = Common.getCellDataProvider(data, "Source Nominal");
		String sourceclientcode = Common.getCellDataProvider(data, "Client Code");
		String sourceclientccy = Common.getCellDataProvider(data, "Ccy");
		driverMethod.click("lbSourceNominal", lbSourceNominal(sourcenominal));
		// Wait loading successfully 
		Log.info("clicked on lbsourcenominal");
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		// Select client by client code
		Log.info("waitForInvisibilityOfElementLocated");
		driverMethod.click("lbSourceClient", lbSourceClient(sourceclientcode, sourceclientccy));
		Log.info("clicked lbSourceClient");
		// Select Deal
		driverMethod.click("lbDealSearchClientCodeResultByRow", lbDealSearchClientCodeResultByRow(1));
		Log.info("clicked lbDealSearchClientCodeResultByRow");
		// Input Refresh amount
		driverMethod.inputText("txtApproveAmount", txtApproveAmount, "1");
		// Click Refresh button
		driverMethod.click("btnRefresh", btnRefresh);
		// Wait loading successfully 
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);		
		// Verify screen is refreshed
		int size = driverMethod.driver.findElements(lbDestinationNominal).size();
		Assert.assertEquals(size, 0);		
		size = driverMethod.driver.findElements(lbDealSearchResult).size();
		Assert.assertEquals(size, 0);
		driverMethod.verifyText("txtApproveAmount", txtApproveAmount, "");
		//driverMethod.verifyText("lbClientName", lbClientName, "");
	}
	// verify result of search function: Client name or client search must contain search keyword
	private void resultSearch(String clientname,String clientcode, String keyword) throws Exception{
		if (!clientname.contains(keyword)&&!clientcode.contains(keyword)){
			Log.error("Search result "+clientcode+", "+clientname+" does not contain keyword "+keyword);
			TestngLogger.writeResult("Search result "+clientcode+", "+clientname+" does not contain keyword "+keyword, false);
			throw new Exception();
		}			 
	}
	private void resultSearch(String dealno, String keyword) throws Exception{
		if (!dealno.contains(keyword)){
			Log.error("Search result "+dealno+"does not contain keyword "+keyword);
			TestngLogger.writeResult("Search result "+dealno+"does not contain keyword "+keyword, false);
			throw new Exception();
		}			 
	}
	public void verifySearchClient() throws Exception{
		String keyword = Common.getCellDataProvider(data, "Keyword");		
		// Click on [ < ] button
		driverMethod.click("btnExpandClientSearch", btnExpandClientSearch);
		// Wait 
		driverMethod.waitForVisibilityOfElementLocated(divClientSearch, Constant.IMPLICIT_WAIT_TIME);
		// input search data
		driverMethod.inputText("txtClientSearch", txtClientSearch, keyword);
		int size = driverMethod.driver.findElements(lbCompany).size();
		// Click search button
		driverMethod.click("btnClientSearch", btnClientSearch);
		while (driverMethod.driver.findElements(lbCompany).size()== size)
			Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
		size = driverMethod.driver.findElements(lbCompany).size();	
		
		// Get quantity of return data
		// Verify return data 
		for (int i = 1; i<=size;i++){	
			String clientname = driverMethod.getText("lbClientNameCompanyByRow", lbClientNameCompanyByRow(i));
			String clientcode = driverMethod.getText("lbClientCodeCompanyByRow", lbClientCodeCompanyByRow(i));
			resultSearch(clientname, clientcode, keyword);
		}
		Log.info("Search result data is correct");
		TestngLogger.writeResult("Search result data is correct",true);
	}
	public void verifySearchDeal() throws Exception{
//		String sourcenominal = Common.getCellDataProvider(data, "Source Nominal");
		String sourceclientcode = Common.getCellDataProvider(data, "Client Code");
		String sourceclientccy = Common.getCellDataProvider(data, "Ccy");
//		String datefrom = Common.getCellDataProvider(data, "Date From");
//		String dateto = Common.getCellDataProvider(data, "Date To");
		String keyword = Common.getCellDataProvider(data, "Keyword");
		/*
		// Select Source Nominal
		driverMethod.click("lbSourceNominal", lbSourceNominal(sourcenominal));
		// Wait loading successfully 
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);*/
		// Select client by client code

		driverMethod.click("lbSourceClient", lbSourceClient(sourceclientcode, sourceclientccy));
		// Input Date From, Date To, Keyword
		driverMethod.inputText("txtDealSearch", txtDealSearch, keyword);
		// Click search client
		int size = driverMethod.driver.findElements(lbDealSearchResult).size();
		Log.info("Search result size: "+size);
		driverMethod.click("btnDealSearch", btnDealSearch);
		// Verify Search data
		
		while (driverMethod.driver.findElements(lbDealSearchResult).size()== size)
			Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
		size = driverMethod.driver.findElements(lbDealSearchResult).size();	
		// Verify return data 
		for (int i = 1; i<=size;i++){				
			String dealno = driverMethod.getText("lbDealSearchClientCodeResultByRow", lbDealSearchClientCodeResultByRow(i));
			// Verify return data
			resultSearch(dealno, keyword);
		}
		Log.info("Search result data is correct");
		TestngLogger.writeResult("Search result data is correct",true);
	}
	public void verifyApprove() throws Exception{
		String sourcenominal = Common.getCellDataProvider(data, "Source Nominal");
		String sourceclientcode = Common.getCellDataProvider(data, "Client Code");
		String sourceclientccy = Common.getCellDataProvider(data, "Ccy");
		String message = Common.getCellDataProvider(data, "Message");
		
		// Select Source Nominal
		driverMethod.click("lbSourceNominal", lbSourceNominal(sourcenominal));
		// Wait loading successfully 
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		// Select client by client code
		driverMethod.click("lbSourceClient", lbSourceClient(sourceclientcode, sourceclientccy));		
		// Select Deal
		driverMethod.click("lbDealSearchClientCodeResultByRow", lbDealSearchClientCodeResultByRow(1));
		// Input approve amount
		driverMethod.inputText("txtApproveAmount", txtApproveAmount, "1");
		// Click Approve button
		driverMethod.click("btnApprove", btnApprove);
		// Wait loading successfully 
		driverMethod.waitForVisibilityOfElementLocated(lbJQMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		// Verify success message
		driverMethod.verifyText("lbJQMessage", lbJQMessage, message);
	}
	@SuppressWarnings("deprecation")
	public void autoMonitor() throws Exception{
		int crmonth = Calendar.getInstance().getTime().getMonth();
		int cryear = Calendar.getInstance().getTime().getYear()+1900;
		String action;
		int date = Integer.valueOf(Common.getCellDataProvider(data, "Date"));
		int month = Integer.valueOf(Common.getCellDataProvider(data, "Month"))-1;
		int year = Integer.valueOf(Common.getCellDataProvider(data, "Year"));
		driverMethod.click("btnExpandAutoAllocation", btnExpandAutoAllocation);
		
		if (cryear>year)
			action = "Prev";
		else if (cryear<year)
			action = "Next";
		else{
			if (crmonth>month){
				action = "Prev";
			}
			else
				action = "Next";
		}
		while (!driverMethod.isElementPresent(btnAutoAllocationDate(month, year, date)))
				driverMethod.click("btnAutoAllocationChangeMonth", btnAutoAllocationChangeMonth(action));
		// Select date
		driverMethod.click("btnAutoAllocationDate", btnAutoAllocationDate(month, year, date));		
		// Select Allocation
		driverMethod.click("btnAutoAllocationSelectByRow", btnAutoAllocationSelectByRow(1));		
		// Click button email
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
	}
	
	public void verifyEmail() throws Exception{
		String message = Common.getCellDataProvider(data, "Message");		
		driverMethod.click("btnEmail", btnEmail);
		driverMethod.waitForVisibilityOfElementLocated(lbJQMessage2, Constant.LONG_WAITTIME_SECONDS);
		driverMethod.verifyText("lbJQMessage2", lbJQMessage2, message);
	}
	public void verifyClear() throws Exception{
		String oldstatus = driverMethod.getAttribute("btnAutoAllocationSelectStatusByRow", btnAutoAllocationSelectStatusByRow(1), "class");
		// Click button clear
		driverMethod.click("btnClear", btnClear);
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		String newstatus = driverMethod.getAttribute("btnAutoAllocationSelectStatusByRow", btnAutoAllocationSelectStatusByRow(1), "class");		
		Assert.assertNotEquals(oldstatus, newstatus);
		Log.info("Status changed successfully");
	}
	public void verifyReset() throws Exception{
		String message = Common.getCellDataProvider(data, "Message");		
		// Click button email
		driverMethod.click("btnReset", btnReset);
		// Verify message
		driverMethod.waitForVisibilityOfElementLocated(lbModalMessage, Constant.LONG_WAITTIME_SECONDS);		
		driverMethod.verifyText("lbModalMessage", lbModalMessage, message);
	
	}
	public void verifyPreview() throws Exception{
		// Click button preview
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnPreview", btnPreview);
		// Switch Window		
			
		driverMethod.switchwindow(size);
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.LONG_WAITTIME_SECONDS);;
		String url = driverMethod.driver.getCurrentUrl();
		String reportname = url.substring(url.lastIndexOf("=")+1);
		// Verify report Name
		Assert.assertEquals(reportname, Common.getCellDataProvider(data, "Report Name"));
	}
}

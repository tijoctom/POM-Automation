package test.page.bulletfinancialobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nashtech.common.Common;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

public class BulletFinancialHomePage {
	
	private WebDriverMethod driverMethod;
	private Object [] data;
	
	// Web Element Locators
	private By txtOPIHistory = By.xpath("//a[contains(.,'OPI History')]");
	private By txtCreditAllocation = By.xpath("//a[contains(.,'Credit Allocation')]");
	private By txtNominalAllocation = By.xpath("//a[contains(.,'Nominal Allocation')]");
	private By txtCashCollectionGRP = By.xpath("//ul[*[text()='Risk Management']]/li[6]//a[text()='GRP']");
	private By txtVariationMarginGRP = By.xpath("//ul[*[text()='Risk Management']]/li[4]//a[text()='GRP']");
	private By txtExportPaymentManual = By.xpath("//a[contains(.,'Export Payments (Manual)')]");
	private By txtExportPaymentAuto = By.xpath("//a[contains(.,'Export Payments (Auto Override)')]");
	private By txtCASS = By.xpath("//a[contains(.,'CASS')]");
	private By txtOPIInput = By.xpath("//a[contains(.,'OPI Input')]");
	private By txtOPIAmendment = By.xpath("//a[contains(.,'OPI Amendments')]");
	private By txtReport = By.xpath("//a[contains(.,'Report')]");
	
	private By txtLogoff = By.xpath("//a[contains(.,'Log Off')]");
	///////////////////  Updated Cash Collection   ////////////////////////////
	private By lblCashCollectionGRM =By.xpath("//ul[*[text()='Risk Management']]/li[6]//a[text()='GRM']");
	private By lblCashCollectionFCE =By.xpath("//ul[*[text()='Risk Management']]/li[6]//a[text()='FCE']");
	
	private By lbHomePageShorcutFunctionName(String label){
		return By.xpath("//span[contains(.,'"+label+"')]");
	}
	private By lbHomePageSettingFunctionName(String label){
		return By.xpath("//*[@id='dlgEditFunction']//td[contains(.,'"+label+"')]");
	}
	private By btnHomeSettings = By.xpath("//a[contains(.,'Homepage Setting')]");
	public BulletFinancialHomePage(WebDriverMethod driverMethod, Object [] data) {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void clickHomePageSettings()throws Exception{
		driverMethod.clickByJS("btnHomeSettings", btnHomeSettings);
	}
	public void verifyRemovedLabelHomePageSetting() throws Exception{
		driverMethod.isElementIsDisplayed("Add New IB", lbHomePageShorcutFunctionName("Funds Transfer"), false);
		clickHomePageSettings();
		driverMethod.isElementIsDisplayed("Add New IB", lbHomePageSettingFunctionName("Funds Transfer"), false);
	}
	public OPIHistoryPage clickOPIHistory()throws Exception{
		driverMethod.clickByJS("txtOPIHistory", txtOPIHistory);
		return new OPIHistoryPage(driverMethod, data);
	}
	public void clickLogoff()throws Exception{
		driverMethod.clickByJS("txtLogoff", txtLogoff);
	}
	public CreditAllocationPage clickCreditAllocation()throws Exception{
		driverMethod.clickByJS("txtCreditAllocation", txtCreditAllocation);
		return new CreditAllocationPage(driverMethod, data);
	}
	public void verifyCreditAllocationRole() throws Exception{
		String departmentid= Common.getCellDataProvider(data,"DepartmentID");
		if (departmentid.equalsIgnoreCase("4"))
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCreditAllocation, true);
		else 
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCreditAllocation, false);
	}
	public NominalAllocationPage clickNominalAllocation()throws Exception{
		driverMethod.clickByJS("txtNominalAllocation", txtNominalAllocation);
		return new NominalAllocationPage(driverMethod, data);
	}
	public void verifyNominalAllocationRole() throws Exception{
		String departmentid= Common.getCellDataProvider(data,"DepartmentID");
		if (departmentid.equalsIgnoreCase("4"))
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCreditAllocation, true);
		else 
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCreditAllocation, false);
	}
	public CashCollectionPage clickCashCollection()throws Exception{
		if(Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("1")) {
		driverMethod.clickByJS("txtCashCollectionGRP", txtCashCollectionGRP);
		}else if(Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("2")){
			driverMethod.clickByJS("", lblCashCollectionGRM);
		}else if (Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("3")) {
			driverMethod.clickByJS("", lblCashCollectionFCE);
		}
		return new CashCollectionPage(driverMethod, data);
	}
	public void verifyCashCollectionRole() throws Exception{
		String departmentid= Common.getCellDataProvider(data,"DepartmentID");
		if (departmentid.equalsIgnoreCase("10"))
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCashCollectionGRP, true);
		else 
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtCashCollectionGRP, false);
	}
	public VariationMarginPage clickVariationMargin()throws Exception{
		driverMethod.clickByJS("txtVariationMarginGRP", txtVariationMarginGRP);
		return new VariationMarginPage(driverMethod, data);
	}
	public void verifyVariationMarginRole() throws Exception{
		String departmentid= Common.getCellDataProvider(data,"DepartmentID");
		if (departmentid.equalsIgnoreCase("10"))
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtVariationMarginGRP, true);
		else 
			driverMethod.isElementIsDisplayed("txtCreditAllocation", txtVariationMarginGRP, false);
	}
	public CassPage clickCass()throws Exception{
		driverMethod.clickByJS("txtCASS", txtCASS);
		return new CassPage(driverMethod, data);
	}
	public ExportPaymentPage clickExportPaymentAuto()throws Exception{
		driverMethod.clickByJS("txtExportPaymentAuto", txtExportPaymentAuto);
		return new ExportPaymentPage(driverMethod, data);
	}
	public ExportPaymentPage clickExportPaymentManual()throws Exception{
		driverMethod.clickByJS("txtExportPaymentManual", txtExportPaymentManual);
		return new ExportPaymentPage(driverMethod, data);
	}
	public OPIInput clickOPIInput()throws Exception{
		driverMethod.clickByJS("txtOPIInput", txtOPIInput);
		return new OPIInput(driverMethod, data);
	}
	public OPIInput clickOPIAmendment()throws Exception{
		driverMethod.clickByJS("txtOPIAmendment", txtOPIAmendment);
		return new OPIInput(driverMethod, data);
	}
	public ReportPage clickReport()throws Exception{
		driverMethod.clickByJS("txtReport", txtReport);
		return new ReportPage(driverMethod, data);
	}
	/////////////////// Cash collection Update /////////////////////////////////////////
	public void verifyInvalidCashCollection() throws Exception {
		if (Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("1")) {
			List<WebElement> element = driverMethod.driver.findElements(txtCashCollectionGRP);
			if (element.isEmpty()) {
				Log.info("PASS: Cash collection is not present in the menu for GRP");
				TestngLogger.writeResult("PASS: Cash collection is not present in the menu for GRP", true);
			} else {
				TestngLogger.writeResult("FAIL: Cash collection is displayed to the wrong user", false);
			}
		} else if (Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("2")) {
			List<WebElement> element = driverMethod.driver.findElements(lblCashCollectionGRM);
			if (element.isEmpty()) {
				Log.info("PASS: Cash collection is not present in the menu for GRM");
				TestngLogger.writeResult("PASS: Cash collection is not present in the menu for GRM", true);
			} else {
				TestngLogger.writeResult("FAIL: Cash collection is displayed to the wrong user", false);
			}
		} else if (Common.getCellDataProvider(data, "Groupid").equalsIgnoreCase("3")) {
			List<WebElement> element = driverMethod.driver.findElements(lblCashCollectionFCE);
			if (element.isEmpty()) {
				Log.info("PASS: Cash collection is not present in the menu");
				TestngLogger.writeResult("PASS: Cash collection is not present in the menu for FCE", true);
			} else {
				TestngLogger.writeResult("FAIL: Cash collection is displayed to the wrong user for FCE", false);
			}
		}
	}
	
}


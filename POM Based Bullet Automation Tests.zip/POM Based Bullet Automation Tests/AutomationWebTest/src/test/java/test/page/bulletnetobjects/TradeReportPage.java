package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;
import com.nashtech.utils.report.Log;


public class TradeReportPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By btnOk = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");

	private By tblListOfOpiRow = By.xpath("//*[@id='tdBody']/tr");
	private By tblListOfOpiRowMandate (int row){
		return By.xpath("//*[@id='tdBody']/tr["+row+"]/td[2]/label[1]");
	}
	private By tblListOfOpiRowBeneficiaryName (int row){
		return By.xpath("//*[@id='tdBody']/tr["+row+"]/td[5]/label[1]");
	}
	private By tblListOfOpiRowAcNoIBAN (int row){
		return By.xpath("//*[@id='tdBody']/tr["+row+"]/td[6]/label[1]");
	}	
	private By tblListOfOpiRowSelect (int row){
		return By.xpath("//*[@id='tdBody']/tr["+row+"]/td[1]/input");
	}
	private By tblOpiRowBeneficiaryName (int row){
		return By.xpath("//*[@id='BeneficiaryName_"+row+"']");
	}
	private By tblOpiRowAcNoIBAN (int row){
		return By.xpath("//*[@id='AcNoIBAN_"+row+"']");
	}
	private By tblOpiRowBeneficiaryBank (int row){
		return By.xpath("//*[@id='BeneficiaryBank_"+row+"']");
	}
	private By tblOpiRowCountry (int row){
		return By.xpath("//*[@id='Country_"+row+"']");
	}
	private By tblOpiRowSwiftCode (int row){
		return By.xpath("//*[@id='SwiftCode_"+row+"']");
	}
	private By tblOpiRowSortCode (int row){
		return By.xpath("//*[@id='SortCode_"+row+"']");
	}
	
	private By tdPaymentDialog = By.xpath("//*[@id='tblPaymentDetails']");
	private By btnPaymentDialogYes = By.xpath("//*[@id='btnPaymentDialogConfirm']");
	private By btnPaymentDialogNo = By.xpath("//*[@id='btnPaymentDialogCancel']");
	private By btnEmail = By.xpath("//*[@id='cmdEmail']");
	private By tdPaymentBenName = By.xpath("//*[@id='lblBenName']");
	private By tdPaymentAcno = By.xpath("//*[@id='lblAcNoIBan']");
	private By tdPaymentBankName = By.xpath("//*[@id='lblBankName']");
	private By tdPaymentCountry = By.xpath("//*[@id='lblCountry']");
	private By tdPaymentSwift = By.xpath("//*[@id='lblSwift']");
	private By tdPaymentSortCode = By.xpath("//*[@id='lblSortCode']");
	private By tblJournalSubtypeCheck = By.xpath("//*[@id='JournalsTable']/tbody/tr[1]/td[3]");

	public TradeReportPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void verifyOpiData() throws Exception{
		SqlServerJDBC.getConnection();
		String clientcode=Common.getCellDataProvider(data, "Client Code");
		String companyid=Common.getCellDataProvider(data, "Company ID");;
		String ccy=Common.getCellDataProvider(data, "Currency");;
		
		String query = "SELECT DISTINCT Mandate = 'Y' , BeneficiaryName = tblCFXOPITemplates.BeneficiaryName , tblCFXOPITemplates.AcNoIBAN , NULL AS ExportDateTime, BeneficiaryNationality = tblNationality.Nationality , ISNULL(tblCFXOPITemplates.BeneficiaryAdd1, '') AS BeneficiaryAdd1 , ISNULL(tblCFXOPITemplates.BeneficiaryAdd2, '') AS BeneficiaryAdd2 , ISNULL(tblCFXOPITemplates.BeneficiaryAdd3, '') AS BeneficiaryAdd3 , PaymentCurrency = tblCurrencies.CurrencyName , ISNULL(tblCFXOPITemplates.SwiftCode, '') AS SwiftCode , ISNULL(tblCFXOPITemplates.SortCode, '') AS SortCode , ISNULL(tblCFXOPITemplates.BeneficiaryBank, '') AS BeneficiaryBank , ISNULL(tblCFXOPITemplates.Address1, '') AS Address1 , '' AS Address2 ,  ISNULL(tblCFXOPITemplates.City, '') AS City , '' AS [State] ,  '' AS ZipPostalCode ,  ISNULL(tblBankCountry.CountryName, '') AS Country , '' AS PaymentNotes ,  '' AS PaymentNotes2 , '' AS PaymentNotes3 , '' AS PaymentNotes4 , ISNULL(tblCFXOPITemplates.BranchRoutingCode, '') AS BranchRoutingCode , ISNULL(tblCFXOPITemplates.IMBankName, '') AS IMBankName , ISNULL(tblCFXOPITemplates.IMBankAddress1, '') AS IMBankAddress1 , '' AS IMBankAddress2 , ISNULL(tblCFXOPITemplates.IMBankCity, '') AS IMBankCity , '' AS IMBankState ,  '' AS IMBankZipPostalCode ,  ISNULL(tblIMBankCountry.CountryName, '') AS IMBankCountry , ISNULL(tblCFXOPITemplates.IMBankSwiftCode, '') AS IMBankSwiftCode , ISNULL(tblCFXOPITemplates.IMBankAcNo, '') AS IMBankAcNo , tblCharges.ChargesType FROM tblCompanies(NOLOCK) INNER JOIN tblCurrencyMandate (NOLOCK) ON tblCurrencyMandate.compID = tblCompanies.compID INNER JOIN tblCFXOPITemplates (NOLOCK) ON tblCFXOPITemplates.OPIID = tblCurrencyMandate.CFXOPIID INNER JOIN tblCharges (NOLOCK) ON tblCharges.ChargesID = tblCompanies.Charges INNER JOIN tblCurrencies (NOLOCK) ON tblCurrencies.currencyID = tblCFXOPITemplates.PaymentCurr INNER JOIN tblCountries tblBankCountry ( NOLOCK ) ON tblBankCountry.countryID = tblCFXOPITemplates.Country LEFT JOIN tblNationality (NOLOCK) ON tblNationality.ID = tblCFXOPITemplates.fBeneficiaryNationality LEFT JOIN tblCountries tblIMBankCountry ( NOLOCK ) ON tblIMBankCountry.countryID = tblCFXOPITemplates.Country WHERE tblCompanies.CompId = "+companyid+" AND ( tblCompanies.ClientCode = '"+clientcode+"' ) AND tblCurrencyMandate.CurrencyCode = '"+ccy+"' AND tblCurrencyMandate.Mandate = 1 AND tblBankCountry.bitSanction = 0 AND ISNULL(tblIMBankCountry.bitSanction, 0) = 0 union SELECT DISTINCT TOP 200 Mandate = 'P' , BeneficiaryName = tblOPIs.BeneficiaryName , tblOPIs.AcNoIBAN , tblOPIs.ExportDateTime AS ExportDateTime, BeneficiaryNationality = tblOPIs.BeneficiaryNationality , ISNULL(tblOPIs.BeneficiaryAdd1, '') AS BeneficiaryAdd1 , ISNULL(tblOPIs.BeneficiaryAdd2, '') AS BeneficiaryAdd2 , ISNULL(tblOPIs.BeneficiaryAdd3, '') AS BeneficiaryAdd3 , tblOPIs.PaymentCurrency , ISNULL(tblOPIs.SwiftCode, '') AS SwiftCode , ISNULL(tblOPIs.SortCode, '') AS SortCode , ISNULL(tblOPIs.BeneficiaryBank, '') AS BeneficiaryBank , ISNULL(tblOPIs.Address1, '') AS Address1 , '' AS Address2 ,  ISNULL(tblOPIs.City, '') AS City , '' AS [State] ,  '' AS ZipPostalCode ,  ISNULL(tblOPIs.Country, '') AS Country , '' AS PaymentNotes ,  '' AS PaymentNotes2 , '' AS PaymentNotes3 , '' AS PaymentNotes4 , ISNULL(tblOPIs.BranchRoutingCode, '') AS BranchRoutingCode , ISNULL(tblOPIs.IMBankName, '') AS IMBankName , ISNULL(tblOPIs.IMBankAddress1, '') AS IMBankAddress1 , '' AS IMBankAddress2 ,  ISNULL(tblOPIs.IMBankCity, '') AS IMBankCity , '' AS IMBankState , '' AS IMBankZipPostalCode , ISNULL(tblOPIs.IMBankCountry, '') AS IMBankCountry , ISNULL(tblOPIs.IMBankSwiftCode, '') AS IMBankSwiftCode , ISNULL(tblOPIs.IMBankAcNo, '') AS IMBankAcNo , tblCharges.ChargesType FROM tblOPIs (NOLOCK) INNER JOIN tblCompanies (NOLOCK) ON tblCompanies.compID = tblOPIs.compID INNER JOIN tblCharges (NOLOCK) ON tblCharges.ChargesID = tblCompanies.Charges INNER JOIN tblCountries tblBankCountry ( NOLOCK ) ON tblBankCountry.countryName = tblOPIs.Country LEFT JOIN tblCountries tblIMBankCountry ( NOLOCK ) ON tblIMBankCountry.countryName = tblOPIs.IMBankCountry WHERE tblCompanies.CompId = "+companyid+" AND ( tblCompanies.ClientCode = '"+clientcode+"' ) AND tblOPIs.PaymentCurrency = '"+ccy+"' AND tblOPIs.ExportDateTime > DATEADD(YEAR, -2, GETDATE()) AND tblOPIs.bitContractVisible = 1 AND tblBankCountry.bitSanction = 0 AND ISNULL(tblIMBankCountry.bitSanction, 0) = 0 union SELECT DISTINCTMandate = 'T' , BeneficiaryName = tblOPITemplates.BeneficiaryName , tblOPITemplates.AcNoIBAN , NULL AS ExportDateTime, BeneficiaryNationality = tblNationality.Nationality , ISNULL(tblOPITemplates.BeneficiaryAdd1, '') AS BeneficiaryAdd1 , ISNULL(tblOPITemplates.BeneficiaryAdd2, '') AS BeneficiaryAdd2 , ISNULL(tblOPITemplates.BeneficiaryAdd3, '') AS BeneficiaryAdd3 , tblOPITemplates.PaymentCurr AS PaymentCurrency , ISNULL(tblOPITemplates.SwiftCode, '') AS SwiftCode , ISNULL(tblOPITemplates.SortCode, '') AS SortCode , ISNULL(tblOPITemplates.BeneficiaryBank, '') AS BeneficiaryBank , ISNULL(tblOPITemplates.Address1, '') AS Address1 , '' AS Address2 ,  ISNULL(tblOPITemplates.City, '') AS City , '' AS [State] ,  '' AS ZipPostalCode , ISNULL(tblCountries.countryName, '') AS countryName , '' AS PaymentNotes ,  '' AS PaymentNotes2 , '' AS PaymentNotes3 , '' AS PaymentNotes4 , ISNULL(tblOPITemplates.BranchRoutingCode, '') AS BranchRoutingCode , ISNULL(tblOPITemplates.IMBankName, '') AS IMBankName , ISNULL(tblOPITemplates.IMBankAddress1, '') AS IMBankAddress1 , '' AS IMBankAddress2 , ISNULL(tblOPITemplates.IMBankCity, '') AS IMBankCity , '' AS IMBankState ,  '' AS IMBankZipPostalCode ,  ISNULL(tblCountriesIM.countryName, '') AS IMBankCountry , ISNULL(tblOPITemplates.IMBankSwiftCode, '') AS IMBankSwiftCode , ISNULL(tblOPITemplates.IMBankAcNo, '') AS IMBankAcNo , tblCharges.ChargesType FROM tblOPITemplates (NOLOCK) INNER JOIN tblCompanies (NOLOCK) ON tblCompanies.compID = tblOPITemplates.compID INNER JOIN tblUsers (NOLOCK) ON tblUsers.UserID = tblCompanies.AccountManager INNER JOIN tblCharges (NOLOCK) ON tblCharges.ChargesID = tblCompanies.Charges INNER JOIN tblCountries (NOLOCK) ON tblCountries.countryID = tblOPITemplates.Country LEFT JOIN tblCountries tblCountriesIM ( NOLOCK ) ON tblCountriesIM.countryID = tblOPITemplates.IMBankCountry LEFT JOIN tblNationality (NOLOCK) ON tblNationality.ID = tblOPITemplates.fBeneficiaryNationality WHERE tblOPITemplates.PaymentCurr = '"+ccy+"' AND tblOPITemplates.bitContractVisible = 1 AND tblCountries.bitSanction = 0 AND ISNULL(tblCountriesIM.bitSanction, 0) = 0 AND ( ( tblOPITemplates.ClientCode = '"+clientcode+"'AND tblOPITemplates.CompId = "+companyid+" AND tblUsers.DepartmentID IN ( 18, 23 )) OR ( UPPER('"+clientcode+"') = ( 'SW3179' ) AND tblOPITemplates.ClientCode = '"+clientcode+"'AND tblOPITemplates.CompId = "+companyid+"))ORDER BY Mandate DESC, BeneficiaryName ,AcNoIBAN, ExportDateTime DESC";
		String datasql[][]=SqlServerJDBC.getValueInDatabase(query);
		for (int i =0; i<driverMethod.driver.findElements(tblListOfOpiRow).size();i++){
			driverMethod.verifyContainText("tblListOfOpiHistoryRowOPIOD", tblListOfOpiRowMandate(i+1), datasql[i][0]);
			driverMethod.verifyContainText("tblListOfOpiHistoryRowOPIOD", tblListOfOpiRowBeneficiaryName(i+1), datasql[i][1]);
			driverMethod.verifyContainText("tblListOfOpiHistoryRowOPIOD", tblListOfOpiRowAcNoIBAN(i+1), datasql[i][2].trim());		
		}
		SqlServerJDBC.closeConnection();
	}
	public void selectOpi(int row) throws Exception{
		driverMethod.inputText("tblListOfOpiRowSelect", tblListOfOpiRowSelect(row), "y");		
	}
	public void deselectOpi() throws Exception{
		int size = driverMethod.driver.findElements(tblListOfOpiRow).size();
		for (int i = 1; i<=size;i++){
			driverMethod.inputText("tblListOfOpiRowSelect", tblListOfOpiRowSelect(i), "n");	
		}				
	}	
	public void verifyPaymentDetail(int row) throws Exception{
		driverMethod.waitForVisibilityOfElementLocated(tdPaymentDialog, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyContainText("tdPaymentBenName", tdPaymentBenName, 
				driverMethod.getText("", tblOpiRowBeneficiaryName(row)));
		driverMethod.verifyContainText("tdPaymentAcno", tdPaymentAcno, 
				driverMethod.getText("", tblOpiRowAcNoIBAN(row)));
		driverMethod.verifyContainText("tdPaymentBankName", tdPaymentBankName, 
				driverMethod.getText("", tblOpiRowBeneficiaryBank(row)));
		driverMethod.verifyContainText("tdPaymentCountry", tdPaymentCountry, 
				driverMethod.getText("", tblOpiRowCountry(row)));
		driverMethod.verifyContainText("tdPaymentSortCode", tdPaymentSortCode, 
				driverMethod.getText("", tblOpiRowSortCode(row)));
		driverMethod.verifyContainText("tdPaymentSwift", tdPaymentSwift, 
				driverMethod.getText("", tblOpiRowSwiftCode(row)));
		
	}
	
	public void verifyConfirmPaymentDetails(int row) throws Exception{
		driverMethod.click("btnPaymentDialogYes", btnPaymentDialogYes);
		driverMethod.verifyAttribute("tblListOfOpiRowSelect", tblListOfOpiRowSelect(row), "class", "y-enter");
	}
	public void verifyCancelPaymentDetails(int row) throws Exception{
		driverMethod.click("btnPaymentDialogNo", btnPaymentDialogNo);
		driverMethod.verifyAttribute("tblListOfOpiRowSelect", tblListOfOpiRowSelect(row), "class", "");
	}
	public void verifyJournal() throws Exception{
		driverMethod.click("btnEmail", btnEmail);
		driverMethod.click("btnOK", btnOk);
		driverMethod.verifyContainText("tblJournalSubtypeCheck", tblJournalSubtypeCheck, "Submitted to Settlements");
	}
}

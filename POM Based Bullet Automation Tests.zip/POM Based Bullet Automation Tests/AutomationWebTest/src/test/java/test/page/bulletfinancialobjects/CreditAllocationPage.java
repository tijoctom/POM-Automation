package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;


public class CreditAllocationPage{

	private WebDriverMethod driverMethod;
	@SuppressWarnings("unused")
	private Object [] data;

	// Web Element Locators
	String title = "Bullet Financial - Credit Allocation";
	private By txtClientSearch = By.xpath("//*[@id='txtClientSearch']");
	private By btnClientSearch = By.xpath("//*[@id='btnClientSearch']");
	private By btnAddCompanyBank = By.xpath("//*[@id='btnAddCompanyBank']");
	private By btnRemoveCompanyBank = By.xpath("//*[@id='btnRemoveCompanyBank']");
	private By btnApprove = By.xpath("//*[@id='btnApprove']");
	private By btnImport = By.xpath("//*[@id='btnImport']");
	private By btnRefresh = By.xpath("//*[@id='btnRefresh']");
	private By btnLinkedCompanies = By.xpath(".//*[@id='tblLinkedCompanies']/tbody/tr");
	public static By btnLinkedCompanies(int i) {
		return By.xpath(".//*[@id='tblLinkedCompanies']/tbody/tr["+i+"]");
	}
	private By btnCompany = By.xpath(".//*[@id='tblAllCompanies']/tbody/tr");
	public static By lbCompanyByRow(int i){
		return By.xpath(".//*[@id='tblAllCompanies']/tbody/tr["+i+"]");
	}
	public static By lbClientNameCompanyByRow(int i){
		return By.xpath(".//*[@id='tblAllCompanies']/tbody/tr["+i+"]/td[1]");
	}
	public static By lbClientCodeCompanyByRow(int i){
		return By.xpath(".//*[@id='tblAllCompanies']/tbody/tr["+i+"]/td[2]");
	}
	public static By btnCredit = By.xpath(".//*[@id='tblCredits']/tbody/tr");
	public static By lbCreditByRow(int i){
		return By.xpath(".//*[@id='tblCredits']/tbody/tr["+i+"]");
	}
	private By lbCredit(int i,int j){
		return By.xpath(".//*[@id='tblCredits']/tbody/tr["+i+"]/td["+j+"]");
	}
	private By lblBootboxMessage = By.xpath("//div[@class='bootbox-body']");
	private By btnOK = By.xpath("//button[contains(.,'Ok')]");
	private By btnYes = By.xpath("//button[contains(.,'Yes')]");
	
//	private By lblErrorMessage = By.xpath("//div[contains(@class,'jqimessage')]/div/div[2]");
//	private By btnJQOK = By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By lbJQMessage = By.xpath("//div[contains(@class,'jqimessage')]//td[2]");
	private By imgLoading = By.xpath("//*[@id='divBusyIndicator']/img");		
	
	public CreditAllocationPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void verifyTitle() throws Exception{
		driverMethod.compareText("Title", driverMethod.getTitle(), title);
	}
	// Import file
	public void verifyImportFile(String filepath) throws Exception{
		// Upload data file
		driverMethod.uploadfile(btnImport,filepath);
//		driverMethod.waitForVisibilityOfElementLocated(imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);        
		driverMethod.waitForInvisibilityOfElementLocated(imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);    
		
	}
	public void importFile(String filepath) throws Exception{
		// Upload data file
		driverMethod.uploadfile(btnImport,filepath);
		driverMethod.click("btnOK", btnOK);
		
	}
	// Verify pop-up message
	public void verifyMessage(String message) throws Exception{
		int temp = 0;
		for (int time = 0; time < Constant.DEFAULT_WAITTIME_SECONDS; time += Constant.TIMEOUT_STEPS_SECONDS) {
			try {
				if (driverMethod.displayedElement(lbJQMessage))
					temp =0;
				else if (driverMethod.displayedElement(lblBootboxMessage))
					temp=1;
				break;
			} catch (Exception e) {
				Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
			}
		}
		if (temp ==0)
			driverMethod.verifyText("Message", lbJQMessage, message);
		else if (temp ==1)
			driverMethod.verifyText("Message", lblBootboxMessage, message);
		
		
	}
	// Add data to table Association Company	
	public void associationCompany() throws Exception{
		// Select 1st row credit 		
		driverMethod.click("lbcredit 1st row", lbCreditByRow(1));		
		// Verify remove data in Link company field if have
		int size = driverMethod.driver.findElements(btnLinkedCompanies).size();
		while (size >0){
			driverMethod.click("btnLinkedCompanies", btnLinkedCompanies(size));			
			driverMethod.click("btnRemoveCompanyBank", btnRemoveCompanyBank);			
			driverMethod.click("btnYes", btnYes);			
			driverMethod.click("btnOK", btnOK);
			size = driverMethod.driver.findElements(btnLinkedCompanies).size();
		}		 
		// Double click 1st row Client 
		driverMethod.click("lbCompanyByRow 1st row"	, lbCompanyByRow(1));		
		driverMethod.click("btnAddCompanyBank", btnAddCompanyBank);
		// Click OK button to close pop up		
		driverMethod.click("btnOK", btnOK);
	}
	public void verifyRefresh() throws Exception{
		driverMethod.click("btnRefresh", btnRefresh);
		int size = driverMethod.driver.findElements(btnLinkedCompanies).size();
		Assert.assertEquals(size, 0);
		// Verify no row is selected
		size = driverMethod.driver.findElements(btnCredit).size();
		// Verify return data 
		for (int i = 1; i<=size;i++){	
			driverMethod.verifyAttribute("Select attribute of lbCredit", lbCredit(i, 1), "class", "");	
		}	
	}
	// verify result of search function: Client name or client search must contain search keyword
	public void resultSearch(String clientname,String clientcode, String keyword) throws Exception{
		if (!clientname.contains(keyword)&&!clientcode.contains(keyword)){
			Log.error("Search result "+clientcode+", "+clientname+" does not contain keyword "+keyword);
			TestngLogger.writeResult("Search result "+clientcode+", "+clientname+" does not contain keyword "+keyword, false);
			throw new Exception();
		}			 
	}
	public void searchClient(String keyword) throws Exception{
		// Input text into search field
		driverMethod.inputText("txtClientSearch", txtClientSearch, keyword);
		int size = driverMethod.driver.findElements(btnCompany).size();		
		// Click button Search
		driverMethod.click("btnClientSearch", btnClientSearch);
		// Get quantity of return data
		while (driverMethod.driver.findElements(btnCompany).size()== size)
			Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
		
	}
	public void verifySearch(String keyword) throws Exception{
		searchClient(keyword);
		int size = driverMethod.driver.findElements(btnCompany).size();	
		// Verify return data 
		for (int i = 1; i<=size;i++){	
			String clientname = driverMethod.getText("lbClientNameCompanyByRow", lbClientNameCompanyByRow(i));
			String clientcode = driverMethod.getText("lbClientCodeCompanyByRow", lbClientCodeCompanyByRow(i));
			resultSearch(clientname, clientcode, keyword);
		}
		Log.info("Search result data is correct");
		TestngLogger.writeResult("Search result data is correct",true);
	}
	public void verifyApprove(String message) throws Exception{
		driverMethod.click("btnApprove", btnApprove);
		// Verify success message		
		verifyMessage(message);
	}
	public void approveNewNominal(String url, String cliendcode) throws Exception{
		importFile(url);
		searchClient(cliendcode);
		associationCompany();
		driverMethod.click("btnLinkedCompanies", btnLinkedCompanies(1));			
		driverMethod.click("btnApprove", btnApprove);	
	}
}

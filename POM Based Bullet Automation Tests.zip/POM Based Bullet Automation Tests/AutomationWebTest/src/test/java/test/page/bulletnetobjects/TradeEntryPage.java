package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;
import com.nashtech.utils.report.HtmlReporter;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

public class TradeEntryPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtTradeNo = By.xpath("//*[@id='frmTradeEntry']/div[1]/div[1]/h3");
	private By ddlContractType = By.xpath("//*[@id='cboContractType']");
	private By ddlBrokerCode = By.xpath("//*[@id='cboBrokerCode']");
	private By ddlNoOfPayment = By.xpath("//*[@id='cboNoOfPayments']");
	private By txtCPMTM = By.xpath("//*[@id='txtCPMTM']");
	private By txtBrokerPrice = By.xpath("//*[@id='txtBrokerPrice']");
	private By txtBrokerDealer = By.xpath("//*[@id='txtBrokerDealer']");
	private By txtBrokerDealNo = By.xpath("//*[@id='txtBrokerDealNo']");
	private By btnBrokerMultiply = By.xpath("//*[@id='cmdMultiplyBuy']");
	private By btnVerify = By.xpath("//*[@id='cmdFilled']");
	private By btnSave = By.xpath("//*[@id='cmdSave']");
//	private By btnCloseOut = By.xpath("//*[@id='cmdCloseout']");
	private By btnConfirm = By.xpath("//button[contains(.,'Yes')]");	
	private By btnOk = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");
	
	private By message = By.xpath("//*[@class='jqimessage ']/div/div[2]");
	private By btnReport = By.xpath("//input[@id='cmdReport']");
	//////////////////////////////window forward/////////////////////////////////////////////	
	private By btnTradeNotExist = By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By lblTradeNo =By.xpath("//*[@id='frmTradeEntry']/div[1]/div[1]/h3");
	private By txtFirstUtil =By.xpath("//*[@id='mskFirstUtilDate']");
	private By txtBuyAmount =By.xpath("//*[@id='txtBuyAmount']");
	////////////////////////////////////////////////////////////////////////////////////////
	
	public TradeEntryPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void verifyUrl(String groupid, String dealno) throws Exception{
		String url =driverMethod.driver.getCurrentUrl();
		url=url.substring(url.indexOf("?"), url.length());
		url.equalsIgnoreCase("groupid="+groupid+"&dealNo="+dealno);		
	}
	public void verifyLocked() throws Exception{
		Common.sleep(Constant.IMPLICIT_WAIT_TIME);
		driverMethod.isElementIsDisplayed("message", message, false);		
//		if (driverMethod.isElementDisplayed(message))
//			driverMethod.verifyNotContainText("message", message, "This Trade is currently in use by");
	}
	public void clickBtnReport() throws Exception{
		driverMethod.click("btnReport", btnReport);
	}
	public TradeReportPage navigateTradeReport() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		clickBtnReport();
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		return new TradeReportPage(driverMethod, data);
	}
	public void inputBroker() throws Exception{
		String brokercode = Common.getCellDataProvider(data, "Broker Code");
        String CPMTM = Common.getCellDataProvider(data, "Client M2M");
        String brokerprice = Common.getCellDataProvider(data, "Broker Price");
        String brokerdealer = Common.getCellDataProvider(data, "Broker Dealer");
        String brokerdealno = Common.getCellDataProvider(data, "Broker Dealer No");
        String contractype = Common.getCellDataProvider(data, "Contract Type");		
		if (!contractype.equalsIgnoreCase(""))
			//driverMethod.selectDDLByText("ddlContractType", ddlContractType, contractype);       
		driverMethod.selectDDLByText("ddlBrokerCode", ddlBrokerCode,brokercode);
    	// Input CPMTM
    	driverMethod.inputText("txtCPMTM", txtCPMTM, CPMTM);
    	// Input broker price
    	driverMethod.inputText("txtBrokerPrice", txtBrokerPrice, brokerprice);
    	// Input broker dealer
    	driverMethod.inputText("txtBrokerDealer", txtBrokerDealer, brokerdealer);
    	// Input broker deal no 
    	driverMethod.inputText("txtBrokerDealNo", txtBrokerDealNo, brokerdealno);	
 		// Click button calc x
    	driverMethod.click("btnBrokerMultiply", btnBrokerMultiply);		
	}
	public void verifyLastTrade() throws Exception{
		inputBroker();
			//Click button Verify
    	driverMethod.click("btnVerify", btnVerify);
		// Click button confirm
    	driverMethod.waitForVisibilityOfElementLocated(btnConfirm, Constant.DEFAULT_WAITTIME_SECONDS);
    	driverMethod.click("btnConfirm", btnConfirm);
    	driverMethod.waitForVisibilityOfElementLocated(btnOk, Constant.DEFAULT_WAITTIME_SECONDS);
    	driverMethod.click("btnOk", btnOk);
	}
	public void saveLastTrade() throws Exception{
		inputBroker();
		//Click button btnSave
		driverMethod.click("btnSave", btnSave);
		// Click button confirm
		driverMethod.click("btnOk", btnOk);
	}
	public void increaseNoOfPayment(String dealno) throws Exception{
		SqlServerJDBC.getConnection();
		int count = Integer.valueOf(SqlServerJDBC.getValueInDatabase(" SELECT  COUNT(tblOPIs.OPIID) as a "
				+ "FROM tblOPIs (NOLOCK) INNER JOIN tblDebitControl (NOLOCK) ON tblOPIs.OPIID = tblDebitControl.fOPIID"
				+ " WHERE   tblDebitControl.fDealNo = "+dealno+" AND tblOPIs.OPIID <> 599520", "a"));
		int NoOfPayment = Integer.valueOf(driverMethod.getAttribute("ddlNoOfPayment", ddlNoOfPayment, "value"));		
		if (NoOfPayment<=count){
			driverMethod.selectDDLByText("ddlNoOfPayment", ddlNoOfPayment, String.valueOf(count+1));
			driverMethod.click("btnSave", btnSave);
			driverMethod.closeOtherWindow();
			driverMethod.click("btnOk", btnOk);
		}
	}
	public String getDealno() throws Exception{
		String dealno = driverMethod.getText("", txtTradeNo);
		dealno=dealno.substring(dealno.lastIndexOf(" "));
		return dealno;
	}
	/////////////////////////////////////                 windowed forward               /////////////////////////////////////////////////
	
	public NewTradePage verifyFieldEnabled() throws Exception {

		int size = driverMethod.driver.getWindowHandles().size();
		// driverMethod.clickByJS("menuTradeApproval", CommonObject.menuTradeApproval);
		// Change to Swap V2 window cause it will open in new tab/browser
		driverMethod.switchwindowNew(size);
		driverMethod.closeOtherWindow();

		if (driverMethod.isElementEnable(txtCPMTM)) {
			Log.info("Fields enabled in trade verify screen");
			TestngLogger.writeResult(txtCPMTM + " is enabled correctly", true);
			HtmlReporter.pass("Trade enabled in trade verify screen");
		} else {
			Log.error("Fields are not enabled in trade verify screen");
			TestngLogger.writeResult(txtCPMTM + " isn't enabled correctly", false);
		}

		return new NewTradePage(driverMethod, data);

	}
	
	public NewTradePage verifyTradeDontExist() throws Exception {

		int size = driverMethod.driver.getWindowHandles().size();
		// driverMethod.clickByJS("menuTradeApproval", CommonObject.menuTradeApproval);
		// Change to Swap V2 window cause it will open in new tab/browser
		driverMethod.switchwindowNew(size);
		driverMethod.closeOtherWindow();

		if (driverMethod.isElementDisplayed(btnTradeNotExist)) {
			Log.info("Trade not exist in trade verify screen");
			TestngLogger.writeResult("Trade not exist in trade verify screen", true);
			HtmlReporter.pass("Trade not exist Pop Up present in the trade verify screen");
			
		} else {
			Log.error("Trade exist in trade verify screen");
			TestngLogger.writeResult("Trade exist in trade verify screen", false);
		}

		return new NewTradePage(driverMethod, data);

	}
	public String verifyLastTradeNew() throws Exception {
		inputBroker();
		driverMethod.click("btnVerify", btnVerify);
		driverMethod.waitForVisibilityOfElementLocated(btnConfirm, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnConfirm", btnConfirm);
		driverMethod.waitForVisibilityOfElementLocated(btnOk, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnOk", btnOk);
		TestngLogger.writeResult("Tread verified successfully", true);
		HtmlReporter.pass("Tread verified successfully");
		String tradeno = driverMethod.getText("Trade no", lblTradeNo);
		tradeno = tradeno.substring(tradeno.lastIndexOf(" ") + 1);
		Log.info("New trade number is:"+tradeno);
		TestngLogger.writeLog("New trade number is:"+tradeno);
		return tradeno;
	}
	public String getBuyAmount() throws Exception{		
		String str= driverMethod.getAttribute("txtByAmount", txtBuyAmount, "value").trim();
		Log.info("BUY AMOUNT:::::::::"+str);
		return str;
	}
	public void verifyBuyAmountRefund(String buyAmount) throws Exception {
		String str = buyAmount;
		String newStr = driverMethod.getAttribute("txtByAmount", txtBuyAmount, "value").trim();
		Log.info("Old buy amount:" + str);
		Log.info("New Buy Amount:" + newStr);
		if (str.contains(newStr)) {
			Log.info("PASS: Amount refunded after rejection");
			TestngLogger.writeResult("PASS: Amount refunded after rejection", true);
		} else {
			Log.info("PASS: Amount refunded after rejection");
			TestngLogger.writeResult("FAIL: Amount not refunded after rejection", false);
		}
	}
	public void verifyFirstUtilDisabled() throws Exception {
		driverMethod.isElementIsEnabled("txtFirstUtil", txtFirstUtil, false);
	}
	public void verifyRollOver() throws Exception {
		driverMethod.selectDDLByText("ddlBrokerCode", ddlBrokerCode, Common.getCellDataProvider(data, "Broker Code"));
		driverMethod.inputText("txtCPMTM", txtCPMTM, Common.getCellDataProvider(data, "Client M2M"));
		driverMethod.inputText("txtBrokerPrice", txtBrokerPrice, Common.getCellDataProvider(data, "Broker Price"));
		driverMethod.inputText("txtBrokerDealer", txtBrokerDealer, Common.getCellDataProvider(data, "Broker Dealer"));
		driverMethod.inputText("txtBrokerDealNo", txtBrokerDealNo,Common.getCellDataProvider(data, "Broker Dealer No"));
		driverMethod.click("btnBrokerMultiply", btnBrokerMultiply);
		driverMethod.click("btnVerify", btnVerify);
		driverMethod.waitForVisibilityOfElementLocated(btnConfirm, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnConfirm", btnConfirm);
		driverMethod.waitForVisibilityOfElementLocated(btnOk, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.click("btnOk", btnOk);
		TestngLogger.writeResult("Tread verified successfully", true);
		HtmlReporter.pass("RollOver verified successfully");
	}
	
}

package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.core.web.WebDriverMethod;

import test.common.WebProjectConstant;

public class LoginPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtUsername = By.xpath(".//*[@id='UserName']");
	private By txtPassword = By.xpath(".//*[@id='Password']");
	private By ddlAppName = By.xpath(".//*[@id='appName']");
	private By ddlDepartment = By.xpath("//*[@id='department']");
	private By btnLogin = By.xpath(".//*[@id='btnLogon']");
	private By btnLogOff = By.xpath("//li[@class='dropdown open']/ul/li[5]/a");
	private By btnSettings =By.xpath("//li[@class='dropdown']/a/span");	
	
	public LoginPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		driverMethod.openUrl(WebProjectConstant.url);
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public BulletFinancialHomePage LoginSubmit() throws Exception {
		driverMethod.inputText("user name", txtUsername, Common.getCellDataProvider(data,"Username"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password"));
		driverMethod.selectDDLByText("Application Name", ddlAppName, Common.getCellDataProvider(data,"AppName"));
		driverMethod.selectDDLByText("Department ", ddlDepartment, Common.getCellDataProvider(data,"Department"));
		driverMethod.click("Login", btnLogin);
		return new BulletFinancialHomePage(driverMethod, data);
	}
	public void LogOff() throws Exception{
		driverMethod.clickByJS("Settings", btnSettings);
		driverMethod.clickByJS("Log Off", btnLogOff);
	}

}

package test.page.bulletnetobjects;

import org.openqa.selenium.By;
import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

import test.page.bulletfinancialobjects.BulletFinancialHomePage;

public class BulletNetHomePage {
	
	private WebDriverMethod driverMethod;
	private Object [] data;
	
	// Web Element Locators
	private By btnLogoff = By.xpath("//a[contains(.,'Log Off')]");
	private By txtHelloUser = By.xpath("//h1[contains(@id,'helloUser')]");	
//	private By btnSettingMenu = By.xpath(".//*[@id='tdSettingMenu']/img");
//	private By btnChangePassword = By.xpath("//a[contains(.,'Change Password')]");
//	private By btnBulletFinancialGRM = By.xpath("//a[contains(.,'Bullet Financial GRM')]");
	private By btnBulletFinancialGRP = By.xpath("//a[contains(.,'Bullet Financial GRP')]");
//	private By btnNewSwapv2 = By.xpath("//a[@id='mniSwapV2']");
//	private By txtSettingMenu = By.xpath(".//*[@id='tdSettingMenu']/img");
//	private By txtLogoff = By.xpath("//a[contains(.,'Log Off')]");
	private By txtClientSearch = By.xpath("//*[@id='txtClientSearch']");
	private By btnQuickSearch = By.xpath("//td[input[@id='txtClientSearch']]/input[@type='image']");
//	private By btnTopMenu = By.xpath("//*[@id='tdMenuDrop2']/img");
//	private By btnNewMarketOrder = By.xpath("//a[@id='mniNewMktOrder']");
//	private By divQuickSearchResult = By.xpath("//*[@id='divQuickSearchResult']");
//	private By btnNewFXOptionTrade = By.xpath("//a[@id='mniOptionNew']"); 
//	private By btnOpenFXOptionTrade = By.xpath(".//tbody[tr/td/*[@id='mniOptionNew']]//a[text()='Open']");
//	private By chkAddClientMenu = By.xpath("//input[@id='ckSelect_9']"); 
//	private By btnUpdateMenu = By.xpath(".//*[@id='dlgEditFunction']//input[@value='Update']"); 
//	private By btnAddClient = By.xpath("//a[@href='/Client/Index']"); 
//	private By lnkClientInfo = By.xpath("//*[@id='divQuickSearchResult']/div[1]/a"); 
	private By btnAlerts = By.xpath("//a[contains(.,'Alerts')]");

	private By lbTradeRec(String groupid){
		return By.xpath("//*[@id='tblMenuMain']//a[@href='/TradeReconciliation/Import?groupId="+groupid+"']");
	}
	private By lbHomePageShorcutFunctionName(String label){
		return By.xpath("//span[contains(.,'"+label+"')]");
	}
	private By lbHomePageSettingFunctionName(String label){
		return By.xpath("//*[@id='dlgEditFunction']//td[contains(.,'"+label+"')]");
	}
	private By divQuickSearchResult(String compID) {
		return By.xpath(".//*[@id='divQuickSearchResult']//a[contains(@href,'compId="+compID+"')]");
	}
	private By btnOpenTrade(String groupId){
		return By.xpath("//a[@href='/CFX/SearchFXTrade?GroupId="+groupId+"']");			
	}
	private By btnLiveRate = By.xpath("//a[contains(.,'Live Rates')]");
	private By btnAdvanceSearch = By.xpath("//a[contains(.,'Advanced Search')]");
	private By btnHomeSettings = By.xpath("//a[contains(.,'Homepage Setting')]");
	///////////////////////////// WF fix //////////////////////////////////////////////////////////////
	private By tblQuoteNum(String no){
		return By.xpath("//td[contains(.,'"+no+"')]");			
	}
	private By txtBuyBroker = By.xpath("//*[@id='txtBuyBrokerAmount']");
	private By lblTradeApproval= By.xpath("//td[@class='topMenuItem']/a[contains(.,'Trade Approvals')]");
	private By lblAllTradingHistory =By.xpath("//a[contains(.,'All Trading History')]");
	private By lblFirstUtilAllTradeHis =By.xpath("//*[@id='cHeadFirstUtilisationDate']");
	private By lblFirstUtilFXTradeHis =By.xpath("//div[@class='fht-fixed-column']//*[@id='cHeadFirstUtilisationDate']");
	private By lblGRMFXTrade =By.xpath("//*[@id='tblMenuMain']/tbody/tr[7]/td[3]/table/tbody/tr[1]/td/a");
	///////////////////////////Emergency release//////////////////////////////////////////////////////
	private By btnOK = By.xpath("//*[@id='jqi_state0_buttonOk']");	
	
	public BulletNetHomePage(WebDriverMethod driverMethod, Object [] data) {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void checkHomepage() throws Exception {
		driverMethod.verifyTitle("Bullet");
		driverMethod.verifyText("lblhelloUser", txtHelloUser, Common.getCellDataProvider(data, "HelloUser"));
	}
	
	public LoginPage logoff() throws Exception {
		driverMethod.clickByJS("Log off", btnLogoff);
		Log.info("Click on logout");
		return new LoginPage(driverMethod, data);
	}
	public FindClientPage search(String compid) throws Exception {
		driverMethod.inputText("txtClientSearch", txtClientSearch, compid);
		driverMethod.click("btnQuickSearch", btnQuickSearch);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		if (driverMethod.isElementDisplayed(divQuickSearchResult(compid))){
			driverMethod.click("divQuickSearchResult", divQuickSearchResult(compid));			
			Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		}
		return new FindClientPage(driverMethod, data);
	}
	public FindClientPage navigateClientPage() throws Exception{
		search(Common.getCellDataProvider(data, "Compid"));
		Log.info("navigateClientPage");
		return new FindClientPage(driverMethod, data);   	
	}
	public LiveRatesPage clickBtnLiveRate() throws Exception {
		driverMethod.clickByJS("btnLiveRate", btnLiveRate);
		return new LiveRatesPage(driverMethod, data);
	}
	public SearchFXTrade clickBtnOpenTrade() throws Exception {
		driverMethod.clickByJS("btnOpenTrade", btnOpenTrade(Common.getCellDataProvider(data, "Groupid")));
		return new SearchFXTrade(driverMethod, data);
	}
	public SearchFXTrade clickBtnOpenTrade(String groupid) throws Exception {
		driverMethod.clickByJS("btnOpenTrade", btnOpenTrade(groupid));
		return new SearchFXTrade(driverMethod, data);
	}
	public AdvanceSearchPage clickBtnAdvanceSearch() throws Exception {
		driverMethod.clickByJS("btnAdvanceSearch", btnAdvanceSearch);
		return new AdvanceSearchPage(driverMethod, data);
	}
	public void clickHomePageSettings()throws Exception{
		driverMethod.clickByJS("btnHomeSettings", btnHomeSettings);
	}
	public void verifyRemovedLabelHomePageSetting() throws Exception{
		driverMethod.isElementIsDisplayed("Add New IB", lbHomePageShorcutFunctionName("Add New IB"), false);
		driverMethod.isElementIsDisplayed("Add New Client", lbHomePageShorcutFunctionName("Add New Client"), false);
		clickHomePageSettings();
		driverMethod.isElementIsDisplayed("Add New IB", lbHomePageSettingFunctionName("Add New IB"), false);
		driverMethod.isElementIsDisplayed("Add New Client", lbHomePageSettingFunctionName("Add New Client"), false);
	}
	

	public BulletFinancialHomePage clickBulletFinancialGRP() throws Exception{
		driverMethod.clickByJS("btnBulletFinancialGRP", btnBulletFinancialGRP);		
		return new BulletFinancialHomePage(driverMethod, data);
	}
	public TradeReconciliationPage clickTradeRec(String groupid) throws Exception{
		driverMethod.clickByJS("lbTradeRec", lbTradeRec(groupid));		
		return new TradeReconciliationPage(driverMethod, data);
	}
	public void verifyTradeRecRole(String groupid) throws Exception{
		String departmentid= Common.getCellDataProvider(data,"DepartmentID");
		if (departmentid.equalsIgnoreCase("4"))
			driverMethod.isElementIsDisplayed("lbTradeRec", lbTradeRec(groupid), true);
		else 
			driverMethod.isElementIsDisplayed("lbTradeRec", lbTradeRec(groupid), false);
	}
	public TMSPage clickTMS() throws Exception{
		driverMethod.clickByJS("lbTradeRec", btnAlerts);		
		return new TMSPage(driverMethod, data);
	}
	/////////////////////// WF Fix   /////////////////////////////////////////////////
	public void clickQuoteNumber(String no) throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.doubleClick("tblQuoteNum", tblQuoteNum(no));
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
	}
	public void verifyBokerDisabled() throws Exception{
		driverMethod.isElementIsEnabled("txtBuyBroker", txtBuyBroker, false);
	}
	public void verifyTradeApproval() throws Exception{
		boolean b=driverMethod.isElementPresent(lblTradeApproval);
		if(b==false) {
			TestngLogger.writeResult("PASS: Trade approval is not present for this role as expected", true);
		}else{
			TestngLogger.writeResult("FAIL: Trade approval is present for invaild role", false);
		}
		
	}
	public void navigateAllTradeHistory() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("lblAllTradingHistory", lblAllTradingHistory);
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
	}
	public void verifyFirstUtilAllTradeHistory() throws Exception{
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("lblFirstUtilAllTradeHis", lblFirstUtilAllTradeHis, false);
	}
	public void verifyFirstUtilFXTradeHistory() throws Exception{
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("lblFirstUtilFXTradeHis", lblFirstUtilFXTradeHis, false);
	}
	public void naviagteFXTradeHistory() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("new", lblGRMFXTrade);
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
	}
	//////////////////////// Emergency release/////////////////////////////////
	public OnboardingPage navigateOnboarding() throws Exception {
		search(Common.getCellDataProvider(data, "Compid"));
		if (driverMethod.isElementDisplayed(btnOK)) {
			driverMethod.clickByJS("ok Button", btnOK);
		}
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("btnmenuOnboarding", CommonObject.menuOnboarding);
		// Change to Swap V2 window cause it will open in new tab/browser
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		return new OnboardingPage(driverMethod, data);
	}
	public OptionsPage navigatetoClientPage() throws Exception{
		search(Common.getCellDataProvider(data, "Compid"));
		if(driverMethod.isElementDisplayed(btnOK)) {
			driverMethod.clickByJS("ok Button", btnOK);
		}
		return new OptionsPage(driverMethod, data);
	}
}

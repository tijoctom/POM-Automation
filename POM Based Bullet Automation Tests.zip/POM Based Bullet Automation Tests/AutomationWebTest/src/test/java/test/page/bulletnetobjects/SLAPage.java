package test.page.bulletnetobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;

import test.common.WebProjectConstant;

public class SLAPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By SLAbackground = By.xpath("//*[@id='divDealingSLA']/div[@class='clientBg']");
	//Button
	private By btnSaveMeeting = By.xpath("//input[@id='btnSaveMeeting']");
	private By btnDeleteMeeting = By.xpath("//input[@id='btnDeleteMeeting']");
	private By btnContactReport = By.xpath("//input[@id='btnContactReport']");
	private By btnfileUpload = By.xpath("//input[@id='fileUpload']");
	private By btnViewLastestContact = By.xpath("//input[@id='cmdViewLastestContact']");
	private By btnOk = By.xpath("//button[contains(.,'Ok')]");
	private By btnConfirm = By.xpath("//div[@class='modal-content']//button[contains(.,'Yes')]");	
	//Text box
	private By lbDateForNextMeeting = By.xpath("//label[contains(.,'Date for next meeting')]");
	private By txtDateForNextMeeting = By.xpath("//input[@id='DateForNextMeeting']");
	// Message 
	private By txtMessage = By.xpath("//*[@class='bootbox-body']");
	
	// Checkbox		
	private By ckContactReportAll = By.xpath("//input[@id='ckContactReport_All']");
	private By chkCheckAll = By.xpath("//input[@id='chkCheckAll']");
	private By chkAgendaSent = By.xpath("//input[@id='chkAgendaSent']");
	private By chkMeetingComplete = By.xpath("//input[@id='chkMeetingComplete']");
	private By tbMeetingComplete(){
		return By.xpath("//input[@class='meeting-complete']");
	}
	private By tbContactFileName(int row){
		return By.xpath("//*[@id='tblContactReport']//tr["+row+"]/td[2]/a");
	}		
	public SLAPage(WebDriverMethod driverMethod, Object [] data) throws Exception {		
		this.driverMethod = driverMethod;
		this.data = data;
		driverMethod.waitForVisibilityOfElementLocated(SLAbackground, Constant.DEFAULT_WAITTIME_SECONDS);
	}
	public String addToCurrentDate(int day){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, day);
		Date inputDate = cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(inputDate);
	}
	public void verifyMeetingCompleteFail() throws Exception{
		String message = Common.getCellDataProvider(data, "Message");		
		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, addToCurrentDate(1));
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);
		// Meeting complete		
		driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click save meeting button
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		// Verify error message
		driverMethod.verifyText("txtMessage", txtMessage, message);
		// Click button ok
		driverMethod.click("btnOk", btnOk);
		// Deselect checkbox
		driverMethod.deselectCheckBox("chkMeetingComplete", chkMeetingComplete);
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		// Check checkbox complete
		driverMethod.selectCheckBox("tbMeetingComplete", tbMeetingComplete());
		// Verify error message
		driverMethod.verifyText("txtMessage", txtMessage, message);
		// Click button ok
		driverMethod.click("btnOk", btnOk);
		// Delete all Meeting
		driverMethod.selectCheckBox("chkCheckAll", chkCheckAll);
		driverMethod.click("btnDeleteMeeting", btnDeleteMeeting);
		// Click button yes
		driverMethod.click("btnConfirm", btnConfirm);
	}
	public void verifyMeetingCompleteSuccess() throws Exception{
		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, addToCurrentDate(0));
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);

		// Meeting complete		
		driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click save meeting button
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("txtMessage", txtMessage, false);		

		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, addToCurrentDate(-1));
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);

		// Meeting complete		
		driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click save meeting button
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("txtMessage", txtMessage, false);			
		
		// Delete all Meeting
		driverMethod.selectCheckBox("chkCheckAll", chkCheckAll);
		driverMethod.click("btnDeleteMeeting", btnDeleteMeeting);
		// Click button yes
		driverMethod.click("btnConfirm", btnConfirm);
	}
	public void verifyMeetingDeleteContact() throws Exception{
		String filename = Common.getCellDataProvider(data, "Upload URL");
		String url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + filename;	
		// Upload file
		driverMethod.uploadfile(btnfileUpload, url);				
		
		// Verify file uploaded succesfully
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		// Delete all Contact
		driverMethod.selectCheckBox("ckContactReportAll", ckContactReportAll);
		driverMethod.click("btnContactReport", btnContactReport);
		// Verify item is deleted
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("tbContactFileName", tbContactFileName(1), false);
	}
	public void verifyMeetingDelete() throws Exception{
		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, addToCurrentDate(0));
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);

		// Meeting complete		
		driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click save meeting button
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("txtMessage", txtMessage, false);		

		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, addToCurrentDate(-1));
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);

		// Meeting complete		
		driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click save meeting button
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("txtMessage", txtMessage, false);				
		
		// Delete all Meeting
		driverMethod.selectCheckBox("chkCheckAll", chkCheckAll);
		driverMethod.click("btnDeleteMeeting", btnDeleteMeeting);
		// Click button yes
		driverMethod.click("btnConfirm", btnConfirm);
		// Verify no data is still displayed
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("tbMeetingComplete", tbMeetingComplete(), false);
	
	}
	public void verifyMeetingInvalidFormatDate() throws Exception{
		String date = Common.getCellDataProvider(data, "Date");
		String message = Common.getCellDataProvider(data, "Message");
		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, date);
		// Click btn Save meeting
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		// Verify error message
		driverMethod.verifyText("txtMessage", txtMessage, message);
	}
	public void verifyMeetingInvalidRole() throws Exception{
		driverMethod.isElementIsEnabled("btnContactReport", btnContactReport, false);
		driverMethod.isElementIsEnabled("btnDeleteMeeting", btnDeleteMeeting, false);
		driverMethod.isElementIsEnabled("btnfileUpload", btnfileUpload, false);
		driverMethod.isElementIsEnabled("btnSaveMeeting", btnSaveMeeting, false);
		SqlServerJDBC.getConnection();
		SqlServerJDBC.executeQuery("delete from tblClientUserLock where compid = 41324");
	}
	public void verifyMeetingSave() throws Exception{
		String date = Common.getCellDataProvider(data, "Date");
		String agenda = Common.getCellDataProvider(data, "Agenda sent");
		String complete = Common.getCellDataProvider(data, "Meeting complete");
		// input Date 
		driverMethod.inputText("txtDateForNextMeeting", txtDateForNextMeeting, date);
		driverMethod.click("lbDateForNextMeeting", lbDateForNextMeeting);
		
		// Checkbox Agenda sent
		if (agenda.equalsIgnoreCase("true"))
			driverMethod.selectCheckBox("chkAgendaSent", chkAgendaSent);
		else
			driverMethod.deselectCheckBox("chkAgendaSent", chkAgendaSent);
		// Meeting complete
		if (complete.equalsIgnoreCase("true"))
			driverMethod.selectCheckBox("chkMeetingComplete", chkMeetingComplete);
		else
			driverMethod.deselectCheckBox("chkMeetingComplete", chkMeetingComplete);
		// Click btn Save meeting
		driverMethod.click("btnSaveMeeting", btnSaveMeeting);
		driverMethod.isElementIsDisplayed("txtMessage", txtMessage, false);
		// Delete all Meeting
		driverMethod.selectCheckBox("chkCheckAll", chkCheckAll);
		driverMethod.click("btnDeleteMeeting", btnDeleteMeeting);
		// Click button yes
		driverMethod.click("btnConfirm", btnConfirm);
	
	}
	public void verifyMeetingUploadContact() throws Exception{
		String filename = Common.getCellDataProvider(data, "Upload URL");
		String url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + filename;	
		
		// Upload file
		driverMethod.uploadfile(btnfileUpload, url);

		// Verify file uploaded succesfully
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyContainText("tbContactFileName", tbContactFileName(1), filename);
		// Delete all Contact
		driverMethod.selectCheckBox("ckContactReportAll", ckContactReportAll);
		driverMethod.click("btnContactReport", btnContactReport);
	}
	public void verifyMeetingValidRole() throws Exception{
		driverMethod.isElementIsEnabled("btnContactReport", btnContactReport, true);
		driverMethod.isElementIsEnabled("btnDeleteMeeting", btnDeleteMeeting, true);
		driverMethod.isElementIsEnabled("btnfileUpload", btnfileUpload, true);
		driverMethod.isElementIsEnabled("btnSaveMeeting", btnSaveMeeting, true);
	}
	public void verifyMeetingViewLatestContact() throws Exception{
		String filename = Common.getCellDataProvider(data, "Upload URL");
		String url = System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + filename;	
		
		// Upload file
		driverMethod.uploadfile(btnfileUpload, url);

		// Verify file uploaded succesfully
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading,Constant.DEFAULT_WAITTIME_SECONDS);
		//Click button view latest contact report
		filename =driverMethod.getText("tbContactFileName", tbContactFileName(1));
		driverMethod.click("btnViewLastestContact", btnViewLastestContact);
		driverMethod.isFileAvailable(System.getProperty("user.dir")+ Common.correctPath(WebProjectConstant.testResourcePath) + filename);
		
		driverMethod.selectCheckBox("ckContactReportAll", ckContactReportAll);
		driverMethod.click("btnContactReport", btnContactReport);
		
	}

		
		
}

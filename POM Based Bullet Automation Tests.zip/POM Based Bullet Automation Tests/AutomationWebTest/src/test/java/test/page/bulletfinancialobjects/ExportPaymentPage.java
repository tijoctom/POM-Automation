package test.page.bulletfinancialobjects;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

import test.page.bulletnetobjects.CommonObject;

public class ExportPaymentPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	/*-----Export Payment Auto*/ 
	private By btnSearch = By.xpath("//input[@value='Search']");	
	private By btnReset = By.xpath("//input[@id='btnResetSearch']");
	private By lblClientResult = By.xpath(".//*[@id='tblPaymentDetails']/tbody/tr/td[8]");				
	private By txtClientCode = By.xpath("//input[@id='SearchOption_ClientCode']");
	private By txtDealNo = By.xpath("//input[@id='SearchOption_DealNo']");	
	private By txtIBAN = By.xpath("//input[@id='SearchOption_IBAN']");	
	private By txtOrderNo = By.xpath("//input[@id='SearchOption_OrderNo']");			
	private By txtAmount = By.xpath("//input[@id='SearchOption_Amount']");			
	private By txtClientName = By.xpath("//input[@id='SearchOption_ClientName']");		
	private By txtOPIID = By.xpath("//input[@id='SearchOption_OPIID']");	
	private By txtBeneName = By.xpath("//input[@id='SearchOption_BeneName']");
	private By txtDetails = By.xpath("//div[2]/div/div/div[2]/div/table/tbody/tr/td[2]");	
	private By btnOk = By.xpath("//button[contains(.,'Ok')]");	
	private By txtApproveStatus = By.xpath("//table/tbody/tr/td[2]");
//	private By lblResult = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr/td[2]");
	private By lblResultSpan = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr/td[2]/span");
	private By lblResultOPIID = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr[1]/td[4]");
	
	private By lblResultDeleted = By.xpath("//*[@id='jqistate_state0']/div[2]/table/tbody/tr/td[2]");
	private By btnDelete = By.xpath("//a[@title='Delete']");
	private By btnYes = By.xpath("//button[contains(.,'Yes')]");
	/*--------Export Payment Manual*/
	private By ddlCurrencyCode = By.xpath("//*[@id='SearchOption_CurrencyCode']");	
	private By txtApprove = By.xpath("//*[@id='txt_0_1']");
	private By txtBlockedStatus = By.xpath("//table/tbody/tr/td[57]");
	private By txtBlocked= By.xpath("//*[@id='txt_0_56']");	
	private By txtDealNoApprove = By.xpath("//*[@id='txtDealNoApprove']");	
	private By txtApprovePopupSuccess = By.xpath("//*[@class='modal-body']//td[contains(.,'The OPI has been approved for export')]");	
	
	
//	private By btnSearch = By.xpath("//*[@id='btnSearch']");	
	private By btnResetSearch = By.xpath("//*[@id='btnResetSearch']");	
	private By btnApprove = By.xpath("//*[@id='btnApprove']");	
	private By btnPrint = By.xpath("//*[@id='btnPrint']");	
	private By btnPaymentSheet = By.xpath("//*[@id='btnPaymentSheet']");	
	private By btnSave = By.xpath("//*[@id='btnSave']");	
	private By btnSelectAll = By.xpath("//*[@id='btnSelectAll']");	
	private By btnCheck = By.xpath("//*[@id='btnCheck']");	
	private By btnExport = By.xpath("//*[@id='btnExport']");	
//	private By btnDelete = By.xpath("//tr[1]//a[@class='DeleteOPI']");
	private By btnDelete(String row){
		return By.xpath("//tr["+row+"]//a[@class='DeleteOPI']");	
	}
//	private By btnOk = By.xpath("//button[contains(.,'Ok')]");	
//	private By btnYes = By.xpath("//button[contains(.,'Yes')]");	
	
	private By lbPaymentDetailsClick = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr/td[4]");
	private By lbPaymentDetailsRow = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr");
	public static By lbPaymentDetailsRowNew(int i){
		return By.xpath(".//*[@id='tblPaymentDetails']/tbody/tr["+i+"]/td[2]/span");
	}
	private By lbPaymentDetailsData (String header){
		String[] temp = header.split(" ");
		if (temp.length==1)
			return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr[1]/td[count(//thead/tr/th[text()='"+header+"']/preceding-sibling::th)+1]");
		String xpath = "";
		int i=0;
		do{
			xpath+="contains(.,'"+temp[i]+"')";
			i++;
			if (i<temp.length)
				xpath+=" and ";
			else
				break;
		} while (true);
		
		return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr[1]/td[count(//thead/tr/th["+xpath+"]/preceding-sibling::th)+1]");	
	}/*
	private By lbPaymentDetailsBlocked = By.xpath("//*[@id='tblPaymentDetails']/tbody/tr/td[4]");
	private By lbPaymentDetailsRow(int row) {
		return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr["+row+"]");
	}
	private By lbPaymentDetailsData (String header,String row){
		String[] temp = header.split(" ");
		if (temp.length==1)
			return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr["+row+"]/td[count(//thead/tr/th[text()='"+header+"']/preceding-sibling::th)+1]");
		
		String xpath="";
		int i=0;
		do{
			xpath+="contains(.,'"+temp[i]+"')";
			i++;
			if (i<temp.length)
				xpath+=" and ";
			else
				break;
		} while (true);
		
		return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr["+row+"]/td[count(//thead/tr/th["+xpath+"]/preceding-sibling::th)+1]");	
	}
	*/
	private By lbPaymentDetailsInput (String header,String row){
		String[] temp = header.split(" ");
		if (temp.length==1)
			return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr["+row+"]/td[count(//thead/tr/th[text()='"+header+"']/preceding-sibling::th)+1]//input");
		
		String xpath="";
		int i=0;
		do{
			xpath+="contains(.,'"+temp[i]+"')";
			i++;
			if (i<temp.length)
				xpath+=" and ";
			else
				break;
		} while (true);
		
		return By.xpath("//*[@id='tblPaymentDetails']/tbody/tr["+row+"]/td[count(//thead/tr/th["+xpath+"]/preceding-sibling::th)+1]//input");	
	}
	
	
	private By lbPopupTitle = By.xpath("//*[@class='modal-title']");	
	private By lbPopupContent = By.xpath("//div[@class='modal-content']//td[2]");	
	private By lbJQMessage = By.xpath("//div[contains(@class,'jqimessage')]//td[2]");
	
	
	public ExportPaymentPage(WebDriverMethod driverMethod, Object [] data) throws Exception {				
		this.driverMethod = driverMethod;
		this.data = data;
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
	}
	public void verifyChangeApproveStatus() throws Exception{
		
		changeApproveStatus();
		// Verify the results
		String Result = Common.getCellDataProvider(data,"Result");
		driverMethod.verifyText("lblResult", lblResultSpan, Result);
		
	}
	public void verifyResetSearch() throws Exception{
		// Set the value data
		String ClientCode = Common.getCellDataProvider(data,"ClientCode");
		String DealNo = Common.getCellDataProvider(data,"DealNo");
		String ClientName = Common.getCellDataProvider(data,"ClientName");
		String Amount = Common.getCellDataProvider(data,"Amount");
		String OPIID = Common.getCellDataProvider(data,"OPIID");
		String BeneName = Common.getCellDataProvider(data,"BeneName");		
		String IBAN = Common.getCellDataProvider(data,"IBAN");		
		String OrderNo = Common.getCellDataProvider(data,"OrderNo");			
		// Fill all information
		driverMethod.sendkeys("ClientCode", txtClientCode, ClientCode);
		driverMethod.sendkeys("DealNo", txtDealNo, DealNo);
		driverMethod.sendkeys("ClientName", txtClientName, ClientName);
		driverMethod.sendkeys("txtAmount", txtAmount, Amount);
		driverMethod.sendkeys("OPIID", txtOPIID, OPIID);
		driverMethod.sendkeys("BeneName", txtBeneName, BeneName);
		driverMethod.sendkeys("IBAN", txtIBAN, IBAN);
		driverMethod.sendkeys("OrderNo", txtOrderNo, OrderNo);		
		// Click on Reset button		
		driverMethod.click("btnReset", btnReset);
		driverMethod.waitForInvisibilityOfElementLocated( CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		// Verify the result should be empty
		driverMethod.verifyContainText("ClientCode", txtAmount, "");
		driverMethod.verifyContainText("Currency", txtAmount, "");
		driverMethod.verifyContainText("DealNo", txtAmount, "");
		driverMethod.verifyContainText("ClientName", txtAmount, "");
		driverMethod.verifyContainText("txtAmount", txtAmount, "");
		driverMethod.verifyContainText("OPIID", txtAmount, "");
		driverMethod.verifyContainText("BeneName", txtAmount, "");
		driverMethod.verifyContainText("IBAN", txtAmount, "");
		driverMethod.verifyContainText("OrderNo", txtAmount, "");		
	}
	public void verifyDetail() throws Exception{
		String OPIID=driverMethod.getText("lblResultOPIID", lblResultOPIID);
		/*String OPIID = Common.getCellDataProvider(data,"OPIID");
		driverMethod.sendkeys("txtOPIID", txtOPIID, OPIID);		
		// Click on search button
		driverMethod.click("btnSearch", btnSearch);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		// Double click on the result		 
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		*/
		driverMethod.doubleClick("lblClientResult",  lblClientResult);		
//		String Details = Common.getCellDataProvider(data,"Details");	
		// Verify the result details
		driverMethod.waitForVisibilityOfElementLocated(txtDetails, Constant.LONG_WAITTIME_SECONDS);
		driverMethod.verifyContainText("txtDetails", txtDetails, OPIID);
	}
	public void verifySearch() throws Exception{
		
		// Set the value data
		String ClientResult = Common.getCellDataProvider(data,"Client Result");
		String DealNo = Common.getCellDataProvider(data,"DealNo");
		String ClientName = Common.getCellDataProvider(data,"ClientName");
		String Amount = Common.getCellDataProvider(data,"Amount");
		String OPIID = Common.getCellDataProvider(data,"OPIID");
		String BeneName = Common.getCellDataProvider(data,"BeneName");		
		String IBAN = Common.getCellDataProvider(data,"IBAN");					
		// Fill all information
		driverMethod.sendkeys("DealNo", txtDealNo, DealNo);
		driverMethod.sendkeys("ClientName", txtClientName, ClientName);
		driverMethod.sendkeys("txtAmount", txtAmount, Amount);
		driverMethod.sendkeys("OPIID", txtOPIID, OPIID);
		driverMethod.sendkeys("BeneName", txtBeneName, BeneName);
		driverMethod.sendkeys("IBAN", txtIBAN, IBAN);	
		// Click on Reset button		
		driverMethod.click("btnSearch", btnSearch);
		driverMethod.waitForInvisibilityOfElementLocated( CommonObject.imgLoading, Constant.LONG_WAITTIME_SECONDS);
		// Verify the result should be empty
		driverMethod.verifyContainText("lblClientResult", lblClientResult, ClientResult);
		
	}
	public void verifyDelete() throws Exception{
		// Click on Delete button
		driverMethod.click("btnDelete", btnDelete);
		// Clink on Yes button	
		driverMethod.click("btnYes", btnYes);
		// Verify the results
		String Result = Common.getCellDataProvider(data,"Result");
		driverMethod.verifyContainText("lblResultDeleted", lblResultDeleted, Result);		
	}
		
	public void disableBlocked() throws Exception{
		driverMethod.click("txtBlockedStatus", txtBlockedStatus);		
		driverMethod.sendkeys("txtBlocked", txtBlocked, "n");
		driverMethod.click("btnOk", btnOk);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
	}
	public void searchByOPI() throws Exception{
		driverMethod.inputText("txtOPIID", txtOPIID, Common.getCellDataProvider(data, "OPI ID"));
		// Click Search
		driverMethod.click("btnSearch", btnSearch);
		// Wait
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);		
	}
	public void changeApproveStatus() throws Exception{
		driverMethod.click("txtApproveStatus", txtApproveStatus);
		driverMethod.sendkeys("txtApprove", txtApprove, "Y");
		driverMethod.click("lblResultOPIID", lblResultOPIID);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		
	}
	
	public void verifyApproveManual() throws Exception{
		disableBlocked();
		changeApproveStatus();
		// Click button btnApprove
		driverMethod.click("btnApprove", btnApprove);		
		// input text
		driverMethod.inputText("txtDealNoApprove", txtDealNoApprove, "");
		// Close pop-up
		driverMethod.click("btnOk", btnOk);
//		driverMethod.click("btnYes", btnYes);
		// Verify Success pop-up	
		driverMethod.isElementDisplayed(txtApprovePopupSuccess);
	}
	
	public void verifyCheckPaymentManual() throws Exception{
		searchByOPI();		
		disableBlocked();
		changeApproveStatus();
		String message = Common.getCellDataProvider(data, "Message");
		String title = Common.getCellDataProvider(data, "Title");
		
		// Click 1st row
		driverMethod.click("lbPaymentDetailsData", lbPaymentDetailsClick);
		String keyed  = driverMethod.getText("Keyed", lbPaymentDetailsData("Keyed"));
		// Click button btnPaymentSheet
		int size = driverMethod.driver.getWindowHandles().size();		
		driverMethod.click("btnCheck", btnCheck);
		if (keyed.equalsIgnoreCase("No")){
			driverMethod.verifyContainText("lbPopupContent", lbPopupContent, message);
		}
		else{				
			driverMethod.switchwindow(size);			
			driverMethod.verifyTitle(title);
			
		}
		driverMethod.closeOtherWindow();
	}
	public void verifyDeleteManual() throws Exception{
		disableBlocked();
		changeApproveStatus();
		// Click button btnPaymentSheet
		driverMethod.click("btnDelete", btnDelete("2"));
		// Verify Error pop-up
		driverMethod.click("btnYes", btnYes);
		// Verify successful message
		driverMethod.verifyText("lbJQMessage", lbJQMessage, Common.getCellDataProvider(data, "Message"));

	}
	public void verifyDoubleClickManual() throws Exception{
		String title = Common.getCellDataProvider(data, "Title");
		// Double Click 1st row
		driverMethod.doubleClick("lbPaymentDetailsData", lbPaymentDetailsClick);
		// Wait for popup appear
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.SMALL_WAITTIME_SECONDS);		
		driverMethod.verifyText("lbPopupTitle", lbPopupTitle, title);
	}	
	public void verifyExportManual() throws Exception{
		disableBlocked();
		changeApproveStatus();
		int size = driverMethod.driver.getWindowHandles().size();		
		driverMethod.click("btnExport", btnExport);	
		driverMethod.switchwindow(size);	
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);
		String url = driverMethod.driver.getCurrentUrl();
		String reportName = url.substring(url.lastIndexOf("&")+1);
		//Verify system open correct report		
		driverMethod.compareText("reportName", reportName, Common.getCellDataProvider(data, "Report Name"));
	}
	public void verifyPaymentSheetManual() throws Exception{
		disableBlocked();
		changeApproveStatus();		
			// Click button btnPaymentSheet
 		driverMethod.click("btnPaymentSheet", btnPaymentSheet);		
		// Verify successful message
		driverMethod.waitForVisibilityOfElementLocated(lbPopupContent, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbPopupContent", lbPopupContent, Common.getCellDataProvider(data, "Message"));
		// Click button OK
		int size = driverMethod.driver.getWindowHandles().size();		
		driverMethod.click("btnOk", btnOk);
		// Switch window				
		driverMethod.switchwindow(size);					
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);		
		String url = driverMethod.driver.getCurrentUrl();
		String reportName = url.substring(0,url.lastIndexOf("&"));
		reportName = reportName.substring(reportName.lastIndexOf("&")+1);
		driverMethod.compareText("reportName", reportName, Common.getCellDataProvider(data, "Report Name"));
	}	
	public void verifyPrintManual() throws Exception{
		disableBlocked();
		changeApproveStatus();
		// Click button btnPaymentSheet
		int size = driverMethod.driver.getWindowHandles().size();	
		driverMethod.click("btnPrint", btnPrint);		
		driverMethod.switchwindow(size);			
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);
		
		String url = driverMethod.driver.getCurrentUrl();
		String reportName = url.substring(0,url.lastIndexOf("&"));
		reportName = reportName.substring(reportName.lastIndexOf("&")+1);
		//Verify system open correct report		
		driverMethod.compareText("reportName", reportName, Common.getCellDataProvider(data, "Report Name"));
	}
	public void verifyResetSearchManual() throws Exception{
		String clientcode = Common.getCellDataProvider(data, "Client Code");
		String currency = Common.getCellDataProvider(data, "Currency");
		String dealno = Common.getCellDataProvider(data, "Deal No");
		String clientname = Common.getCellDataProvider(data, "Client Name");
		String amount = Common.getCellDataProvider(data, "Amount");
		String opiid = Common.getCellDataProvider(data, "OPI ID");
		String benename = Common.getCellDataProvider(data, "Bene Name");
		String iban = Common.getCellDataProvider(data, "IBAN");
		String orderno = Common.getCellDataProvider(data, "Order No");
		
		// Input ClientCode
		driverMethod.inputText("txtClientCode", txtClientCode, clientcode);
		// Select ddlCurrencyCode
		driverMethod.selectDDLByText("ddlCurrencyCode", ddlCurrencyCode, currency);
		// Input txtDealNo
		driverMethod.inputText("txtDealNo", txtDealNo, dealno);
		// Input txtClientName
		driverMethod.inputText("txtClientName", txtClientName, clientname);
		// Input txtAmount
		driverMethod.inputText("txtAmount", txtAmount, amount);
		// Input txtOPIID
		driverMethod.inputText("txtOPIID", txtOPIID, opiid);
		// Input txtBeneName
		driverMethod.inputText("txtBeneName", txtBeneName, benename);
		// Input txtIBAN
		driverMethod.inputText("txtIBAN", txtIBAN, iban);
		// Input txtOrderNo
		driverMethod.inputText("txtOrderNo", txtOrderNo, orderno);
		// Click Search
		driverMethod.click("btnResetSearch", btnResetSearch);
		// Wait
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyAttribute("txtClientCode", txtClientCode, "value", "");
		driverMethod.verifyDisplayDDL("ddlCurrencyCode", ddlCurrencyCode, "");
		driverMethod.verifyAttribute("txtDealNo", txtDealNo, "value", "");
		driverMethod.verifyAttribute("txtAmount", txtAmount, "value", "");
		driverMethod.verifyAttribute("txtOPIID", txtOPIID, "value", "");
		driverMethod.verifyAttribute("txtIBAN", txtIBAN, "value", "");
		driverMethod.verifyAttribute("txtOrderNo", txtOrderNo, "value", "");
	}
	public void verifySaveManual() throws Exception{
		disableBlocked();
		changeApproveStatus();
	
		// Click button btnSave
		driverMethod.click("btnSave", btnSave);
		// Verify Success pop-up
		driverMethod.waitForVisibilityOfElementLocated(lbPopupContent, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("SuccessMessage", lbPopupContent, Common.getCellDataProvider(data, "Message"));
	}
	public void verifySearchManual() throws Exception{
		String clientcode = Common.getCellDataProvider(data, "Client Code");
		String currency = Common.getCellDataProvider(data, "Currency");
		String dealno = Common.getCellDataProvider(data, "Deal No");
		String clientname = Common.getCellDataProvider(data, "Client Name");
		String amount = Common.getCellDataProvider(data, "Amount");
		String opiid = Common.getCellDataProvider(data, "OPI ID");
		String benename = Common.getCellDataProvider(data, "Bene Name");
		String iban = Common.getCellDataProvider(data, "IBAN");
		String orderno = Common.getCellDataProvider(data, "Order No");
		// Input ClientCode
		driverMethod.inputText("txtClientCode", txtClientCode, clientcode);
		// Select ddlCurrencyCode
		driverMethod.selectDDLByText("ddlCurrencyCode", ddlCurrencyCode, currency);
		// Input txtDealNo
		driverMethod.inputText("txtDealNo", txtDealNo, dealno);
		// Input txtClientName
		driverMethod.inputText("txtClientName", txtClientName, clientname);
		// Input txtAmount
		driverMethod.inputText("txtAmount", txtAmount, amount);
		// Input txtOPIID
		driverMethod.inputText("txtOPIID", txtOPIID, opiid);
		// Input txtBeneName
		driverMethod.inputText("txtBeneName", txtBeneName, benename);
		// Input txtIBAN
		driverMethod.inputText("txtIBAN", txtIBAN, iban);
		// Input txtOrderNo
		driverMethod.inputText("txtOrderNo", txtOrderNo, orderno);
		// Click Search
		driverMethod.click("btnSearch", btnSearch);
		// Wait
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		
		// Verify result
		driverMethod.verifyText("OPI ID", lbPaymentDetailsData("OPI ID"), opiid);
				
	}
	public void verifySelectAllManual() throws Exception{
		// Click button btnSelectAll
		driverMethod.click("btnSelectAll", btnSelectAll);		
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		// Verify all row are selected
		int row = driverMethod.driver.findElements(lbPaymentDetailsRow).size();
		Log.info("Total rows: "+row);
		for (int i=1;i<=row;i++){
				driverMethod.verifyAttribute("lbPaymentDetailsInputApprove: "+i, lbPaymentDetailsInput("Approve", String.valueOf(i)), "value", "Yes");
				Log.info("Total rows: "+i);
		}
		// Click button btnSelectAll
		driverMethod.click("btnSelectAll", btnSelectAll);		
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		// Verify all row are selected	
		for (int i=1;i<=row;i++){
				driverMethod.verifyAttribute("lbPaymentDetailsInputApprove: "+i, lbPaymentDetailsInput("Approve", String.valueOf(i)), "value", "No");	
		}
	}
	

	public void verifySelectAll() throws Exception {

		driverMethod.click("btnSelectAll", btnSelectAll);
		driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading, Constant.DEFAULT_WAITTIME_SECONDS);
		// Give total row count
		int row = driverMethod.driver.findElements(lbPaymentDetailsRow).size();
		for (int i = 1; i <= row; i++) {
			String approveText = driverMethod.getText("lbClientCodeCompanyByRow", lbPaymentDetailsRowNew(i));
			approveText = approveText.replace("[", "").replace("]", "");
			approveText = approveText.trim();
			// Log.info("approveText :" + approveText);
			if (approveText.contains("Yes")) {
				driverMethod.click("btnSelectAll", btnSelectAll);
				driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading,
						Constant.DEFAULT_WAITTIME_SECONDS);
				driverMethod.verifyAttribute("lbPaymentDetailsInputApprove: " + i,
						lbPaymentDetailsInput("Approve", String.valueOf(i)), "value", "No");
				driverMethod.click("btnSelectAll", btnSelectAll);
				driverMethod.waitForInvisibilityOfElementLocated(CommonObject.imgLoading,
						Constant.DEFAULT_WAITTIME_SECONDS);
			}
		}
		Log.info("Select all function working correctly");
		TestngLogger.writeResult("Select all function working correctly", true);
	}
	
	
	
	
	
	
	
}

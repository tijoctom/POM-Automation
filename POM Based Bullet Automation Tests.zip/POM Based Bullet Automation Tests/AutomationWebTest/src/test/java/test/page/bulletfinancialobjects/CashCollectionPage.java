package test.page.bulletfinancialobjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.report.TestngLogger;

import test.page.bulletnetobjects.CommonObject;


public class CashCollectionPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	String title = "Bullet Financial - Cash Collection";
	private By btnRefresh = By.xpath("//input[@id='btnRefresh']");
	private By btnRefreshDefault = By.xpath("//input[@id='btnRefresh' and @value='9:00 to Refresh']");		
	private By btnPrint = By.xpath("//input[@id='btnPrint']");
	private By txtCashCollectionPrintGrid = By.xpath("//input[@id='cashcollectionyesno1']");
	private By btnEmailClient = By.xpath("//input[@id='btnEmailClient']");
	private By btnUpdate = By.xpath("//input[@id='btnUpdate']");
	private By btnSaveJournal = By.xpath("//input[@id='btnSaveJournal']");
	private By txtJournal = By.xpath("//textarea[@id='txtJournal']");
	private By btnClientStatement = By.xpath("//input[@id='btnClientStatement']");
	private By btnBankListOK = By.xpath("//input[@id='btnBankListOK']");
	private By ddlBankList = By.xpath("//select[@id='BankLists']");
	private By txtClientInfo = By.xpath("//p[@id='pClientInfo']");		
	private By lbBootboxMessage = By.xpath("//div[@class='bootbox-body']//td[2]");
	private By lbBootboxMessage2 = By.xpath("//div[@class='bootbox-body']");
//	private By lbJQMessage = By.xpath("//div[contains(@class,'jqimessage')]//td[2]");
	private By lbJQMessage2 = By.xpath("//div[contains(@class,'jqimessage')]//div[2]");
	private By btnOK = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");
	private By lstClientCodeFilter = By.xpath("//*[@id='divCashCollections']/span[1]/div/button");
	private By lstSellCurrency = By.xpath("//*[@id='divCashCollections']/span[2]/div/button");	
	private By chkBxFirstClient = By.xpath("//*[@id='divCashCollections']/span[1]/div/ul/li[3]/a/label/input");	
	private By lblFirstClient = By.xpath("//*[@id='divCashCollections']/span[1]/div/ul/li[3]/a/label");
	private By tblCashCollectionTableSize = By.xpath("//tbody[@id='ListOfCashCollection']/tr");
	private By lblClientCode(int i) {
		return By.xpath("//*[@id='ListOfCashCollection']/tr[" + i + "]/td[2]");
	}	
	
	public CashCollectionPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	public void verifyTitle() throws Exception{
		driverMethod.compareText("Title", driverMethod.getTitle(), title);
	}
	public void verifyClientStatement() throws Exception{
		String message = Common.getCellDataProvider(data, "Error message");
		String report = Common.getCellDataProvider(data, "Report Name");	
		driverMethod.click("btnClientStatement", btnClientStatement);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Error Message", lbBootboxMessage, message);
		// Click button OK
		driverMethod.click("btnOK", btnOK);
		// Select 1st row
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Click button btnClientStatement
		String vBaseWindowHandle = driverMethod.driver.getWindowHandle();
		int size = driverMethod.driver.getWindowHandles().size();	
		driverMethod.click("btnClientStatement", btnClientStatement);
		// Switch window		
		driverMethod.switchwindow(size);
		driverMethod.waitForVisibilityOfElementLocated(By.xpath("//*[@id='CrystalReportViewerBullet']"), Constant.LONG_WAITTIME_SECONDS);	
		// Get report name
		String url = driverMethod.driver.getCurrentUrl();
		String reportName = url.substring(url.lastIndexOf("reportName="));
		driverMethod.compareText("reportName", reportName, report);
		driverMethod.driver.switchTo().window(vBaseWindowHandle);	
	}
	public void verifyEmailClient() throws Exception {
		String message1 = Common.getCellDataProvider(data, "Error message1");
		String message2 = Common.getCellDataProvider(data, "Error message2");
		String message3 = Common.getCellDataProvider(data, "Success Message");
		String banklist = Common.getCellDataProvider(data, "Bank list");
	
		driverMethod.click("btnEmailClient", btnEmailClient);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage2, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Error Message", lbBootboxMessage2, message1);
		// Click button ok
		driverMethod.click("btnOk", btnOK);
		// Select yes in 1st row to print out data
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Click button email client
		driverMethod.click("btnEmailClient", btnEmailClient);
		// Click button btnBankListOK 
		driverMethod.click("btnBankListOK", btnBankListOK);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbJQMessage", lbBootboxMessage, message2);
		// Click button ok
		driverMethod.click("btnOk", btnOK);
		// Select banklist
		driverMethod.selectDDLByText("ddlBankList", ddlBankList, banklist);
		// Click button btnBankListOK 
		driverMethod.click("btnBankListOK", btnBankListOK);
		// Verify success message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbBootboxMessage", lbBootboxMessage, message3);	
	}
	public void verifyPrint() throws Exception{
		String report = Common.getCellDataProvider(data, "Report Name");
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Select yes in 1st row to print out data
		driverMethod.sendkeys("txtCashCollectionPrintGrid",  txtCashCollectionPrintGrid, "y");
		// Click button print
		String currentWindow = driverMethod.driver.getWindowHandle();		
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnPrint", btnPrint);
		// Switch window
		driverMethod.switchwindow(size);	
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.DEFAULT_WAITTIME_SECONDS);;
			// Get report name
		String url = driverMethod.driver.getCurrentUrl();
		String reportName = url.substring(url.lastIndexOf("reportName="));
		driverMethod.compareText("reportName", reportName, report);
		driverMethod.driver.switchTo().window(currentWindow);
	}
	public void verifyRefresh() throws Exception{
		String timer = Common.getCellDataProvider(data, "Timer");		
		driverMethod.click("btnRefresh", btnRefresh);		
		driverMethod.waitForVisibilityOfElementLocated(btnRefreshDefault, Constant.DEFAULT_WAITTIME_SECONDS);
		String text = driverMethod.getAttribute("btnRefresh", btnRefresh, "value");
		text= text.substring(0,text.indexOf(" "));
		// Verify that timer is refreshed
		driverMethod.compareText("btnRefresh", text, timer);
	}
	public void verifySaveJournal() throws Exception{	
		driverMethod.click("btnSaveJournal", btnSaveJournal);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbJQMessage2, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Error Message", lbJQMessage2, Common.getCellDataProvider(data, "Error message"));
		// Click button OK
		driverMethod.click("btnOK", btnOK);
		// Select yes in 1st row to print out data
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Click button btnSaveJournal
		driverMethod.click("btnSaveJournal", btnSaveJournal);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbJQMessage2, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Error Message", lbJQMessage2, Common.getCellDataProvider(data, "Error message2"));
		// Click button OK
		driverMethod.click("btnOK", btnOK);
		// Click button btnSaveJournal
		// Input Journal
		driverMethod.inputText("txtJournal", txtJournal, Common.getCellDataProvider(data, "Username"));
		driverMethod.click("btnSaveJournal", btnSaveJournal);
		// Verify success message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Success Message", lbBootboxMessage, Common.getCellDataProvider(data, "Success Message"));
	}
	public void verifyUpdate() throws Exception{
		String message = Common.getCellDataProvider(data, "Error message");
		String successmessage = Common.getCellDataProvider(data, "Success Message");
		
		driverMethod.click("btnUpdate", btnUpdate);
		// Verify error message
		driverMethod.waitForVisibilityOfElementLocated(lbJQMessage2, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("Error Message", lbJQMessage2, message);
		// Click button OK
		driverMethod.click("btnOK", btnOK);
		// Select yes in 1st row to print out data
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Click button update client
		driverMethod.click("btnUpdate", btnUpdate);
		// Verify success message
		driverMethod.waitForVisibilityOfElementLocated(lbBootboxMessage, Constant.DEFAULT_WAITTIME_SECONDS);		
		driverMethod.verifyText("Success Message", lbBootboxMessage, successmessage);		
	}
	public void verifyViewClientDetail() throws Exception{
		// Verify client info field is empty
		driverMethod.verifyText("txtClientInfo", txtClientInfo, "");
		// Select 1st row
		driverMethod.click("txtCashCollectionPrintGrid", txtCashCollectionPrintGrid);
		// Verify client info field is not empty	
		driverMethod.verifyNotEqualText("txtClientInfo",txtClientInfo, "");
	}
	public void verifyFilter() throws Exception {
		driverMethod.findElement(lstClientCodeFilter);
		driverMethod.findElement(lstSellCurrency);
		driverMethod.clickByJS("clickfirstchkbox", chkBxFirstClient);
		WebElement element = driverMethod.driver.findElement(lblFirstClient);
		String clientcode = element.getAttribute("title").trim();
		clientcode = clientcode.substring(clientcode.lastIndexOf(" ") + 1, clientcode.length());
		driverMethod.waitForPageLoad();
		int size = driverMethod.driver.findElements(tblCashCollectionTableSize).size();
		for (int i = 1; i <= size; i++) {
			String tablecode = driverMethod.getText("", lblClientCode(i)).trim();
			if (tablecode.contains(clientcode)) {
				TestngLogger.writeResult(
						"Filtered out client code: " + clientcode + " is present in the table row: " + i, false);
			} else {
				TestngLogger.writeResult("Filtered out client code: " + clientcode + " is not present in table row: "
						+ i + ".Client code in table row " + i + " is " + tablecode, true);
			}
		}
	}
}

package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

public class ForgetPasswordPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtUsername = By.xpath(".//*[@id='UserName']");
	private By btnContinue = By.xpath("//input[@type='submit']");
	private By txtAnswer = By.xpath(".//*[@id='Answer']");
	private By btnSubmit = By.xpath("//input[@type='submit']");
	private By lblMessage = By.xpath(".//*[@id='jqistate_state0']/div[2]");
	
	public ForgetPasswordPage(WebDriverMethod driverMethod, Object [] data) {		
		this.driverMethod = driverMethod;
		this.data = data;
		driverMethod.waitForPageLoad();
		Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
	}
	
	public void ForgotPasswordSubmitUsername() throws Exception {
		driverMethod.inputText("txtUsername", txtUsername, Common.getCellDataProvider(data,"Username"));;
		// Click on continue button		
		driverMethod.click("btnContinue", btnContinue);
		
	}
	public void ForgotPasswordSubmitPassword() throws Exception {
		// Input the Answer
		driverMethod.inputText("txtAnswer", txtAnswer, Common.getCellDataProvider(data,"Answer"));;
		// Click Reset Password button		
		driverMethod.click("btnSubmit", btnSubmit);	
		
	}
	
	public void ForgotPasswordFail() throws Exception {
		driverMethod.waitForVisibilityOfElementLocated(lblMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"VerifyMessage"));
		
	}
	
	public void ForgotPasswordSuccess() throws Exception {	
		driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"VerifyMessage"));
	}

}

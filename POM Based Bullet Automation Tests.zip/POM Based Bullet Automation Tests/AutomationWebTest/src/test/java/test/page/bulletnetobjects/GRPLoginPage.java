package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;


public class GRPLoginPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By txtUsername = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_EmailLogin_txtEmail']");
	private By txtPassword = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_EmailLogin_txtPassword']");
	private By btnLogin = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_EmailLogin_cmdOk']");
	private By lblMessage = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_lblStatus']");
	private By btnVerify = By.xpath("//*[@id='ctl00_ContentPlaceHolder1_EmailLogin_MobileAuth_btnValidateMobile']");
	
	
	public GRPLoginPage(WebDriverMethod driverMethod, Object [] data) throws Exception {		
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void LoginSubmit() throws Exception {
		String url = Common.getCellDataProvider(data, "URL");
		driverMethod.openUrl(url+":7315/SuspendedAccount/Forms/frmLogin.aspx");
		driverMethod.inputText("user name", txtUsername, Common.getCellDataProvider(data,"Username"));
		driverMethod.inputText("password", txtPassword, Common.getCellDataProvider(data,"Password"));
		driverMethod.click("Login", btnLogin);
	}
	
	public void verify() throws Exception{
		String query = "update tblCompanies set tol ="+Common.getCellDataProvider(data, "TOL")+" , bitSuspended ="+Common.getCellDataProvider(data, "bitSuspended")+" where clientcode='test3019' and groupid="+Common.getCellDataProvider(data, "groupid");		
		SqlServerJDBC.executeQuery(query);
		if (Common.getCellDataProvider(data, "Status").equalsIgnoreCase("1")){
			LoginSubmit();
			verifyLoginSuccess();
		}
		else if(Common.getCellDataProvider(data, "Status").equalsIgnoreCase("0")){
			LoginSubmit();
			verifyLoginUnsuccess();
		}
	}
	public void verifyLoginUnsuccess() throws Exception {
		driverMethod.isElementIsDisplayed("lblMessage", lblMessage, true);
		driverMethod.verifyContainText("lblMessage", lblMessage, Common.getCellDataProvider(data, "Message"));	
		
	}
	
	public void verifyLoginSuccess() throws Exception {	
		driverMethod.isElementIsDisplayed("btnVerify", btnVerify, true);
		
	}

}

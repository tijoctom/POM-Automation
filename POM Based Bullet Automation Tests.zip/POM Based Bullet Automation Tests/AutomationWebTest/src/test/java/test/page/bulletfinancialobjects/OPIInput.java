package test.page.bulletfinancialobjects;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;


public class OPIInput{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	private By ckcIsNewPayee = By.xpath("//input[contains(@id,'IsNewPayee')]");
	private By ckcIsAddNewTemplateName = By.xpath(".//*[@id='BenificiaryDetails_IsAddNewTemplateName']");
	
	private By ddlBenificiaryDetails_OPIID = By.xpath("//select[@id='BenificiaryDetails_OPIID']");
	private By btnDelete = By.xpath("//input[@id='btnDelete']");
	private By btnYesButton = By.xpath("//button[contains(.,'Yes')]");
	private By btnNoButton = By.xpath("//button[contains(.,'No')]");		
	
	// 
	private By tblDealListRow = By.xpath("//*[@id='tblDealList']/tbody/tr");
	private By tblDealListSelect(int i) {
		return By.xpath(".//*[@id='tblDealList']/tbody/tr["+i+"]/td[1]/input");
	}
	private By tblDealListValue(int i) {
		return By.xpath(".//*[@id='tblDealList']/tbody/tr["+i+"]/td[4]/input");
	}
	// Beneficiary Details
	private By txtBenificiaryDetails_TemplateName = By.xpath("//input[@id='BenificiaryDetails_TemplateName']");	
	private By ddlClientCode = By.xpath("//*[@id='frmOPIInput']/div[1]/div[1]/div[2]/div[2]/span[1]/span[1]/span");	
	private By ddlClientCodeOption = By.xpath("//span[1]/input");	
	private By txtNotesToBenificiary = By.xpath(".//*[@id='BenificiaryDetails_NotesToBenificiary']");			
	private By txtBenificiaryDetails_BenificiaryName = By.xpath(".//*[@id='BenificiaryDetails_BenificiaryName']");			
	private By ddlBenificiaryDetails_Currency = By.xpath(".//*[@id='select2-BenificiaryDetails_Currency-container']");
	private By ddlBenificiaryDetails_CurrencyOption = By.xpath("//span[1]/input");
	private By txtBenificiaryDetails_Amount = By.xpath(".//*[@id='BenificiaryDetails_Amount']");			
	private By txtBenificiaryDetails_AcNo = By.xpath(".//*[@id='BenificiaryDetails_AcNo']");	
	private By ddlBenificiaryDetails_PaymentType = By.xpath(".//*[@id='BenificiaryDetails_PaymentType']");	
	private By txtBenificiaryDetails_Charge = By.xpath(".//*[@id='BenificiaryDetails_Charge']");
	private By txtBenificiaryDetails_NotesToBenificiary2 = By.xpath(".//*[@id='BenificiaryDetails_NotesToBenificiary2']");
	private By txtNotesToBenificiary3 = By.xpath(".//*[@id='BenificiaryDetails_NotesToBenificiary3']");	
	private By ddlBenificiaryDetails_NotesToBenificiary4 = By.xpath("//input[@id='BenificiaryDetails_NotesToBenificiary4']");
	
	// Beneficiary Address Details
	private By txtBenificiaryAddressDetails_Address1 = By.xpath(".//*[@id='BenificiaryAddressDetails_Address1']");
	private By txtBenificiaryAddressDetails_Address2 = By.xpath(".//*[@id='BenificiaryAddressDetails_Address2']");
	private By txtBenificiaryAddressDetails_Address3 = By.xpath(".//*[@id='BenificiaryAddressDetails_Address3']");	
	private By ddlNationality = By.xpath("//*[@id='frmOPIInput']/div[3]/div[2]/div[2]/div[2]/span/span[1]/span");	
//	private By ddlNationality = By.xpath(".//*[@id='frmOPIInput']/div[3]/div[2]/div[2]/div[2]/span");	
	private By ddlOptionNationality = By.xpath("//span[1]/input");			
	
	// Beneficiary Bank Details		
	private By txtBenificiaryBankDetails_BankName = By.xpath(".//*[@id='BenificiaryBankDetails_BankName']");
	private By txtBenificiaryBankDetails_Address1 = By.xpath(".//*[@id='BenificiaryBankDetails_Address1']");
	private By txtBenificiaryBankDetails_City = By.xpath("//input[@id='BenificiaryBankDetails_City']");
	private By ddlBenificiaryBankDetails_Country = By.xpath(".//*[@id='select2-BenificiaryBankDetails_Country-container']");
	private By ddlBenificiaryBankDetails_CountryOption = By.xpath("//span[1]/input");		
	private By txtBenificiaryBankDetails_SwiftCode = By.xpath(".//*[@id='BenificiaryBankDetails_SwiftCode']");	
	private By txtBenificiaryBankDetails_SortCode = By.xpath(".//*[@id='BenificiaryBankDetails_SortCode']");	
	private By txtBenificiaryBankDetails_BankCode = By.xpath(".//*[@id='BenificiaryBankDetails_BankCode']");	
	
	// Intermediary Bank Details
	private By txtIntermediaryBankDetails_BankName = By.xpath(".//*[@id='IntermediaryBankDetails_BankName']");
	private By txtIntermediaryBankDetails_Address1 = By.xpath(".//*[@id='IntermediaryBankDetails_Address1']");
	private By txtIntermediaryBankDetails_City = By.xpath(".//*[@id='IntermediaryBankDetails_City']");
	private By ddlIntermediaryBankDetails_Country = By.xpath(".//*[@id='select2-IntermediaryBankDetails_Country-container']");
	private By ddlIntermediaryBankDetails_CountryOption = By.xpath("//span[1]/input");
	private By txtIntermediaryBankDetails_SwiftCode = By.xpath(".//*[@id='IntermediaryBankDetails_SwiftCode']");
	private By txtIntermediaryBankDetails_AccountNumber = By.xpath(".//*[@id='IntermediaryBankDetails_AccountNumber']");

	private By btnReset = By.xpath(".//*[@id='btnReset']");	
	private By btnInsert = By.xpath("//input[@value='Insert']");	
	private By btnSave = By.xpath("//input[@value='Save']");		
	private By lblMessage = By.xpath("//div[@class='bootbox-body']//td[2]");
	private By btnInsertOkButton = By.xpath("//button[contains(.,'Ok')]");	
	private By btnYes = By.xpath(".//*[@id='jqi_state0_buttonYes']");	
	private By lblMandateMess = By.xpath(".//*[@id='jqistate_state0']/div[2]/div/div[2]");	
		
	private By lblDealValue = By.xpath("//input[contains(@id,'AmountToUse')]");
	
	
	
	public OPIInput(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void inputDealnoAmount() throws Exception{
		int size = driverMethod.driver.findElements(tblDealListRow).size();
		for (int i=2;i<=size; i++){
			if (i==2)
				driverMethod.sendkeys("tblDealListSelect2", tblDealListSelect(2), "y");
			else
				driverMethod.sendkeys("tblDealListSelect"+i, tblDealListSelect(i), "N");
		}
		
		for(int i=0; i<=10; i++){
			driverMethod.sendkeys("lblDealValue", tblDealListValue(2),Keys.BACK_SPACE);
		}
		driverMethod.sendkeys("lblDealValue", tblDealListValue(2), Common.getCellDataProvider(data,"Amount"));	
		
	}
	public void inputDataNotSelectClientCode() throws Exception{
		// Enter Notes To Benificiary		
		driverMethod.inputText("txtNotesToBenificiary", txtNotesToBenificiary, Common.getCellDataProvider(data,"Benificiary"));	
		// Enter Benificiary 3		
		driverMethod.inputText("txtNotesToBenificiary3", txtNotesToBenificiary3, Common.getCellDataProvider(data,"Benificiary 3"));	
		// Enter Benificiary Name
		driverMethod.inputText("txtBenificiaryDetails_BenificiaryName", txtBenificiaryDetails_BenificiaryName, Common.getCellDataProvider(data,"Benificiary Name"));	
		// Enter Currency
		driverMethod.click("ddlBenificiaryDetails_Currency", ddlBenificiaryDetails_Currency);
		driverMethod.sendkeys("ddlBenificiaryDetails_CurrencyOption", ddlBenificiaryDetails_CurrencyOption, Common.getCellDataProvider(data,"Currency"));	
		driverMethod.sendkeys("ddlBenificiaryDetails_CurrencyOption", ddlBenificiaryDetails_CurrencyOption,Keys.ENTER);
		// Enter Amount
		if (!Common.getCellDataProvider(data,"Amount").equalsIgnoreCase("")){
			for(int i=0; i<=10; i++){
				driverMethod.sendkeys("txtBenificiaryDetails_Amount", txtBenificiaryDetails_Amount,Keys.BACK_SPACE);
			}				
			driverMethod.sendkeys("txtBenificiaryDetails_Amount", txtBenificiaryDetails_Amount, Common.getCellDataProvider(data,"Amount"));
			
		}	
		// Enter AC No or IBAN
		driverMethod.inputText("txtBenificiaryDetails_AcNo", txtBenificiaryDetails_AcNo, Common.getCellDataProvider(data,"AcNo"));
		// Select Payment Type*		
		driverMethod.inputText("ddlBenificiaryDetails_PaymentType", ddlBenificiaryDetails_PaymentType, Common.getCellDataProvider(data,"Payment Type"));	
		// Select Charge
		driverMethod.inputText("txtBenificiaryDetails_Charge", txtBenificiaryDetails_Charge, Common.getCellDataProvider(data,"Charge"));	
		// Enter Notes To Benificiary 2
		driverMethod.inputText("txtBenificiaryDetails_NotesToBenificiary2", txtBenificiaryDetails_NotesToBenificiary2, Common.getCellDataProvider(data,"Beneficiary 2"));
		// Enter Notes To Benificiary 3
		driverMethod.inputText("txtBenificiaryDetails_NotesToBenificiary3", txtNotesToBenificiary3, Common.getCellDataProvider(data,"Beneficiary 3"));
		// Select Benificiary 4
		driverMethod.click("ddlBenificiaryDetails_NotesToBenificiary4", ddlBenificiaryDetails_NotesToBenificiary4);
		driverMethod.inputText("ddlBenificiaryDetails_NotesToBenificiary4", ddlBenificiaryDetails_NotesToBenificiary4, "Purchase of goods or services");
						
		// Beneficiary Address Details
		// Enter Address 1
		driverMethod.inputText("txtBenificiaryAddressDetails_Address1", txtBenificiaryAddressDetails_Address1, Common.getCellDataProvider(data,"Address 1"));
		// Enter Address 2
		driverMethod.inputText("txtBenificiaryAddressDetails_Address2", txtBenificiaryAddressDetails_Address2, Common.getCellDataProvider(data,"Address 2"));
		// Enter Address 3
		driverMethod.inputText("txtBenificiaryAddressDetails_Address3", txtBenificiaryAddressDetails_Address3, Common.getCellDataProvider(data,"Address 3"));
		// Select Nationality
		driverMethod.click("ddlNationality", ddlNationality);
		driverMethod.sendkeys("ddlOptionNationality", ddlOptionNationality, Common.getCellDataProvider(data,"Nationality"));
		driverMethod.sendkeys("ddlOptionNationality", ddlOptionNationality, Keys.ENTER);
		// Beneficiary Bank Details			
		// Enter Beneficiary Bank Name
		driverMethod.inputText("txtBenificiaryBankDetails_BankName", txtBenificiaryBankDetails_BankName, Common.getCellDataProvider(data,"Bank Name"));
		// Enter Address 1
		driverMethod.inputText("txtBenificiaryBankDetails_Address1", txtBenificiaryBankDetails_Address1, Common.getCellDataProvider(data,"Address 1"));
		// Enter City
		driverMethod.inputText("txtBenificiaryBankDetails_City", txtBenificiaryBankDetails_City, Common.getCellDataProvider(data,"City"));
		// Select Country
		driverMethod.click("ddlBenificiaryBankDetails_Country", ddlBenificiaryBankDetails_Country);
		driverMethod.sendkeys("ddlBenificiaryBankDetails_CountryOption", ddlBenificiaryBankDetails_CountryOption, Common.getCellDataProvider(data,"Bank Details Nationality"));
		driverMethod.sendkeys("ddlBenificiaryBankDetails_CountryOption", ddlBenificiaryBankDetails_CountryOption, Keys.ENTER);
		// Enter Swift Code (BIC)
		driverMethod.inputText("txtBenificiaryBankDetails_SwiftCode", txtBenificiaryBankDetails_SwiftCode, Common.getCellDataProvider(data,"Swift Code"));
		// Enter Sort Code (UK)
		driverMethod.inputText("txtBenificiaryBankDetails_SortCode", txtBenificiaryBankDetails_SortCode, Common.getCellDataProvider(data,"Sort Code"));
		// Enter Bank Code
		driverMethod.inputText("txtBenificiaryBankDetails_BankCode", txtBenificiaryBankDetails_BankCode, Common.getCellDataProvider(data,"Bank Code"));
		// Intermediary Bank Details
		// Enter Bank name
		driverMethod.inputText("txtIntermediaryBankDetails_BankName", txtIntermediaryBankDetails_BankName, Common.getCellDataProvider(data,"Bank Name"));
		// Enter Address 1
		driverMethod.inputText("txtIntermediaryBankDetails_Address1", txtIntermediaryBankDetails_Address1, Common.getCellDataProvider(data,"Address 1"));
		// Enter City
		driverMethod.inputText("txtIntermediaryBankDetails_City", txtIntermediaryBankDetails_City, Common.getCellDataProvider(data,"City"));
		// Select Country
		driverMethod.click("ddlIntermediaryBankDetails_Country", ddlIntermediaryBankDetails_Country);
		driverMethod.sendkeys("ddlIntermediaryBankDetails_CountryOption", ddlIntermediaryBankDetails_CountryOption, Common.getCellDataProvider(data,"Bank Details Nationality"));
		driverMethod.sendkeys("ddlIntermediaryBankDetails_CountryOption", ddlIntermediaryBankDetails_CountryOption, Keys.ENTER);
		
		// Enter Swift Code (BIC)
		driverMethod.inputText("txtIntermediaryBankDetails_SwiftCode", txtIntermediaryBankDetails_SwiftCode, Common.getCellDataProvider(data,"Swift Code"));
		// Enter Sort Code (UK)
		driverMethod.inputText("txtIntermediaryBankDetails_AccountNumber", txtIntermediaryBankDetails_AccountNumber, Common.getCellDataProvider(data,"Account Number"));		
			
	}
	public void inputData() throws Exception{
		// Enter the client code		
		driverMethod.click("ddlClientCode", ddlClientCode);
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.sendkeys("ddlClientCodeOption", ddlClientCodeOption, Common.getCellDataProvider(data,"Client Code"));
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);	
		driverMethod.sendkeys("ddlClientCodeOption", ddlClientCodeOption, Keys.ENTER);
		inputDataNotSelectClientCode();
	}
	public void verifyAddTemplate() throws Exception{
		int randomInt = 0;
		Random rd = new Random();
		for (int idx = 1000; idx <= 100000; ++idx) {
			randomInt = rd.nextInt(100000);
		}		
		String TempName = Common.getCellDataProvider(data,"Template Name");
		String TemplateName = TempName + randomInt;
		
		// Enter Template Name
		driverMethod.sendkeys("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, TemplateName);	
		inputData();
		driverMethod.click("btnSave", btnSave);
		verifyMessage();
	}
	public void verifyCancelEditTemplate() throws Exception{
		// Uncheck NewPayee		
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);	
		// Select Template Name
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"BenificiaryDetails_OPIID"));
		inputData();
		driverMethod.click("btnSave", btnSave);
		verifyMessage();
	}
	public void verifyCopyTemplate() throws Exception{
		// Uncheck NewPayee		
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select Template Name
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"BenificiaryDetails_OPIID"));			
		// Uncheck NewPayee		
		driverMethod.click("ckcIsAddNewTemplateName", ckcIsAddNewTemplateName);
		// Enter Template Name
		// Get random name
		int randomInt = new Random().nextInt(100000);
		
		String Name = Common.getCellDataProvider(data,"Template Name");
		String TemplateName = Name + randomInt;
		driverMethod.sendkeys("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, TemplateName);	
		inputData();
		driverMethod.click("btnSave", btnSave);
		// Verify the result
		verifyMessage();
		driverMethod.click("btnInsertOkButton", btnInsertOkButton);
	
	}
	public void verifyDeleteCancel() throws Exception{
		// Click on IsNewPayee to uncheck
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select the template that need to removed
		driverMethod.sendkeys("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"Benificiary Details"));	
		// Click on Delete button
		driverMethod.click("btnDelete", btnDelete);
		// Click on No button
		driverMethod.click("btnNoButton", btnNoButton);
		// Verify not deleted		
		driverMethod.verifyDisplayDDL("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"Benificiary Details"));

	}
	public void verifyDeleteMandate() throws Exception{
		// Click on IsNewPayee to uncheck
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select the template that need to removed
		driverMethod.sendkeys("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"Benificiary Details"));	
		// Click on Delete button
		driverMethod.click("btnDelete", btnDelete);
		// Click on Yes button
		driverMethod.click("btnYesButton", btnYesButton);
		// Verify the message
		verifyMessage();		
	}
	
	public void verifyDeleteTemplate() throws Exception{
		
		int randomInt = 0;
		Random rd = new Random();
		for (int idx = 1000; idx <= 100000; ++idx) {
			randomInt = rd.nextInt(100000);
		}		
		String TempName = Common.getCellDataProvider(data,"Template Name");
		String TemplateName = TempName + randomInt;
		
		// Enter Template Name
		driverMethod.sendkeys("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, TemplateName);	
		inputData();
		driverMethod.click("btnSave", btnSave);
		driverMethod.click("btnInsertOkButton", btnInsertOkButton);		
		// Click on IsNewPayee to uncheck
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select the template that need to removed		
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, TemplateName);	
		// Click on Delete button
		driverMethod.click("btnDelete", btnDelete);
		// Click on Yes button
		driverMethod.click("btnYesButton", btnYesButton);
		// Verify the result
		verifyMessage();
	}
	public void verifyEditOPITemplate() throws Exception{
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select Template Name
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"BenificiaryDetails_OPIID"));
		inputData();
		driverMethod.click("btnSave", btnSave);
		// Click on Yes button				
		driverMethod.click("btnbuttonYes", btnYes);
				
		// Verify the result
		verifyMessage();
		
	}
	public void verifyEditOPITemplateMandate() throws Exception{
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select Template Name
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"BenificiaryDetails_OPIID"));
		inputData();
		driverMethod.click("btnSave", btnSave);
		// Click on Yes button				
		driverMethod.click("btnbuttonYes", btnYes);
				
		// Verify the result
		verifyMessage();
		
	}
	public void verifyEditTempValidation() throws Exception{
		driverMethod.click("ckcIsNewPayee", ckcIsNewPayee);
		// Select Template Name
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID", ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"BenificiaryDetails_OPIID"));
		inputData();
		driverMethod.click("btnSave", btnSave);
		// Verify empty address 1 
		verifyMessage();
	}
	public void verifyInsertButton() throws Exception{
		// Enter Template Name
		
		driverMethod.sendkeys("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, Common.getCellDataProvider(data,"Template Name"));	
		inputData();
		// Click on Insert button
		driverMethod.click("btnInsert", btnInsert);		
		// Verify the result
		verifyMessage();
	}
	public void verifyResetButton() throws Exception{
		// Enter Template Name
		driverMethod.sendkeys("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, Common.getCellDataProvider(data,"Template Name"));	
		inputData();
		// Click on Reset button
		driverMethod.click("btnReset", btnReset);		
		// Verify all field should be reset
		// Beneficiary Details
		driverMethod.verifyAttribute("txtBenificiaryDetails_TemplateName", txtBenificiaryDetails_TemplateName, "value", "");
		
//		driverMethod.verifyAttribute("ddlClientCode", ddlClientCode, "value", "");
		driverMethod.verifyAttribute("txtNotesToBenificiary", txtNotesToBenificiary, "value", "");
		driverMethod.verifyAttribute("txtNotesToBenificiary3", txtNotesToBenificiary3, "value", "");		
		driverMethod.verifyAttribute("txtBenificiaryDetails_BenificiaryName", txtBenificiaryDetails_BenificiaryName, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryDetails_AcNo", txtBenificiaryDetails_AcNo, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryDetails_NotesToBenificiary2", txtBenificiaryDetails_NotesToBenificiary2, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryAddressDetails_Address1", txtBenificiaryAddressDetails_Address1, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryAddressDetails_Address2", txtBenificiaryAddressDetails_Address2, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryAddressDetails_Address3", txtBenificiaryAddressDetails_Address3, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_BankName", txtBenificiaryBankDetails_BankName, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_BankName", txtBenificiaryBankDetails_BankName, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_Address1", txtBenificiaryBankDetails_Address1, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_City", txtBenificiaryBankDetails_City, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_SwiftCode", txtBenificiaryBankDetails_SwiftCode, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_SortCode", txtBenificiaryBankDetails_SortCode, "value", "");
		driverMethod.verifyAttribute("txtBenificiaryBankDetails_BankCode", txtBenificiaryBankDetails_BankCode, "value", "");
		driverMethod.verifyAttribute("txtIntermediaryBankDetails_BankName", txtIntermediaryBankDetails_BankName, "value", "");
		driverMethod.verifyAttribute("txtIntermediaryBankDetails_Address1", txtIntermediaryBankDetails_Address1, "value", "");
		driverMethod.verifyAttribute("txtIntermediaryBankDetails_City", txtIntermediaryBankDetails_City, "value", "");		
		driverMethod.verifyAttribute("txtIntermediaryBankDetails_SwiftCode", txtIntermediaryBankDetails_SwiftCode, "value", "");
		driverMethod.verifyAttribute("txtIntermediaryBankDetails_AccountNumber", txtIntermediaryBankDetails_AccountNumber, "value", "");
		/*
		driverMethod.verifyDisplayDDL("ddlBenificiaryBankDetails_Country", ddlBenificiaryBankDetails_Country, "");
		driverMethod.verifyDisplayDDL("txtBenificiaryDetails_Charge", txtBenificiaryDetails_Charge, "B");
		driverMethod.verifyDisplayDDL("ddlBenificiaryDetails_NotesToBenificiary4", ddlBenificiaryDetails_NotesToBenificiary4, "----");
		driverMethod.verifyDisplayDDL("ddlBenificiaryDetails_Currency", ddlBenificiaryDetails_Currency, Common.getCellDataProvider(data,"Currency"));
		driverMethod.verifyDisplayDDL("txtBenificiaryDetails_Amount", txtBenificiaryDetails_Amount, Common.getCellDataProvider(data,"Amount"));
		driverMethod.verifyDisplayDDL("ddlBenificiaryDetails_PaymentType", ddlBenificiaryDetails_PaymentType, "Standard");
		driverMethod.verifyDisplayDDL("ddlNationality", ddlNationality, "");
		driverMethod.verifyDisplayDDL("ddlIntermediaryBankDetails_Country", ddlIntermediaryBankDetails_Country, "");
			*/
	}
	public void verifyMessage() throws Exception{
		int temp = 0;
		for (int time = 0; time < Constant.DEFAULT_WAITTIME_SECONDS; time += Constant.TIMEOUT_STEPS_SECONDS) {
			try {
				if (driverMethod.displayedElement(lblMessage))
					temp =0;
				else if (driverMethod.displayedElement(lblMandateMess))
					temp=1;
				break;
			} catch (Exception e) {
				Common.sleep(Constant.TIMEOUT_STEPS_SECONDS);
			}
		}
		if (temp ==0)
			driverMethod.verifyText("lblMessage", lblMessage, Common.getCellDataProvider(data,"Verify"));		
		else if (temp ==1)
			driverMethod.verifyText("lblMandateMess", lblMandateMess, Common.getCellDataProvider(data,"Verify"));		
				
	}
	public void verifyChangeAmountToUse() throws Exception{
		driverMethod.sendkeys("lblDealValue", lblDealValue, Keys.HOME);
		driverMethod.sendkeys("lblDealValue", lblDealValue, Common.getCellDataProvider(data,"DealValue"));	
		driverMethod.sendkeys("lblDealValue", lblDealValue, Keys.TAB);
		verifyMessage();
	}
	public void verifyChangeAmountValue() throws Exception{
		// Select OPI
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID",  ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"OPI"));
		inputDataNotSelectClientCode();
		driverMethod.click("btnSave", btnSave);
		// Verify the result
		verifyMessage();
	}
	public void verifyFieldValidation() throws Exception{
		// Select OPI
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID",  ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"OPI"));
		inputDataNotSelectClientCode();
		driverMethod.click("btnSave", btnSave);
		// Verify the result
		verifyMessage();
	}
	public void verifySaveExistingOPI() throws Exception{
		// Select OPI
		driverMethod.selectDDLByText("ddlBenificiaryDetails_OPIID",  ddlBenificiaryDetails_OPIID, Common.getCellDataProvider(data,"OPI"));		
		inputDealnoAmount();
		inputDataNotSelectClientCode();
		driverMethod.click("btnSave", btnSave);
		// Verify the result
		verifyMessage();
	}
}

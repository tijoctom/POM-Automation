package test.page.bulletfinancialobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;

import test.common.WebProjectConstant;
import test.page.bulletnetobjects.CommonObject;

public class VariationMarginPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators
	String title = "Bullet Financial - Variation Margin";
	private By btnRefresh = By.xpath("//*[@id='time']");
	private By btnPrintVMClientList = By.xpath("//*[@id='btnPrintVMClientList']");
	private By btnVariantMarginUpdate = By.xpath("//*[@id='btnVariantMargin_Update']");
	private By btnVariationMarginEmailClient = By.xpath("//*[@id='VariationMargin_EmailClientButton']");
	private By btnVariationMarginSaveJournal = By.xpath("//*[@id='btnVariationMarginSaveJournal']");
	private By btnVariationMarginUpdateNote = By.xpath("//*[@id='VariationMargin_UpdateNoteButton']");
	private By btnClientStatement = By.xpath("//*[@id='btnClientStatement']");
	private By txtVariationMarginJournalNotes = By.xpath("//*[@id='VariationMargin_JournalNotesTextbox']");
	private By txtVariationMarginUpdateNotes = By.xpath("//*[@id='txtNote']");
	private By tblVariationMarginClientListItem = By.xpath("//*[@id='tblVariationMarginClientList']/tbody/tr[1]");
	private By ddlStatus = By.xpath("//*[@id='Status']");
	private By lbErrorMessage = By.xpath("//div[@class='bootbox-body']//td[2]");
	private By lbSuccessMessage = By.xpath("//div[@class='bootbox-body']");
	private By btnOK = By.xpath("//button[contains(translate(., 'OK', 'ok'),'ok')]");
	private By btnOkEmail = By.xpath(".//*[@id='VMEmailOptionOKButton']");
	
	
	public VariationMarginPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void verifyTitle() throws Exception{
		driverMethod.compareText("Title", driverMethod.getTitle(), title);
	}
	public void verifyClientStatement() throws Exception{
		String errormessage = Common.getCellDataProvider(data, "Error Message");
		String report = Common.getCellDataProvider(data, "Report Name");		
		// Click button btnClientStatement
		driverMethod.click("btnClientStatement", btnClientStatement);
		//
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbErrorMessage", lbErrorMessage, errormessage);
		// Click butotn OK
		driverMethod.click("btnOk", btnOK);
		// Select Item in 1st row
		driverMethod.click("tblVariationMarginClientListItem", tblVariationMarginClientListItem);
		// Click button btnClientStatement
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnClientStatement", btnClientStatement);
		driverMethod.switchwindow(size);
		driverMethod.waitForVisibilityOfElementLocated(By.xpath("//*[@id='CrystalReportViewerBullet']"), Constant.LONG_WAITTIME_SECONDS);
		
		// Get report name
		String url = driverMethod.driver.getCurrentUrl();
		url = url.substring(url.lastIndexOf("reportName="));
		String reportName = url.substring(0, url.indexOf("&"));
		// Verify report name
		driverMethod.compareText("Url", reportName, report);
	}
	public void verifyEmailClient() throws Exception{
		String errormessage = Common.getCellDataProvider(data, "Error Message");				
		
		String filename =  System.getProperty("user.dir") + Common.correctPath(WebProjectConstant.testResourcePath)+Common.getCellDataProvider(data, "File Name") ;
	
		driverMethod.click("btnVariationMarginEmailClient", btnVariationMarginEmailClient);
		//
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbErrorMessage", lbErrorMessage, errormessage);
		// Click butotn OK
		driverMethod.click("btnOk", btnOK);
		// Select Item in 1st row
		driverMethod.click("tblVariationMarginClientListItem", tblVariationMarginClientListItem);			
		// Click button btnVariationMarginEmailClient
		driverMethod.click("btnVariationMarginEmailClient", btnVariationMarginEmailClient);
		// Click button oK
		driverMethod.click("btnOkEmail", btnOkEmail);
		driverMethod.isFileAvailable(filename);
		driverMethod.deleteFile(filename);
	}
	public void verifyPrintVMClient() throws Exception{
		String report = Common.getCellDataProvider(data, "Report Name");
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.click("btnPrintVMClientList", btnPrintVMClientList);
		driverMethod.switchwindow(size);		
		driverMethod.waitForVisibilityOfElementLocated(CommonObject.crystalreport, Constant.LONG_WAITTIME_SECONDS);		
		
		// Get report name
		String url = driverMethod.driver.getCurrentUrl();
		url = url.substring(url.lastIndexOf("reportName="));
		String reportName = url.substring(0, url.indexOf("&"));
		// Verify report name
		driverMethod.compareText("Url", reportName, report);
	}
	public void verifyRefresh() throws Exception{
		String timer = Common.getCellDataProvider(data, "Timer");
		driverMethod.click("btnRefresh", btnRefresh);		
		String text = driverMethod.getAttribute("btnRefresh", btnRefresh, "value");
		text= text.substring(0,text.indexOf(" "));
		// Verify that timer is refreshed
		driverMethod.compareText("btnRefresh", text, timer);
	}
	public void verifySaveJournal() throws Exception{
		String errormessage = Common.getCellDataProvider(data, "Error Message");
		String successmessage = Common.getCellDataProvider(data, "Success Message");		
		String journalmessage = Common.getCellDataProvider(data, "Journal Message");		
		// Click button Save Journal
		driverMethod.click("btnVariationMarginSaveJournal", btnVariationMarginSaveJournal);
		//
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbErrorMessage", lbErrorMessage, errormessage);
		// Click butotn OK
		driverMethod.click("btnOk", btnOK);
		// Select Item in 1st row
		driverMethod.click("tblVariationMarginClientListItem", tblVariationMarginClientListItem);
		// Input journal
		driverMethod.inputText("txtVariationMarginJournalNotes", txtVariationMarginJournalNotes, journalmessage);
		// Click button update
		driverMethod.click("btnVariationMarginSaveJournal", btnVariationMarginSaveJournal);
		// Verify message 
		driverMethod.waitForVisibilityOfElementLocated(lbSuccessMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbMessage", lbSuccessMessage, successmessage);		
				
	}
	public void verifyUpdateClient() throws Exception{
		String errormessage = Common.getCellDataProvider(data, "Error Message");
		String status = Common.getCellDataProvider(data, "Status");
		String successmessage = Common.getCellDataProvider(data, "Success Message");
		// Click button UpDate
		driverMethod.click("btnVariantMarginUpdate", btnVariantMarginUpdate);		
		// Verify message 
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbMessage", lbErrorMessage, errormessage);
		// Click butotn OK
		driverMethod.click("btnOk", btnOK);
		// Select Item in 1st row
		driverMethod.click("tblVariationMarginClientListItem", tblVariationMarginClientListItem);
		// Select Status
		driverMethod.selectDDLByText("ddlStatus", ddlStatus, status);
		// Click button update
		driverMethod.click("btnVariantMarginUpdate", btnVariantMarginUpdate);
		// Verify message 
		driverMethod.waitForVisibilityOfElementLocated(lbSuccessMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbMessage", lbSuccessMessage, successmessage);
		
	}
	public void verifyUpdateNotes() throws Exception{
		String errormessage = Common.getCellDataProvider(data, "Error Message");
		String successmessage = Common.getCellDataProvider(data, "Success Message");		
		String notemessage = Common.getCellDataProvider(data, "Note Message");		
		// Click button Update Note
		driverMethod.click("btnVariationMarginUpdateNote", btnVariationMarginUpdateNote);
		//
		driverMethod.waitForVisibilityOfElementLocated(lbErrorMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbErrorMessage", lbErrorMessage, errormessage);
		// Click butotn OK
		driverMethod.click("btnOk", btnOK);
		// Select Item in 1st row
		driverMethod.click("tblVariationMarginClientListItem", tblVariationMarginClientListItem);
		// Input journal
		driverMethod.inputText("txtVariationMarginUpdateNotes", txtVariationMarginUpdateNotes, notemessage);
		// Click button update
		driverMethod.click("btnVariationMarginUpdateNote", btnVariationMarginUpdateNote);
		// Verify message 
		driverMethod.waitForVisibilityOfElementLocated(lbSuccessMessage, Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.verifyText("lbMessage", lbSuccessMessage, successmessage);
		
	}
	

}

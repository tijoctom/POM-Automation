package test.page.bulletnetobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;

import com.nashtech.common.Common;
import com.nashtech.common.Constant;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;
import com.nashtech.utils.report.HtmlReporter;

public class FindClientPage {
	
	private WebDriverMethod driverMethod;
	private Object [] data;
	
	// Web Element Locators
	//Tab list 
	private By tabClientSetup = By.xpath(".//*[@id='tabClientSetup']");
	// Client Details tab
	/*
	private By btnAssignClientCode = By.xpath("//*[@id='imgcmdAssignClientCode']");
	private By btnDelete = By.xpath("//*[@id='cmdDelete']");
	private By btnOk = By.xpath("//button[contains(.,'Ok')]");
	private By btnConfirm = By.xpath("//div[@class='modal-footer']/button[text()='Yes']");
	*/
	private By btnSave = By.xpath("//*[@id='cmdSave']");
	// Client background
	private By txtCompanyName = By.xpath("//*[@id='txtCompanyName']");
	private By txtGroup= By.xpath("//*[@id='tblClientBg']/tbody/tr[2]/td[4]/table/tbody/tr/td[1]");
	private By txtClientCode = By.xpath("//*[@id='divClientCode']");
	private By ddlClientCategory = By.xpath("//select[@id='cboABC']");
	private By txtClientSubCat = By.xpath("//input[@id='txtSubCat']");
	private By txtAddress1 = By.xpath("//*[@id='txtAddress1']");
	private By txtAddress2 = By.xpath("//*[@id='txtAddress2']");
	private By txtAddress3 = By.xpath("//*[@id='txtAddress3']");
	private By txtAddress4 = By.xpath("//*[@id='txtAddress4']");
	private By txtPostCode = By.xpath("//input[@id='txtPostCode']");
	private By txtDueDiligence = By.xpath("//input[@id='txtDueDiligence']");
	private By txtCompRegNo = By.xpath("//input[@id='txtCompRegNo']");
	private By txtTradeLicense = By.xpath("//input[@id='txtTradeLicense']");
	private By txtTradeLicenseExpiryDate = By.xpath("//input[@id='txtTradeLicenseExpiryDate']");
	private By txtClientRelationshipStrength = By.xpath("//td[@id='ClientRelationshipStrength']");
	private By txtAge = By.xpath("//tr[td[@id='ClientRelationshipStrength']]/td[3]");
	// Client background Second Level
	private By ddlTitles = By.xpath("//select[@id='cboTitles']");
	private By txtDOBDate = By.xpath("//input[@id='mskDOBDate']");
	private By txtFirstName = By.xpath("//*[@id='txtFirstName']");
	private By txtLastName = By.xpath("//*[@id='txtLastName']");
	private By txtBusPhone = By.xpath("//input[@id='txtBusPhone']");
	private By txtHomePhone = By.xpath("//input[@id='txtHomePhone']");
	private By txtBusFax = By.xpath("//input[@id='txtBusFax']");
	private By txtMob = By.xpath("//input[@id='txtMob']");
	private By txtEmail = By.xpath("//input[@id='txtEmail']");
	private By txtWeb = By.xpath("//input[@id='txtWeb']");
	/*
	private By ddlJobTitles = By.xpath("//select[@id='cboJobTitles']");
	private By txtDepartment = By.xpath("//input[@id='txtDepartment']");
	private By ddlIDTypesId = By.xpath("//select[@id='cboIDTypesId']");
	private By txtIDTypeExpiryDate = By.xpath("//input[@id='txtIDTypeExpiryDate']");
	*/
	// Client background Third Level	
	private By ddlAcManager = By.xpath("//select[@id='cboAcManager']");
	private By ddlLegalIDType = By.xpath("//select[@id='cboLegalIDType']");
	private By ddlSecondaryDealer = By.xpath("//select[@id='cboSecondaryDealer']");
	private By txtLegalIDNo = By.xpath("//input[@id='txtLegalIDNo']");
	/*
	private By ddlACExecutive = By.xpath("//select[@id='cboACExecutive']");
	private By ddlActForexTurnover = By.xpath("//select[@id='cboActForexTurnover']");
	private By ddlSalesExecutive = By.xpath("//select[@id='cboSalesExecutive']");
	private By ddlTradingPotential = By.xpath("//select[@id='cboTradingPotential']");
	private By ddlSCDIntroducer = By.xpath("//select[@id='cboSCDIntroducer']");
	private By ddlInactiveReason = By.xpath("//select[@id='cboInactiveReason']");
	private By ddlOptionsDealer = By.xpath("//select[@id='cboOptionsDealer']");
	private By ddlIntroducer = By.xpath("//select[@id='cboIntroducer']");
	private By ddlBDDOwner = By.xpath("//select[@id='cboLGTMember']");
	private By txtForexSource = By.xpath("//select[@id='txtForexSource']");
	private By ddlReferee = By.xpath("//select[@id='cboReferee']");	
	private By ddlIB = By.xpath("//*[@id='cboIB']");	
	private By ddlSubIB = By.xpath("//*[@id='cboSubIB']");
	*/
	private By ddlMethod = By.xpath("//*[@id='cboMethod']");
	private By ddlMedium = By.xpath("//*[@id='cboMedium']");
	private By ddlLeadSource = By.xpath("//*[@id='cboLeadSource']");
	private By ddlIndustries = By.xpath("//*[@id='cboIndustries']");
	// Right side	
	private By txtImportantNote = By.xpath("//textarea[@name='Client_ImportantNote']");
	private By txtClientRecentJournal = By.xpath("//textarea[@name='Client_RecentJournal']");
	private By txtLastTradeContractNo = By.xpath(".//div[div[@class='groupHeaderLabel' and contains(.,'Last Trade Deal')]]//tr[1]/td[2]");
	private By txtLastTradeContractType = By.xpath(".//div[div[@class='groupHeaderLabel' and contains(.,'Last Trade Deal')]]//tr[2]/td[2]");
	private By txtLastTradeSell = By.xpath(".//div[div[@class='groupHeaderLabel' and contains(.,'Last Trade Deal')]]//tr[3]/td[2]");
	private By txtLastTradeBuy = By.xpath(".//div[div[@class='groupHeaderLabel' and contains(.,'Last Trade Deal')]]//tr[4]/td[2]");	
	private By ddlFTurnOver = By.xpath("//*[@id='cboFTurnOver']");
	private By ddlTradeFrequency = By.xpath("//*[@id='cboTradeFrequency']");
	private By ddlTradeSize = By.xpath("//*[@id='cboTradeSize']");
	/*
	private By txtRemainingValue = By.xpath("//div[div[text()='Client limits']]//tr[3]/td[2]");
	private By txtClientGroupId = By.xpath("//*[@id='tblClientBg']/tbody/tr[2]/td[4]/table/tbody/tr/td[1]");
	// Journal	
	private By txtJournalInputDate = By.xpath("//input[@id='txtJournalInputDate']");
	private By ddlJournalInputDate = By.xpath("//select[@id='JournalInputDate']");
	*/
	private By ddlJournalTypeValue = By.xpath("//select[@id='JournalTypeValue']");
	private By ddlJournalSubTypeValue = By.xpath("//select[@id='JournalSubTypeValue']");
	private By ddlJournalDealNoValue = By.xpath("//select[@id='JournalDealNoValue']");
	private By txtJournalEntry = By.xpath("//textarea[@id='JournalEntry']");
	private By btnCreateApp = By.xpath("//input[@id='cmdCreateApp']");
	private By btnPrint = By.xpath("//input[@id='PrintJournal']");
	private By btnSaveJournal = By.xpath("//input[@id='SaveJournal']");
	private By btnModeSwitch = By.xpath("//input[@id='cmdModeSwitch']");
	private By btnToggleJournalList = By.xpath("//input[@id='ToggleJournalList']");
//	private By txtUserFilter = By.xpath("//input[@id='txtUserFilter']");
	private By createAppPopup = By.xpath("//span[contains(.,'Create Outlook Appointment')]");
	private By txtAppStartDateTime = By.xpath("//input[@id='appStartDateTime']");
	private By txtAppDuration = By.xpath("//input[@id='appDuration']");
	private By btnDone = By.xpath("//button[contains(.,'Done')]");
//	private By btnNow = By.xpath("//button[contains(.,'Now')]");
	private By txtAppSubject = By.xpath("//input[@id='appSubject']");
	private By txtAppBody = By.xpath("//input[@id='appBody']");
	private By txtAppLocation = By.xpath("//input[@id='appLocation']");
	private By txtAppReminder = By.xpath("//input[@id='appReminder']");
	private By btnAppSave = By.xpath("//input[@value='Save']");
	private By JournalTable = By.xpath(".//*[@id='JournalsTable']");
	private By trJournalTable = By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]");
	private By tabSLA = By.xpath("//*[@id='tabDealingSLA']");
	
	public static By txtJournalTableDate(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[1]");
	}
	public static By txtJournalTableType(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[2]");
	}
	public static By txtJournalTableSubType(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[3]");
	}
	public static By txtJournalTableDealNo(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[4]");
	}
	public static By txtJournalTableEntry(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[5]");
	}
	public static By txtJournalTableUserLogin(int i){
		return By.xpath(".//*[@id='JournalsTable']/tbody/tr[not(@style='display: none;')]["+i+"]/td[6]");
	}	
	private By imgInfo = By.xpath("//img[@src='/Images/MsgBox/info.png']");
	private By txtMessage = By.xpath("//*[contains(@class,'jqimessage')]//td[2]");
	private By txtMessage2 = By.xpath("//*[contains(@class,'bootbox-body')]");
	private By txtMessage3 = By.xpath("//*[contains(@class,'bootbox-body')]//td[2]");
	// Client Setup tab
	private By btnSwitchLitePro = By.xpath("//div[@id='divOnlineLogin']/table[1]/tbody/tr[2]/td[2]/div/div");
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////               Window forward         ////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private By txtSwapV2TableSize = By.xpath("//div[@class='table-container-tradedetails']/table/tbody/tr");
	private By txtByAmount = By.xpath("//input[@id='txtLinkedBuyAmount']");
	private By txtClientPrice = By.xpath("//input[@id='txtLinkedFXRate']");	
	private By btnPlusButton = By.xpath("//input[@id='StripsPlus']");	
	private By btnInstructionForm = By.xpath("//tr[@id='instruction-from']/td[1]");
	private By btnInstructionMethod = By.xpath("//tr[@id='instruction-method-first-row']/td[1]");	
	private By reasonForPayment = By.xpath("//select[@id='RfpReasonForPaymentSelection']");
	private By btnSaveDrawDown = By.xpath("//input[@id='btnSaveTrades']");	
	private By btnApprovalYes = By.xpath("//button[@id='jqi_state0_buttonYes']");
	private By txtApprovalReason = By.xpath("//textarea[@id='reason']");	
	private By btnApprovalSubmit = By.xpath("//div[@class='modal-footer']/button");
	private By tblTradeApprovalSize = By.xpath("//div[@class='table-container']/table/tbody/tr");
	private By txtApproveTextBox = By.xpath("//textarea[@id='txtReason']");
	private By btnApproveButton = By.xpath("//input[@id='cmdAccept']");
	private By btnRejectButton = By.xpath("//input[@id='cmdReject']");	
	private By btnApproveConfirmYes = By.xpath("//button[@id='jqi_state0_buttonYes']");
	private By lblApprovalHistorySize = By.xpath("//table[@id='tblTradeApprovalHistory']/tbody/tr");
	private By btnOKK = By.xpath("//div[@class='modal-dialog']/div/div[3]/button");	
	private By btnNextAvaliDateOK = By.xpath("//div[@class='modal-content']/div[3]/button");
	/////////////////////////////////////////////////////////////////////////////////////////////////
	public static By txtFrowardTradeNo(int i) {
		return By.xpath("//div[@class='table-container']/table/tbody/tr["+i+"]/td[5]");
	}
	public static By txtTradeNo(int i) {
		return By.xpath("//div[@class='table-container']/table/tbody/tr["+i+"]/td[2]/a");
	}
	public static By txtSwapV2TableTradeNo(int i){
		return By.xpath("//div[@class='table-container-tradedetails']/table/tbody/tr["+i+"]/td[1]");
	}	
	public static By txtTradeNumber(int i){
		return By.xpath("//table[@id='tblTradeApprovalHistory']/tbody/tr["+i+"]/td[1]/a");
	}	
	///////////////////////////////////// WF fix  ////////////////////////////////////////////////////////////////
	private By lblFirstUtilV2 =By.xpath("//*[@id='tradeDetCheadFirstUtilisationDate']");
	private By lblClientPriceMsg =By.xpath("//*[@class='jqimessage ']/div//div[contains(.,'Please select input Linked Exchange Rate')]");
	private By btnSwapV2OK =By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By lblDrawDownNumber =By.xpath("//*[@id='tblPrint']/tbody/tr[2]/td[3]");
	public static By lblDrowdownNo(String i){
		return By.xpath("//*[@id='td_DealNo_["+i+"]']/a");
	}
	private By tblFirstUtil =By.xpath("//*[@id='tradeDetCheadFirstUtilisationDate']");
	private By lblPendingApprovalForward=By.xpath("//div[@class='jqimessage ']/div//div[contains(.,'There has already been a drawdown request for approval on this trade ')]");
	private By lblOK =By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By lstSwapContractType =By.xpath("//*[@id='cboSwapContractType']");
	private By txtRollOverFirstUtil =By.xpath("//*[@id='mskLinkedFirstUtilDate']");
	private By btnSwapV2PlusButton =By.xpath("//*[@id='StripsPlus']");
	private By lblFirstUtilRollOverMsg = By.xpath("//div[@class='jqimessage ']/div//div[contains(.,'Please set a 1st Utilisation Date for this Rollover')]");
	private By btnOKk =By.xpath("//*[@id='jqi_state0_buttonOk']");
	private By txtRollOverValueDate =By.xpath("//*[@id='mskLinkedValueDate']");
	private By lblRollOverNumber =By.xpath("//td[contains(.,'Rollover')]/preceding-sibling::td[@id='ticketDealNo']");
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public FindClientPage(WebDriverMethod driverMethod, Object [] data) {
		this.driverMethod = driverMethod;
		this.data = data;
	}	
	public void verifyData() throws Exception{
		String compid = Common.getCellDataProvider(data,"Compid");
		String SQLverify = Common.getCellDataProvider(data,"SQL verify") +"'"+ compid+"'";
		String SQLlastjournal = Common.getCellDataProvider(data,"SQL lastjournal1") +"'"+ compid+"'" + Common.getCellDataProvider(data,"SQL lastjournal2");
		String SQLlasttrade = Common.getCellDataProvider(data,"SQL Last Trade") +" '"+ compid+"' " +Common.getCellDataProvider(data,"SQL Last Trade2");
		SqlServerJDBC.getConnection();
		//Client Background
		driverMethod.verifyContainText("txtClientCode", txtClientCode, SqlServerJDBC.getValueInDatabase(SQLverify,"ClientCode"));
		driverMethod.verifyAttribute("txtCompanyName", txtCompanyName, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"compName"));		
		driverMethod.verifyAttribute("txtAddress1", txtAddress1,"value", SqlServerJDBC.getValueInDatabase(SQLverify,"Address1"));
		driverMethod.verifyAttribute("txtAddress2", txtAddress2,"value", SqlServerJDBC.getValueInDatabase(SQLverify,"Address2"));
		driverMethod.verifyAttribute("txtAddress3", txtAddress3,"value", SqlServerJDBC.getValueInDatabase(SQLverify,"Address3"));
		driverMethod.verifyAttribute("txtAddress4", txtAddress4,"value", SqlServerJDBC.getValueInDatabase(SQLverify,"Address4"));
		driverMethod.verifyAttribute("txtPostCode", txtPostCode, "value",SqlServerJDBC.getValueInDatabase(SQLverify,"addrPostCode"));	
		driverMethod.verifyContainText("txtGroup", txtGroup, SqlServerJDBC.getValueInDatabase(SQLverify,"GroupID").equalsIgnoreCase("1") ? "GRP":"GRM");
		driverMethod.verifyDisplayDDL("ddlClientCategory", ddlClientCategory, SqlServerJDBC.getValueInDatabase(SQLverify,"ABC"));	 
		driverMethod.verifyAttribute("txtClientSubCat", txtClientSubCat, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"tinySubCat"));	 
		driverMethod.verifyAttribute("txtDueDiligence", txtDueDiligence, "value", 
				new SimpleDateFormat("dd/MM/yyyy").format(new SimpleDateFormat("yyyy-MM-dd").parse(SqlServerJDBC.getValueInDatabase(SQLverify,"dteDueDiligence"))));	 
		driverMethod.verifyAttribute("txtCompRegNo", txtCompRegNo, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"vcCompRegistrationNo"));	 
		driverMethod.verifyAttribute("txtTradeLicense", txtTradeLicense, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"TradeLicense"));	 
		driverMethod.verifyAttribute("txtTradeLicenseExpiryDate", txtTradeLicenseExpiryDate, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"TradeLicenseExpiryDate"));	 
		driverMethod.verifyContainText("txtClientRelationshipStrength", txtClientRelationshipStrength, SqlServerJDBC.getValueInDatabase(SQLverify,"intCRS"));	 
		driverMethod.verifyContainText("txtAge", txtAge, SqlServerJDBC.getValueInDatabase(SQLverify,"Client1StAgeTrade")+" year(s)");	 
		//Client Background level 2
		driverMethod.verifyDisplayValueDDL("ddlTitles", ddlTitles, SqlServerJDBC.getValueInDatabase(SQLverify,"contTitle"));		
		SimpleDateFormat sdf1 = new SimpleDateFormat(Constant.TIME_STAMP_6);
		SimpleDateFormat sdf2 = new SimpleDateFormat(Constant.TIME_STAMP_1);
		String date = sdf2.format(sdf1.parse(SqlServerJDBC.getValueInDatabase(SQLverify,"contDOB").split(" ")[0]));
		driverMethod.verifyAttribute("txtDOBDate", txtDOBDate,"value",  date);
		driverMethod.verifyAttribute("txtFirstName", txtFirstName, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"contFirstName"));
		driverMethod.verifyAttribute("txtLastName", txtLastName, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"contLastName"));
		driverMethod.verifyAttribute("txtBusPhone", txtBusPhone, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"contPhone"));
		driverMethod.verifyAttribute("txtHomePhone", txtHomePhone, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"contPhone2"));
		driverMethod.verifyAttribute("txtBusFax", txtBusFax, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"contFax"));
		driverMethod.verifyAttribute("txtMob", txtMob, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"Mobile"));
//		driverMethod.verifyAttribute("ddlJobTitles", ddlJobTitles, SqlServerJDBC.getValueInDatabase(SQLverify,""));
		driverMethod.verifyAttribute("txtEmail", txtEmail, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"Email"));
		driverMethod.verifyAttribute("txtWeb", txtWeb, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"WebAddress"));
		//Client Background level 3
		driverMethod.verifyDisplayDDL("ddlAcManager", ddlAcManager, SqlServerJDBC.getValueInDatabase(SQLverify,"UserName"));		
		driverMethod.verifyDisplayValueDDL("ddlLegalIDType", ddlLegalIDType,  SqlServerJDBC.getValueInDatabase(SQLverify,"LegalID"));
		driverMethod.verifyDisplayValueDDL("ddlSecondaryDealer", ddlSecondaryDealer,   SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));		
		driverMethod.verifyAttribute("txtLegalIDNo", txtLegalIDNo, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"LegalIDNo"));
		/*
		driverMethod.verifyDisplayValueDDL("ddlACExecutive", ddlACExecutive,   SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));		
		driverMethod.verifyAttribute("ddlActForexTurnover", ddlActForexTurnover,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlSalesExecutive", ddlSalesExecutive,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlTradingPotential", ddlTradingPotential, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlSCDIntroducer", ddlSCDIntroducer, "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlInactiveReason", ddlInactiveReason,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlOptionsDealer", ddlOptionsDealer,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));;
		driverMethod.verifyAttribute("ddlIntroducer", ddlIntroducer,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlBDDOwner", ddlBDDOwner,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("txtForexSource", txtForexSource, SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));		
		driverMethod.verifyAttribute("ddlReferee", ddlReferee,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlIB", ddlIB,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		driverMethod.verifyAttribute("ddlSubIB", ddlSubIB,  "value", SqlServerJDBC.getValueInDatabase(SQLverify,"intSecondaryDealer"));
		*/
		driverMethod.verifyDisplayValueDDL("ddlMethod", ddlMethod,   SqlServerJDBC.getValueInDatabase(SQLverify,"fintLeadMethodID"));
		driverMethod.verifyDisplayValueDDL("ddlMedium", ddlMedium,   SqlServerJDBC.getValueInDatabase(SQLverify,"fintLeadMediumID"));
		driverMethod.verifyDisplayValueDDL("ddlLeadSource", ddlLeadSource,  SqlServerJDBC.getValueInDatabase(SQLverify,"LeadSource"));		
		driverMethod.verifyDisplayValueDDL("ddlIndustries", ddlIndustries,   SqlServerJDBC.getValueInDatabase(SQLverify,"IndustryID"));
		//Right side
		driverMethod.verifyAttribute("txtImportantNote", txtImportantNote,   "value", SqlServerJDBC.getValueInDatabase(SQLverify,"Notepad"));
		driverMethod.verifyAttribute("txtClientRecentJournal", txtClientRecentJournal,   "value", SqlServerJDBC.getValueInDatabase(SQLlastjournal,"Entry"));
		driverMethod.verifyContainText("txtLastTradeContractNo", txtLastTradeContractNo, SqlServerJDBC.getValueInDatabase(SQLlasttrade,"DealNo"));
		driverMethod.verifyContainText("txtLastTradeContractType", txtLastTradeContractType,   SqlServerJDBC.getValueInDatabase(SQLlasttrade,"ContractType"));
		driverMethod.verifyContainText("txtLastTradeSell", txtLastTradeSell, SqlServerJDBC.getValueInDatabase(SQLlasttrade,"SellAmount"));
		driverMethod.verifyContainText("txtLastTradeBuy", txtLastTradeBuy,  SqlServerJDBC.getValueInDatabase(SQLlasttrade,"BuyAmount"));
		
	}
	
	public void editdata() throws Exception{
		// Input Company Name
 		driverMethod.inputText("txtCompanyName", txtCompanyName, Common.getCellDataProvider(data,"CompanyName"));
 		// Input Address 1
 		driverMethod.inputText("txtAddress1", txtAddress1, Common.getCellDataProvider(data,"Address1"));
 		// Input last name
 		driverMethod.inputText("txtLastName", txtLastName, Common.getCellDataProvider(data,"LastName"));
 		// Select Industries
 		driverMethod.selectDDLByText("ddlIndustries", ddlIndustries, Common.getCellDataProvider(data,"Industries"));
 		// Select Method
 		driverMethod.selectDDLByText("ddlMethod", ddlMethod, Common.getCellDataProvider(data,"Method"));
 		// Select medium
 		driverMethod.selectDDLByText("ddlMedium", ddlMedium, Common.getCellDataProvider(data,"Medium"));
 		// Select Turn Over
 		driverMethod.selectDDLByText("ddlFTurnOver", ddlFTurnOver, Common.getCellDataProvider(data,"TurnOver"));
 		// Select Trade Frequency
 		driverMethod.selectDDLByText("ddlTradeFrequency", ddlTradeFrequency, Common.getCellDataProvider(data,"TradeFrequency"));
 		// Select Trade Size
 		driverMethod.selectDDLByText("ddlTradeSize", ddlTradeSize, Common.getCellDataProvider(data,"TradeSize"));
	}
	public void saveClient() throws Exception{
		driverMethod.click("btnSave", btnSave);
	}
	public void verifyPopupMessage() throws Exception{
		driverMethod.waitForPresenceOfElementLocated(imgInfo, Constant.SMALL_WAITTIME_SECONDS);
		if (driverMethod.isElementDisplayed(txtMessage))
			driverMethod.verifyContainText("txtMessage", txtMessage, Common.getCellDataProvider(data,"Message"));
		else if (driverMethod.isElementDisplayed(txtMessage2))
			driverMethod.verifyContainText("txtMessage", txtMessage2, Common.getCellDataProvider(data,"Message"));
		else if (driverMethod.isElementDisplayed(txtMessage3))
			driverMethod.verifyContainText("txtMessage", txtMessage3, Common.getCellDataProvider(data,"Message"));
	}
	public void verifyPopupMessage(String message) throws Exception{
		driverMethod.waitForPresenceOfElementLocated(imgInfo, Constant.SMALL_WAITTIME_SECONDS);
		if (driverMethod.isElementDisplayed(txtMessage))
			driverMethod.verifyContainText("txtMessage", txtMessage, message);
		else if (driverMethod.isElementDisplayed(txtMessage2))
			driverMethod.verifyContainText("txtMessage", txtMessage2, message);
		else if (driverMethod.isElementDisplayed(txtMessage3))
			driverMethod.verifyContainText("txtMessage", txtMessage3, message);
	}
	public void clickCreateApp() throws Exception{
		driverMethod.click("btnCreateApp", btnCreateApp);
		driverMethod.waitForVisibilityOfElementLocated(createAppPopup, Constant.SMALL_WAITTIME_SECONDS);
	}
	public void clickPrint() throws Exception{
		driverMethod.click("btnPrint", btnPrint);
	}
	public void clickSaveJournal() throws Exception{
		driverMethod.click("btnSaveJournal", btnSaveJournal);
	}
	public void clickFilterJournal() throws Exception{
		driverMethod.click("btnModeSwitch", btnModeSwitch);
	}
	public void clickToggleButton() throws Exception{
		driverMethod.click("btnToggleJournalList", btnToggleJournalList);
	}
	public void clickClientSetup() throws Exception{
		driverMethod.click("tabClientSetup", tabClientSetup);
	}
	public void clickSwitchLitePro() throws Exception{
		driverMethod.click("btnSwitchLitePro", btnSwitchLitePro);
	}
	public void editCreateApp() throws Exception{
		driverMethod.inputText("txtAppStartDateTime", txtAppStartDateTime, Common.getCellDataProvider(data,"StartDateTime"));
		driverMethod.click("btnDone", btnDone);
		driverMethod.inputText("txtAppLocation", txtAppLocation, Common.getCellDataProvider(data,"Location"));
		driverMethod.inputText("txtAppDuration", txtAppDuration, Common.getCellDataProvider(data,"Duration"));
		driverMethod.click("btnDone", btnDone);
		driverMethod.inputText("txtAppSubject", txtAppSubject, Common.getCellDataProvider(data,"Subject"));
		driverMethod.inputText("txtAppBody", txtAppBody, Common.getCellDataProvider(data,"Body"));
		driverMethod.inputText("txtAppReminder", txtAppReminder, Common.getCellDataProvider(data,"Reminder"));
		driverMethod.click("btnDone", btnDone);
		driverMethod.click("btnAppSave", btnAppSave);
	}
	public void verifyPrint() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		clickPrint();
		driverMethod.switchwindow(size);
		driverMethod.waitForPresenceOfElementLocated(By.xpath("//*[@id='CrystalReportViewerBullet']"), Constant.DEFAULT_WAITTIME_SECONDS);;
		String url = driverMethod.driver.getCurrentUrl();
		String reportstring = url.substring(url.lastIndexOf("?")+1);
		String reportname = reportstring.split("&")[0];
		// Verify report Name
		Assert.assertEquals(reportname, Common.getCellDataProvider(data,"reportName"));
	}
	
	public void editJournal() throws Exception{
		driverMethod.selectDDLByText("ddlJournalTypeValue", ddlJournalTypeValue, Common.getCellDataProvider(data,"Journal Type"));
		driverMethod.selectDDLByText("ddlJournalSubTypeValue", ddlJournalSubTypeValue, Common.getCellDataProvider(data,"Journal Subtype"));
		driverMethod.selectDDLByText("ddlJournalDealNoValue", ddlJournalDealNoValue, Common.getCellDataProvider(data,"Journal Dealno"));
		driverMethod.inputText("txtJournalEntryou", txtJournalEntry, Common.getCellDataProvider(data,"Journal Entry"));
		clickSaveJournal();
	}	
	
	public void filterJournal() throws Exception{
		// Get quantity of return data
		int size = driverMethod.driver.findElements(trJournalTable).size();
		// Verify return data 
		for (int i = 1; i<=size;i++){	
			driverMethod.verifyContainText("txtJournalTableDate", txtJournalTableDate(i), Common.getCellDataProvider(data,"Journal Entry"));
			driverMethod.verifyContainText("txtJournalTableType", txtJournalTableType(i), Common.getCellDataProvider(data,"Journal Entry"));
			driverMethod.verifyContainText("txtJournalTableSubType", txtJournalTableSubType(i), Common.getCellDataProvider(data,"Journal Entry"));
			driverMethod.verifyContainText("txtJournalTableDealNo", txtJournalTableDealNo(i), Common.getCellDataProvider(data,"Journal Entry"));
			driverMethod.verifyContainText("lbClientNameCompanyByRow", txtJournalTableEntry(i), Common.getCellDataProvider(data,"Journal Entry"));
			driverMethod.verifyContainText("txtJournalTableUserLogin", txtJournalTableUserLogin(i), Common.getCellDataProvider(data,"Journal Entry"));
			
		}	
	}
	
	public void verifyJournalTableDisplayed() throws Exception{
		driverMethod.isElementDisplayed(JournalTable);
	} 
	public NewTradePage navigateTradeFX() throws Exception{
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("btnNewTradeFX", CommonObject.menuNewTradeFX);
		// Change to New Trade FX window cause it will open in new tab/browser		
		driverMethod.switchwindow(size);
		Log.info("navigateTradeFX");
		driverMethod.closeOtherWindow();
		return new NewTradePage(driverMethod, data);
		
	}
	public void verifyOpenClient(String clientcode, String Groupid) throws Exception{	
		driverMethod.verifyContainText("txtClientCode", txtClientCode, clientcode);
		driverMethod.verifyContainText("txtGroup", txtGroup, Groupid);
	}
	public void verifySwitchLiteProSuccessfuly() throws Exception{	
		SqlServerJDBC.getConnection();
		clickClientSetup();		
		
		String dbstatus = SqlServerJDBC.getValueInDatabase(Common.getCellDataProvider(data, "SQL Current Status"), "IsGRPLite");
		if (dbstatus.equalsIgnoreCase("1")){
			driverMethod.verifyAttribute("btnSwitchLitePro", btnSwitchLitePro, "style", "width: 87px; margin-left: -29px;");
			clickSwitchLitePro();	
			driverMethod.waitForVisibilityOfElementLocated(txtMessage3, Constant.DEFAULT_WAITTIME_SECONDS);
			dbstatus = SqlServerJDBC.getValueInDatabase(Common.getCellDataProvider(data, "SQL Current Status"), "isGRPLite");
			driverMethod.compareText("Current status", dbstatus, "0");
			driverMethod.verifyAttribute("btnSwitchLitePro", btnSwitchLitePro, "style", "width: 87px; margin-left: 0px;");
			verifyPopupMessage("The client has been setup on GRP Pro");
		}
		else{
			driverMethod.verifyAttribute("btnSwitchLitePro", btnSwitchLitePro, "style", "margin-left: 0px; width: 87px;");
			clickSwitchLitePro();	
			driverMethod.waitForVisibilityOfElementLocated(txtMessage3, Constant.DEFAULT_WAITTIME_SECONDS);
			dbstatus = SqlServerJDBC.getValueInDatabase(Common.getCellDataProvider(data, "SQL Current Status"), "isGRPLite");
			driverMethod.compareText("Current status", dbstatus, "1");
			driverMethod.verifyAttribute("btnSwitchLitePro", btnSwitchLitePro, "style", "margin-left: -29px; width: 87px;");
			verifyPopupMessage("The client has been setup on GRP Lite");
		}
		SqlServerJDBC.closeConnection();
		
	}

	public void verifyJournalNewSubType() throws Exception{
		SqlServerJDBC.getConnection();
		String journaltypeid = SqlServerJDBC.getValueInDatabase(Common.getCellDataProvider(data, "SQL Check")+"'" + Common.getCellDataProvider(data, "New Journal Subtype")+"'", "JournalTypeID");
		try{
		if (journaltypeid.equalsIgnoreCase(""))
			throw new Exception();
		}catch (Exception e){
			TestngLogger.writeResult("New subtype is not added", false);
		}
		driverMethod.selectDDLByValue("ddlJournalTypeValue", ddlJournalTypeValue, journaltypeid);
		driverMethod.selectDDLByText("ddlJournalSubTypeValue", ddlJournalSubTypeValue, Common.getCellDataProvider(data, "New Journal Subtype"));
	}
	public SLAPage openSLATab() throws Exception{
		driverMethod.click("tabSLA", tabSLA);
		return new SLAPage(driverMethod, data);
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
///////////////////////////////////////////////          Window forward         ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public NewTradePage navigateSwapV2() throws Exception {
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("btnSwapV2", CommonObject.menuSwapV2);
		// Change to Swap V2 window cause it will open in new tab/browser
		driverMethod.switchwindow(size);
		driverMethod.closeOtherWindow();
		return new NewTradePage(driverMethod, data);

	}
	public NewTradePage navigateTradeApproval() throws Exception {
		int size = driverMethod.driver.getWindowHandles().size();
		driverMethod.clickByJS("menuTradeApproval", CommonObject.menuTradeApproval);
		// Change to Swap V2 window cause it will open in new tab/browser
		driverMethod.switchwindowNew(size);
		driverMethod.closeOtherWindow();
		return new NewTradePage(driverMethod, data);

	}
	public NewTradePage selectSwapRecord() throws Exception {

		String message = Common.getCellDataProvider(data, "DealNumberApprove");
		Log.info("TradeNumber:" + message);
		int size = driverMethod.driver.findElements(txtSwapV2TableSize).size();
		Log.info("Total rows in swapV2:" + size);
		// Verify return data
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtSwapV2TableTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("", txtSwapV2TableTradeNo(i));
				driverMethod.waitForPresenceOfElementLocated(By.xpath("//input[@id='txtLinkedBuyAmount']"),
						Constant.DEFAULT_WAITTIME_SECONDS);
				Log.info("In Row number:" + i);
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage selectSwapRecordReject() throws Exception {
		String message = Common.getCellDataProvider(data, "DealNumberReject");
		Log.info("TradeNumber:" + message);
		int size = driverMethod.driver.findElements(txtSwapV2TableSize).size();
		Log.info("Total rows in swapV2:" + size);
		// Verify return data
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtSwapV2TableTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("", txtSwapV2TableTradeNo(i));
				driverMethod.waitForPresenceOfElementLocated(By.xpath("//input[@id='txtLinkedBuyAmount']"),
						Constant.DEFAULT_WAITTIME_SECONDS);
				Log.info("In Row number:" + i);
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage submitDrowDown() throws Exception {
		driverMethod.inputText("txtByAmount", txtByAmount, Common.getCellDataProvider(data, "BuyAmount"));
		driverMethod.inputText("txtClientPrice", txtClientPrice, Common.getCellDataProvider(data, "ClientPrice"));
		driverMethod.clickByJS("", btnPlusButton);
		// driverMethod.waitForVisibilityOfElementLocated(txtMessage3,
		// Constant.DEFAULT_WAITTIME_SECONDS);
		driverMethod.clickByJS("btnInstructionForm", btnInstructionForm);
		driverMethod.doubleClick("btnInstructionMethod", btnInstructionMethod);
		driverMethod.selectDDLByText("reasonForPayment", reasonForPayment,
				Common.getCellDataProvider(data, "Reason for payment"));
		driverMethod.doubleClick("btnSaveDrawDown", btnSaveDrawDown);
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage drawDownApprovalPopUp() throws Exception {
		driverMethod.clickByJS("btnApprovalYes", btnApprovalYes);
		driverMethod.inputText("", txtApprovalReason, Common.getCellDataProvider(data, "ApproveReason"));
		driverMethod.clickByJS("btnApprovalSubmit", btnApprovalSubmit);
		driverMethod.clickByJS("btnApprovalSubmit", btnOKK);
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage drawDownRejectPopUp() throws Exception {
		driverMethod.clickByJS("btnApprovalYes", btnApprovalYes);
		driverMethod.inputText("", txtApprovalReason, Common.getCellDataProvider(data, "RejectReason"));
		driverMethod.clickByJS("btnApprovalSubmit", btnApprovalSubmit);
		driverMethod.clickByJS("btnApprovalSubmit", btnOKK);
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage approvalRecord() throws Exception {
		String message = Common.getCellDataProvider(data, "DealNumberApprove");
		Log.info("Deal No:" + message);
		int size = driverMethod.driver.findElements(tblTradeApprovalSize).size();
		Log.info("Approval screen row size:" + size);
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtFrowardTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("", txtFrowardTradeNo(i));
				String tradeNo = driverMethod.getText("tradeNo", txtTradeNo(i));
				Log.info("New trade number:" + tradeNo);
				driverMethod.inputText("txtApproveTextBox", txtApproveTextBox,
						Common.getCellDataProvider(data, "ApproveReason"));
				driverMethod.clickByJS("btnApproveButton", btnApproveButton);
				driverMethod.clickByJS("btnApproveConfirmYes", btnApproveConfirmYes);
				// driverMethod.waitForVisibilityOfElementLocated(imgInfo,
				// Constant.DEFAULT_WAITTIME_SECONDS);
				int approveHistorysize = driverMethod.driver.findElements(lblApprovalHistorySize).size();
				Log.info("Approval History table size:" + approveHistorysize);
				for (int j = 1; j <= approveHistorysize; j++) {
					if (driverMethod.getText("txtSwapV2TableTradeNo", txtTradeNumber(j)).contains(tradeNo)) {
						driverMethod.doubleClick("txtTradeNumber", txtTradeNumber(j));
						Log.info("New trade row:" + j);
						break;
					}
				}
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage rejectRecord() throws Exception {
		String message = Common.getCellDataProvider(data, "DealNumberReject");
		Log.info("Deal No:" + message);
		int size = driverMethod.driver.findElements(tblTradeApprovalSize).size();
		Log.info("Approval screen row size:" + size);
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtFrowardTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("", txtFrowardTradeNo(i));
				String tradeNo = driverMethod.getText("tradeNo", txtTradeNo(i));
				Log.info("New trade number:" + tradeNo);
				driverMethod.inputText("txtApproveTextBox", txtApproveTextBox,
						Common.getCellDataProvider(data, "RejectReason"));
				driverMethod.clickByJS("btnRejectButton", btnRejectButton);
				driverMethod.clickByJS("btnApproveConfirmYes", btnApproveConfirmYes);
				// driverMethod.waitForVisibilityOfElementLocated(imgInfo,
				// Constant.DEFAULT_WAITTIME_SECONDS);
				int approveHistorysize = driverMethod.driver.findElements(lblApprovalHistorySize).size();
				Log.info("Approval History table size:" + approveHistorysize);
				for (int j = 1; j <= approveHistorysize; j++) {
					if (driverMethod.getText("txtSwapV2TableTradeNo", txtTradeNumber(j)).contains(tradeNo)) {
						driverMethod.doubleClick("txtTradeNumber", txtTradeNumber(j));
						Log.info("New trade row:" + j);
						break;
					}
				}
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage tradeApproval() throws Exception {
		navigateSwapV2();
		selectSwapRecord();
		submitDrowDown();
		drawDownApprovalPopUp();
		navigateTradeApproval();
		approvalRecord();
		TestngLogger.writeResult("Trade approved successfully", true);
		HtmlReporter.pass("Trade approved successfully");
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage tradeReject() throws Exception {
		navigateSwapV2();
		selectSwapRecordReject();
		submitDrowDown();
		drawDownRejectPopUp();
		navigateTradeApproval();
		rejectRecord();
		TestngLogger.writeResult("Trade rejected successfully", true);
		HtmlReporter.pass("Trade rejected successfully");
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage selectSwapRecordNew(String tradeno) throws Exception {
		String str = tradeno;
		int size = driverMethod.driver.findElements(txtSwapV2TableSize).size();
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtSwapV2TableTradeNo(i)).contains(str)) {
				driverMethod.doubleClick("Trade Number", txtSwapV2TableTradeNo(i));
				driverMethod.waitForPresenceOfElementLocated(By.xpath("//input[@id='txtLinkedBuyAmount']"),
						Constant.DEFAULT_WAITTIME_SECONDS);
				Log.info("In Row number:" + i);
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage approvalRecordNew(String tradeno) throws Exception {
		String message = tradeno;
		Log.info("Deal No:" + message);
		int size = driverMethod.driver.findElements(tblTradeApprovalSize).size();
		Log.info("Approval screen row size:" + size);
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtFrowardTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("Trade Number", txtFrowardTradeNo(i));
				String tradeNo = driverMethod.getText("tradeNo", txtTradeNo(i));
				Log.info("New trade number:" + tradeNo);
				driverMethod.inputText("txtApproveTextBox", txtApproveTextBox,
						Common.getCellDataProvider(data, "ApproveReason"));
				driverMethod.clickByJS("btnApproveButton", btnApproveButton);
				driverMethod.clickByJS("btnApproveConfirmYes", btnApproveConfirmYes);
				int approveHistorysize = driverMethod.driver.findElements(lblApprovalHistorySize).size();
				Log.info("Approval History table size:" + approveHistorysize);
				for (int j = 1; j <= approveHistorysize; j++) {
					if (driverMethod.getText("txtSwapV2TableTradeNo", txtTradeNumber(j)).contains(tradeNo)) {
						driverMethod.doubleClick("txtTradeNumber", txtTradeNumber(j));
						Log.info("New trade row:" + j);
						break;
					}
				}
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	public NewTradePage rejectRecordNew(String tradeno) throws Exception {
		String message = tradeno;
		int size = driverMethod.driver.findElements(tblTradeApprovalSize).size();
		for (int i = 1; i <= size; i++) {
			if (driverMethod.getText("txtSwapV2TableTradeNo", txtFrowardTradeNo(i)).contains(message)) {
				driverMethod.doubleClick("", txtFrowardTradeNo(i));
				String tradeNo = driverMethod.getText("tradeNo", txtTradeNo(i));
				Log.info("New trade number:" + tradeNo);
				driverMethod.inputText("txtApproveTextBox", txtApproveTextBox,Common.getCellDataProvider(data, "RejectReason"));
				driverMethod.clickByJS("btnRejectButton", btnRejectButton);
				driverMethod.clickByJS("btnApproveConfirmYes", btnApproveConfirmYes);
				int approveHistorysize = driverMethod.driver.findElements(lblApprovalHistorySize).size();
				for (int j = 1; j <= approveHistorysize; j++) {
					if (driverMethod.getText("txtSwapV2TableTradeNo", txtTradeNumber(j)).contains(tradeNo)) {
						//driverMethod.doubleClick("txtTradeNumber", txtTradeNumber(j));
						TestngLogger.writeResult("Rejected Successfully", true);
						break;
					}else {
						TestngLogger.writeResult("Rejected not succesfull", false);
					}
				}
				break;
			}
		}
		return new NewTradePage(driverMethod, data);
	}
	////////////////////////////////////////  window forwrd fix  /////////////////////////////////////////////////////////
	public void verifyFirstUtilSwapV2() throws Exception{
		driverMethod.isElementIsDisplayed("1st Utilization date", lblFirstUtilV2, true);
		driverMethod.clear("txtClientPrice", txtClientPrice);
		driverMethod.clickByJS("btnPlusButton", btnPlusButton);
		if(driverMethod.isElementPresent(lblClientPriceMsg)) {
			Log.info("PASS: Client price error message is displayed");
			TestngLogger.writeResult("PASS: Client price error message is displayed", true);
		}else {
			Log.error("FAIL: Client price erro message is not displayed");
			TestngLogger.writeResult("FAIL: Client price error message is not displayed", false);
			
		}
		driverMethod.clickByJS("btnSwapV2OK", btnSwapV2OK);	
	}
	public String getDrawdownNumber() throws Exception{
		 String str =driverMethod.getText("", lblDrawDownNumber);
		 return str;
	}
	public void verifyDrowdownNo(String drawdownNo)throws Exception{
		driverMethod.isElementPresent(lblDrowdownNo(drawdownNo));
	}
	public void verifySwapTradeSuccess() throws Exception {
		driverMethod.verifyText("Swap Trade success message", txtMessage2,Common.getCellDataProvider(data, "Message"));
		driverMethod.clickByJS("ApprovalSubmitOK", btnOKK);
	}
	public void verifyNoSwapV2FirstUtil() throws Exception{
		Common.sleep(Constant.TINY_WAITTIME_SECONDS);
		driverMethod.isElementIsDisplayed("tblFirstUtil", tblFirstUtil, false);
	}
	public void verifyPendingApprovalMsg() throws Exception{
		String str= driverMethod.getText("", lblPendingApprovalForward);
		String strNew =Common.getCellDataProvider(data, "PendingMsg");
		Log.info("Msg from excel: "+strNew);
		Log.info("Msg from system"+str);
		if(str.equalsIgnoreCase(strNew)) {
			Log.info("PASS: Pending approval msg displayed correctly. Msg is ::"+str);
			TestngLogger.writeResult("PASS: Pending approval msg displayed correctly. Msg is ::"+str, true);
		}else {
			Log.error("FAIL: Pending approval message is not displayed correctly");
			TestngLogger.writeResult("FAIL: Pending approval message not displayed correctly", false);
		}
		driverMethod.clickByJS("OK", lblOK);
	}
	public void selectSwapRollOver() throws Exception{
		driverMethod.selectDDLByText("", lstSwapContractType, "Swap-R");
	}
	public void verifyFirstUtilRollOver() throws Exception{
		driverMethod.clear("txtRollOverFirstUtil", txtRollOverFirstUtil);
		driverMethod.clickByJS("", btnSwapV2PlusButton);
		if (driverMethod.displayedElement(lblFirstUtilRollOverMsg)) {
			driverMethod.isElementIsDisplayed("lblFirstUtilRollOverMsg", lblFirstUtilRollOverMsg, true);
			driverMethod.clickByJS("btnOKk", btnOKk);
		}else {
			TestngLogger.writeResult("First Util mandatory msg not displayed for roll over", false);
		}

		Calendar cal2 = Calendar.getInstance();
		cal2.add(Calendar.DATE, 7);
		Date dateObject2 = cal2.getTime();
		SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String firstUtilization = date2.format(dateObject2);
		driverMethod.clear("txtRollOverFirstUtil", txtRollOverFirstUtil);
		driverMethod.inputText("txtfirstUtli", txtRollOverFirstUtil, firstUtilization);
		driverMethod.sendkeys("txtfirstUtli", txtRollOverFirstUtil, Keys.ENTER);
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}	
	}
	public void inputRollOverDate() throws Exception {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 17);
		Date dateObject = cal.getTime();
		SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String valueDate = date.format(dateObject);
		Calendar cal2 = Calendar.getInstance();
		cal2.add(Calendar.DATE, 7);
		Date dateObject2 = cal2.getTime();
		SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		String firstUtilization = date2.format(dateObject2);
        driverMethod.clear("txtRollOverValueDate", txtRollOverValueDate);
		driverMethod.inputText("txtFxPrintValueDate", txtRollOverValueDate, valueDate);
		driverMethod.sendkeys("txtFxPrintValueDate", txtRollOverValueDate, Keys.ENTER);
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}
		driverMethod.clear("txtRollOverFirstUtil", txtRollOverFirstUtil);
		driverMethod.inputText("txtfirstUtli", txtRollOverFirstUtil, firstUtilization);
		driverMethod.sendkeys("txtfirstUtli", txtRollOverFirstUtil, Keys.ENTER);
		if (driverMethod.displayedElement(btnNextAvaliDateOK)) {
			driverMethod.clickByJS("", btnNextAvaliDateOK);
		}
	}
	public void clickPlusButton() throws Exception {
		driverMethod.clickByJS("", btnSwapV2PlusButton);
		if (driverMethod.isElementDisplayed(btnOKK)) {
			driverMethod.clickByJS("ok button", btnOKK);
			driverMethod.sendkeys("txtFxPrintValueDate", txtRollOverValueDate, Keys.ENTER);
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, 21);
			Date dateObject = cal.getTime();
			SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			String valueDate = date.format(dateObject);
			driverMethod.clear("txtRollOverValueDate", txtRollOverValueDate);
			driverMethod.inputText("txtFxPrintValueDate", txtRollOverValueDate, valueDate);
			driverMethod.sendkeys("txtFxPrintValueDate", txtRollOverValueDate, Keys.ENTER);
			driverMethod.clickByJS("", btnSwapV2PlusButton);
		}

		if (driverMethod.isElementDisplayed(btnOKK)) {
			driverMethod.clickByJS("ok button", btnOKK);
			Calendar cal2 = Calendar.getInstance();
			cal2.add(Calendar.DATE, 11);
			Date dateObject2 = cal2.getTime();
			SimpleDateFormat date2 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			String firstUtilization = date2.format(dateObject2);
			driverMethod.clear("txtRollOverFirstUtil", txtRollOverFirstUtil);
			driverMethod.inputText("txtfirstUtli", txtRollOverFirstUtil, firstUtilization);
			driverMethod.sendkeys("txtfirstUtli", txtRollOverFirstUtil, Keys.ENTER);
		}

	}
	public void saveRollOver() throws Exception{
		driverMethod.clickByJS("btnInstructionForm", btnInstructionForm);
		driverMethod.doubleClick("btnInstructionMethod", btnInstructionMethod);
		driverMethod.selectDDLByText("reasonForPayment", reasonForPayment,
				Common.getCellDataProvider(data, "Reason for payment"));
		driverMethod.clickByJS("btnSaveDrawDown", btnSaveDrawDown);
		driverMethod.clickByJS("OK", btnNextAvaliDateOK);
	}
	public String getRollOverNumber() throws Exception{
		String str = driverMethod.getText("lblRollOverNumber", lblRollOverNumber).trim();
		Log.info("RollOver Number: "+str);
		TestngLogger.writeResult("RollOver Number: "+str, true);
		return str;	
	}
	public void verifyFirstUtilRollOverRollOver() throws Exception{
		driverMethod.clear("txtRollOverFirstUtil", txtRollOverFirstUtil);
		driverMethod.clickByJS("", btnSwapV2PlusButton);
		if (driverMethod.displayedElement(lblFirstUtilRollOverMsg)) {
			driverMethod.isElementIsDisplayed("lblFirstUtilRollOverMsg", lblFirstUtilRollOverMsg, true);
			driverMethod.clickByJS("btnOKk", btnOKk);
		}else {
			TestngLogger.writeResult("First Util mandatory msg not displayed for roll over", false);
		}
	}
	
}

package test.page.bulletnetobjects;

import org.openqa.selenium.By;

import com.nashtech.common.Common;
import com.nashtech.core.web.WebDriverMethod;
import com.nashtech.utils.databases.SqlServerJDBC;


public class LiveRatesPage{

	private WebDriverMethod driverMethod;
	private Object [] data;

	// Web Element Locators;
	
	private By tblLiveFeed = By.xpath(".//*[@id='divLiveFeed']//tbody/tr");
	private By ddlSell = By.xpath("//select[@id='Sell']");
	private By ddlBuy = By.xpath("//select[@id='Buy']");
	private By txtDate = By.xpath("//input[@id='ValueDate']");
	private By btnGo = By.xpath("//input[@id='btnGo']");
	
	public static By txtLiveFeedSymbol(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[1]");
	}
	public static By txtLiveFeedBid(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[2]");
	}
	public static By txtLiveFeedAsk(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[3]");
	}
	public static By txtLiveFeedHigh(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[4]");
	}
	public static By txtLiveFeedLow(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[5]");
	}
	public static By txtLiveFeedClose(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[6]");
	}
	public static By txtLiveFeedLastUpdate(int i){
		return By.xpath(".//*[@id='divLiveFeed']//tbody/tr["+i+"]/td[7]");
	}
	public LiveRatesPage(WebDriverMethod driverMethod, Object [] data) throws Exception {
		this.driverMethod = driverMethod;
		this.data = data;
	}
	
	public void verifyData() throws Exception{
		// Get quantity of return data
		int size = driverMethod.driver.findElements(tblLiveFeed).size();
		String departmentid=Common.getCellDataProvider(data,"DepartmentId");
		String SQL1=Common.getCellDataProvider(data,"SQL Department 40");
		String SQL2=Common.getCellDataProvider(data,"SQL Other Department");
		String data[][] = departmentid.equalsIgnoreCase("40")? SqlServerJDBC.getValueInDatabase(SQL1):SqlServerJDBC.getValueInDatabase(SQL2);
		// Verify return data 
		for (int i = 0; i<size;i++){	
			driverMethod.verifyContainText("txtLiveFeedSymbol", txtLiveFeedSymbol(i+1), data[i][0]);
			driverMethod.verifyContainText("txtLiveFeedBid", txtLiveFeedBid(i+1), data[i][1].substring(0,data[i][1].length()-6));
			driverMethod.verifyContainText("txtLiveFeedAsk", txtLiveFeedAsk(i+1), data[i][2].substring(0,data[i][2].length()-6));
			driverMethod.verifyContainText("txtLiveFeedHigh", txtLiveFeedHigh(i+1), data[i][3].substring(0,data[i][3].length()-6));
			driverMethod.verifyContainText("txtLiveFeedLow", txtLiveFeedLow(i+1), data[i][4].substring(0,data[i][4].length()-6));
			driverMethod.verifyContainText("txtLiveFeedClose", txtLiveFeedClose(i+1), data[i][5].substring(0,data[i][5].length()-6));
			driverMethod.verifyContainText("txtLiveFeedLastUpdate", txtLiveFeedLastUpdate(i+1), data[i][6]);
		}	
	}
	
	public void inputData () throws Exception{
		driverMethod.selectDDLByText("ddlBuy", ddlBuy, Common.getCellDataProvider(data, "Buy"));
		driverMethod.selectDDLByText("ddlSell", ddlSell, Common.getCellDataProvider(data, "Sell"));
		driverMethod.inputText("txtDate", txtDate, Common.getCellDataProvider(data, "Value Date"));
	}
	public void clickButtonGo() throws Exception{
		driverMethod.click("btnGo", btnGo);
	}
}

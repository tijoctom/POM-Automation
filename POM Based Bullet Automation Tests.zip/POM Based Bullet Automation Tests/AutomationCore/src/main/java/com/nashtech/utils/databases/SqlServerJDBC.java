package com.nashtech.utils.databases;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Connection;

import com.nashtech.common.Common;
import com.nashtech.utils.report.Log;
import com.nashtech.utils.report.TestngLogger;

public class SqlServerJDBC extends Common{
	
	public static Connection con = null;
	/**
	 * Get connection from jdbc
	 * 
	 * @return A connection instance that connect to jdbc
	 * @throws Exception
	 */
	public static void getConnection() throws Exception {
		try {
			
			String sqlServerName = Common.getConfigValue("SqlServerName");
			String sqlServerDbName = Common.getConfigValue("SqlServerDbName");
			String sqlServerUser = Common.getConfigValue("SqlServerUSer");
			String sqlServerPwd = Common.getConfigValue("SqlServerPwd");

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://"
					+ sqlServerName + ";databaseName=" + sqlServerDbName,
					sqlServerUser, sqlServerPwd);
			Log.info("Connected to db");

		} catch (Exception e) {

			Log.error(e.getMessage());
			TestngLogger.writeLog(e.getMessage());
			throw (e);

		}
	}
	
	/**
	 * Execute query command
	 * 
	 * @param query
	 *            The sql command
	 * @throws Exception
	 */
	public static void executeQuery(String query) throws Exception {

		try {

			Statement st = con.createStatement();
			st.execute(query);

		} catch (Exception e) {

			Log.error(e.getMessage());
			TestngLogger.writeLog(e.getMessage());
			throw (e);

		}

	}
	
	/**
	 * Perform query command and get value of a column
	 * 
	 * @param query
	 *            The sql command used to query value
	 * @param columnName
	 *            The column that want to get value
	 * @return
	 * @throws Exception
	 */
	public static String getValueInDatabase(String query, String columnName)
			throws Exception {
		String data = "";

		try {

			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				data = rs.getString(columnName);
			}
			if (data==null)
				return "";
		} catch (Exception e) {

			Log.error(e.getMessage());
			TestngLogger.writeLog(e.getMessage());
			throw (e);

		}

		return data;
	}
	/**
	 * Perform query command and get data table of executed query 
	 * 
	 * @param query
	 *            The sql command used to query value
	 * @param columnName
	 *            The column that want to get value
	 * @return
	 * @throws Exception
	 */
	public static String[][] getValueInDatabase(String query)
			throws Exception {
		String data[][] = null;

		try {
			
			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, 
				    ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery(query);
			rs.last();
			int row = rs.getRow();
			rs.beforeFirst();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnscount = rsmd.getColumnCount();			
			data = new String[row][columnscount];
			int i=0,j;
			while (rs.next()){
				j=0;
				while(j<columnscount) {				
					data[i][j] = rs.getString(j+1);				
					j++;
				}
				i++;
			}
 			

		} catch (Exception e) {

			Log.error(e.getMessage());
			TestngLogger.writeLog(e.getMessage());
			throw (e);

		}

		return data;
	}
	/**
	 * Get connection from jdbc
	 * 
	 * @return A connection instance that connect to jdbc
	 * @throws Exception
	 */
	public static void closeConnection() throws Exception {
		try {
			con.close();
			Log.info("Connection closed");

		} catch (Exception e) {

			Log.error(e.getMessage());
			TestngLogger.writeLog(e.getMessage());
			throw (e);

		}
	}
}
